---
stage: written
name: Enchantress
aliases: [Siren]
realm: mantle
axis: -55
beings: [tier3-alpha, tier3-gamma]
access: glamour
sigil: enchantress
identity:
  material: silk, pearl and mirror
  palette: [pearl, rose-gold, sea-glass, abyssal blue-black]
  geometry: mirrored-curves
  motion: lagging-reflection
  layout: veiled-diptych
  interaction: glamour-unveil
  typeAccent: Cormorant Garamond light italic, mirrored across the diptych
  entrance: veil-draws
  cursor: mirrored-pearl
  initial: mirrored-capital
  sound: wordless-voice
epithet: The Face That Is Wanted
cipherTitle: Persuader by body, scent and voice
thesis:
  almanac: >-
    The Enchantress wears the one face each beholder most desires and speaks in the one voice
    each listener cannot refuse, and none of it is illusion: the deep has made her flesh able
    to become what is wanted.
  cipher: >-
    An Enchantress is a Tier III being who reshapes her own body and releases scent and sound
    tuned to a target's instincts, producing trust and desire strong enough to override the
    target's judgement.
tropes:
  - the siren on the rocks, singing sailors to wreck
  - the beautiful stranger who is not what she seems
  - the face that changes in a mirror
  - the lady of the lake and the fairy queen
  - love that falls upon a man like a spell
  - the crone revealed beneath the maiden
instruments:
  - object: The face
    almanac: >-
      Never twice the same, and always the one that was hoped for. She studies a man for an
      evening and comes to him the next morning wearing his first love's eyes, and it is no
      mask: touch it, and it is skin.
    cipher: >-
      Her own body, which she can reshape in bone, skin and feature over hours or minutes.
      The change is physical, not a trick of sight, and it is tuned to what the target is
      observed to find most attractive.
  - object: The voice
    almanac: >-
      A song without words, or words that seem to mean only kindness. Sailors have steered onto
      the rocks to come nearer to it, and thanked her as they drowned.
    cipher: >-
      Sound pitched and paced to calm and attract. Combined with scent, it lowers a listener's
      wariness and makes compliance feel like the listener's own wish.
  - object: The mirror
    almanac: >-
      Silver-backed and kept covered. In it she learns the face before she wears it, and in it,
      some say, the face she was born with can still be seen.
    cipher: >-
      A study tool. The reshaping is deliberate and must be practised, and a reflection shows
      her own true form while she is not holding a change.
costs:
  - almanac: >-
      The change hurts. Bone that is asked to move aches for days, and a face held too long
      begins to wear out the body beneath it.
    cipher: >-
      Reshaping the body is painful and draining. Holding a changed form for long periods wears
      on her health, and rapid changes worsen it.
  - almanac: >-
      She must be near. The spell is in her breath, her scent and her presence, and a letter in
      her hand charms no one.
    cipher: >-
      The effects travel by scent, sight and sound and so work only within a short distance.
      She cannot act on anyone she cannot reach in person.
  - almanac: >-
      Love that is made must be fed. Leave a man long enough and he wakes, and remembers, and
      does not forgive.
    cipher: >-
      The induced trust fades without renewed exposure. Once it lapses, the target usually
      recalls what happened and recognises it as manipulation.
blindSpots:
  - almanac: >-
      The Cleric. The Sealed Light sets every body back to the pattern it was first given, and
      under it her borrowed face, and all her art, come undone at once.
    cipher: >-
      The Sealed Broadcast restores tissue to its original pattern. A body altered by the
      Second Tier is returned to its pattern too, so a Cleric's relay strips her changes and
      harms her.
  - almanac: >-
      The dead and the empty. What has no heart to quicken cannot be charmed, and the
      Necromancer's puppets walk past her as though she were a stone.
    cipher: >-
      Her effects act on living instincts. A reanimated corpse, an object or anything without a
      working nervous system is unaffected.
counterparts:
  - archetype: witch
    note:
      almanac: >-
        Legend calls them both witches, and the Registry does not. The Witch must dig, dry and
        boil every working out of the ground; the Enchantress needs no pot, because what the
        Witch brews, the Enchantress is. One learned what the deep earth holds, and the other
        was made of it. That is why Morgan le Fay, who changed her face at will and never
        needed a cauldron, is filed here and not there.
      cipher: >-
        Both draw on the Second Tier and both act on bodies. The Witch is usually an ordinary
        person who prepares external compounds; the Enchantress is Tier III and produces
        comparable effects from her own physiology without preparation. Morgan le Fay is filed
        as an Enchantress for this reason.
  - archetype: bard
    note:
      almanac: >-
        Both win with the voice, and the ear cannot tell them apart. The Bard has learned the
        note that shakes a heart and could teach it to an apprentice; the Enchantress was born
        with a throat that sings it, and no one could learn her song. One plays upon the
        listener, and the other becomes the thing the listener longs for.
      cipher: >-
        Both use sound to act on a listener. The Bard is an ordinary person using learned
        acoustics; the Enchantress is Tier III and combines voice with scent and physical
        change. A Bard's effect is in the sound alone; hers depends on her presence.
cipher: |-
  Being: Tier III, Alpha or Gamma. Source: the Second Tier, through her own body. Access: Biological persuasion.

  The Enchantress, or Siren, is a Tier III being whose body the Second Tier has made changeable. She can reshape her own bone, skin and features, and she releases scent and uses vocal sound tuned to a target's instincts. None of this is illusion. The face is real flesh, the scent is a real chemical signal and the song is real sound.

  Together these produce trust, attraction and a desire to please that override the target's judgement. The target remains conscious and believes the feelings are their own. While the effect holds, the target will do almost anything she asks, including acts against their own interest.

  Fiction usually calls her a witch. She is filed separately because she prepares nothing: what a Witch must extract from plants and minerals, the Enchantress produces in her own body. Morgan le Fay is the best-known case.

  Limits: the effects work only at close range and fade without renewal. Changing her form is painful and draining. The dead and anything without a working nervous system are immune. The Sealed Broadcast returns her altered body to its original pattern, undoing her changes and harming her.
---

The Enchantress is never seen as she is. Each beholder sees the face that beholder has always hoped to see, and hears a voice so gentle that refusing it would feel like cruelty. Sailors have turned their ships onto the rocks for her; knights have given up their oaths, and kings their crowns, and none of them felt it as anything but love.

It is not an illusion, and that is what makes her terrible. The deep earth made her flesh changeable, and she changes it. Bone shifts and skin takes on another colour, until the face in the doorway is the face that was wanted. Her breath carries a sweetness that dulls every suspicion, and her song finds the place in the listener where trust is kept, and opens it.

The old tales call her a witch, and the Registry does not. A Witch must gather, dry and boil every working from the ground; the Enchantress needs no pot, because she is herself what the pot would make. Morgan le Fay, who wore a hag's face or a queen's as she chose and never stooped to a cauldron, is the great example, and is filed here.

Her power has edges. She must be near: in sight, in hearing, close enough to breathe. Her changes cost her, and a face held too long wears on the body beneath it. Love that she has made must be renewed, and those who wake from it remember.

Two things she cannot move at all. The dead have no heart to quicken, and walk past her as though she were a stone. And the Sealed Light, which sets every body back to the pattern it was first given, would take her borrowed beauty from her in an instant, and more besides.
