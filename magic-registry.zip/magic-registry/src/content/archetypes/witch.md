---
stage: written
name: Witch
aliases: []
realm: mantle
axis: -65
beings: [baseline-human, tier3-gamma]
access: decoction
sigil: witch
identity:
  material: stained linen, soot and pressed specimens
  palette: [oxblood, belladonna violet, soot, bone]
  geometry: botanical-plate
  motion: simmer-and-bleed
  layout: pinned-specimens
  interaction: rustle-and-raven
  typeAccent: IM Fell English italic labels
  entrance: smoke-clears
  cursor: ash-and-seed
  initial: nightshade-capital
  sound: simmer-and-crow
epithet: Mistress of the Root and the Pot
cipherTitle: Chemist of the Second Tier
thesis:
  almanac: >-
    The Witch digs for what the deep earth has hidden in root, metal and blood, and boils it
    down until it will do harm or good on command; nothing she does comes from the sky, and
    nothing comes without the pot.
  cipher: >-
    A Witch is an ordinary person who extracts and concentrates the chemistry of the Second
    Tier, toxins, minerals and blood, and acts on bodies only through what has been prepared in
    advance.
tropes:
  - the cauldron over the fire
  - a cottage at the edge of the deep wood
  - herbs hung to dry from the rafters
  - the black cat, the toad and the raven
  - the poppet stuck with pins
  - the village wise woman, feared and sent for
instruments:
  - object: The cauldron
    almanac: >-
      Black iron, older than the cottage it hangs in, scoured with ash and never with water.
      Into it go the root, the bark, the shaving of lead and the drop of blood, and out of it,
      after a night and a day, comes the one thing in them that was worth having.
    cipher: >-
      A vessel for long boiling, steeping and reduction. It is where raw material is
      concentrated into a usable dose. Nothing a Witch does at the moment of working is new;
      it was made here first.
  - object: The familiar
    almanac: >-
      The cat on the sill, the toad under the step, the raven on the roof-tree. Each was
      tamed with a morsel that no other hand could have given it, and each goes where the
      Witch cannot, and comes back to tell her.
    cipher: >-
      An animal brought under the Witch's control by a prepared compound in its food. It
      serves as a scout and a messenger, and can carry out a simple act on her behalf. It is
      an ordinary animal, dosed, not a spirit.
  - object: The poison garden
    almanac: >-
      Behind the cottage, walled, and planted in no order a stranger could read: nightshade
      beside foxglove, henbane in the shade of the yew, and the mushrooms in the cellar. To the
      Witch it is a cupboard, and every shelf is labelled.
    cipher: >-
      A cultivated supply of toxic and medicinal plants, among them belladonna, henbane,
      foxglove and fungi. A Witch's range of effects is limited to what the stores can
      produce.
costs:
  - almanac: >-
      Nothing in the moment. A Witch caught with empty shelves is a woman with a stick, and
      every working must be brewed, dried or buried long before it is wanted.
    cipher: >-
      Every effect must be prepared in advance. A Witch with no stock on hand can do nothing
      at the moment of need.
  - almanac: >-
      The pot breathes back. Years over the fumes stain the hands, cloud the eye and loosen the
      teeth, and many a Witch has died of a working that was not meant for her.
    cipher: >-
      The substances are as dangerous to the maker as to the target. Repeated exposure
      damages the Witch's own health, and accidents are often fatal.
  - almanac: >-
      The dose is narrow. The same root that eases a fever stops a heart at twice the measure,
      and a village forgives a cure far more slowly than it remembers a death.
    cipher: >-
      Most of the compounds have a small margin between a useful dose and a lethal one, so a
      Witch's healing and harming are the same skill, and are judged as such.
blindSpots:
  - almanac: >-
      The one who is never in the room. Against the Wizard, who arranges that their roads never
      cross, the Witch has prepared everything and has no one to give it to.
    cipher: >-
      A poison needs a body to reach. A target protected by probability, such as a Wizard,
      simply never comes within range, and the Witch's preparations go unused.
counterparts:
  - archetype: wizard
    note:
      almanac: >-
        The oldest quarrel in the Registry, and the one legend made into Merlin and Morgan le
        Fay. The Witch works what is: flesh, root, metal and blood, the heavy things of the
        Mantle. The Wizard works what will happen. Her poison would kill him in a breath if she
        could ever find him in the room, and he makes sure that she never does. The Registry
        files Morgan herself as an Enchantress, but the quarrel is the Witch's own.
      cipher: >-
        The Witch works on matter and chemistry, from the Second Tier; the Wizard works on
        likelihood, from the First. A Witch's preparations must reach a body, and a Wizard
        arranges never to be where they can. The Merlin and Morgan le Fay legend is the classic
        case, although the Registry files Morgan as an Enchantress.
  - archetype: druid
    note:
      almanac: >-
        They gather in the same woods, often from the same plants, and the villages call both of
        them wise. But the Druid tends the living web that answers to the sky, and the Witch
        digs beneath it, for the poison in the root and the metal in the stone that belong to
        the deep. The Druid asks the wood to act; the Witch takes what the wood holds and boils
        it down.
      cipher: >-
        Both work with plants and animals, from opposite sources. The Druid directs the Grid,
        which belongs to the First Tier, and acts only through living organisms. The Witch
        extracts chemistry belonging to the Second Tier and applies it directly to a body.
  - archetype: enchantress
    note:
      almanac: >-
        Legend calls them both witches, and the Registry does not. The Witch must dig, dry and
        boil every working out of the ground; the Enchantress carries hers in her own body, and
        needs no pot to make a man love her or a face to change. One learned what the deep earth
        holds, and the other was made of it.
      cipher: >-
        Both draw on the Second Tier and both act on bodies. The Witch is usually an ordinary
        person who must prepare external compounds; the Enchantress is Tier III and produces her
        effects from her own physiology. Morgan le Fay, often called a witch, is filed as an
        Enchantress for this reason.
cipher: |-
  Being: a baseline human, or Tier III Gamma. Source: the Second Tier, through physical material. Access: Chemistry.

  The Witch is the Registry's chemist. The Second Tier is the source of mass, minerals and the chemistry of living bodies, and a Witch draws on it the slow way: by gathering plants, fungi, metals and blood, and boiling, drying and reducing them until their active substances are concentrated. Belladonna, henbane, foxglove and certain fungi are the core of the craft, alongside lead, mercury and other heavy minerals.

  The resulting compounds act directly on the body: they paralyse, sedate, stop the heart, cause visions or ease pain. A familiar is an ordinary animal kept under control by a compound in its food and used as a scout. Nothing a Witch does is projected at a distance by force of will; every effect needs a substance, and the substance must reach the target, by breath, by mouth, through the skin or by an animal carrier.

  Fiction often merges the Witch with the Enchantress. The difference is the Being. A Witch is usually an ordinary person and must prepare everything outside the body. An Enchantress is Tier III and produces comparable effects from her own physiology, without preparation.

  Limits: nothing works without preparation and stock. The compounds harm the maker too. Doses are narrow. A target who is never within reach, which is what a Wizard arranges, cannot be affected at all.
---

The Witch keeps her power on shelves. Root and bark hang drying from the rafters; jars of seed, of shaved metal and of things better left unnamed line the walls; the pot is never quite cold. Everything she can do, she made, and she made it from the earth.

This is what separates her from every practitioner of the sky. The Wizard reckons and the Shaman listens, but the Witch digs. The Mantle has put its strength into the heavy things, the lead in the stone, the poison in the nightshade root, the iron in the blood, and the Witch's whole art is the drawing of it out: gathering, drying, steeping and boiling down, until one black drop holds what a whole hedgerow held.

What comes out of the pot works on the body, and works without regard for anyone's will. It stills a limb, slows a heart, opens the eye to visions or closes it in sleep. It is carried on a breath, in a cup, on a needle, or by the cat that slips through a window the Witch could never pass. It never flies of its own accord, and it is never made in the moment. A Witch with empty shelves is only a woman in the woods.

The craft is paid for in the body that practises it. Years over the fumes leave their mark, and the line between the cure and the killing dose is drawn so fine that a village which sends for the wise woman at a birth will burn her after a death. She knows the measure better than anyone alive, and it is still not always enough.

Legend calls many women witches who were something else, and Morgan le Fay most of all. The Registry is stricter. A Witch is one who learned what the deep earth holds and labours to draw it out. One who carries that power already in her flesh is an Enchantress, and is filed there.
