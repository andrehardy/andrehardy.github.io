---
stage: written
name: Druid
aliases: []
realm: vault
axis: 40
beings: [baseline-human, tier3-gamma]
access: cultivation
sigil: druid
identity:
  material: bark, moss and lichen
  palette: [moss, lichen, bark, spore-gold]
  geometry: phyllotaxis-growth
  motion: root-growth
  layout: living-nodes
  interaction: tendril-reach
  typeAccent: EB Garamond with its historical ligatures, set like a forester's register
  entrance: seed-splits
  cursor: sprouting-spores
  initial: root-capital
  sound: leaves-and-bough
epithet: Keeper of the Living Web
cipherTitle: Director of the Grid
thesis:
  almanac: >-
    The Druid is the keeper of a grove who lays a hand on the living web beneath it and gives
    that web work to do, and for all the bark and moss, the Druid's power comes down from the
    sky.
  cipher: >-
    A Druid directs the Grid, the First Tier's fungal web through living things, to make
    organisms grow, spread or act, and can do nothing where nothing lives.
tropes:
  - green robes and a staff of oak
  - sacred groves and standing stones
  - mistletoe cut with a golden sickle
  - taking the shape of a bear or an eagle
  - commanding beasts and briars
  - the keeper of the balance of nature
instruments:
  - object: The sickle
    almanac: >-
      Of gold, or of brass in poorer groves, for cutting what must be cut cleanly at its hour:
      the mistletoe on the sixth night, the graft, the bough that would steal the light from a
      young oak.
    cipher: >-
      A cutting tool for timed harvests and grafts. Clean cuts in the right season matter,
      because the Grid answers to the condition of the living tissue it runs through.
  - object: The grove
    almanac: >-
      Not a temple but a workshop a century deep: every tree in it planted, pruned and listened
      to, until the web beneath knows the keeper's step.
    cipher: >-
      A tended woodland where the Grid is dense and responsive. A Druid is strongest in a grove
      of their own cultivation and weakest on bare ground.
  - object: The living staff
    almanac: >-
      Cut from a tree that still lives, and kept alive, so that it puts out a leaf each spring.
      Driven into the turf, it is the keeper's hand laid upon the web from a distance.
    cipher: >-
      A length of living wood that stays joined to the Grid. Pushed into soil, it lets the Druid
      direct the Grid beyond arm's reach.
costs:
  - almanac: >-
      Patience past a lifetime. Any living thing within reach will answer the Druid at once,
      but only in its own small measure; to close a road with bramble or turn the wolves from a
      valley, the web must be tended for decades, and a keeper's work is often finished by the
      next.
    cipher: >-
      Living organisms within reach respond to a Druid immediately, but only at their own scale.
      Effects across a wide area, such as closing a road or moving animals between valleys, need
      years of cultivation in that place.
  - almanac: >-
      Nothing where nothing lives. On bare rock, in a stone keep or out on the salt sea, the
      Druid is only a tired walker with a stick.
    cipher: >-
      Without living organisms nearby a Druid has nothing to direct and no power at all.
  - almanac: >-
      What is hurried is paid for. Every forced bloom draws its strength from the ground and
      the creatures around it, and a field made to flower in a night lies starved for a year.
    cipher: >-
      Accelerated growth draws on local resources. Forcing it exhausts the soil and the
      organisms nearby, and the damage cannot simply be undone.
blindSpots:
  - almanac: >-
      The dead. A corpse has left the web, and the keeper has no hold on what the Necromancer
      sets walking.
    cipher: >-
      The Grid runs through living organisms only. Dead tissue lies outside it, so a Druid has
      no hold on the reanimated dead.
counterparts:
  - archetype: shaman
    note:
      almanac: >-
        The Shaman and the Druid sit at either end of the same web. The Shaman eats the key and
        listens to it; the Druid tends it and is listened to. Both look like children of the
        soil and both answer to the sky, and between them they are why the Registry warns its
        readers never to file a practitioner by the mud on the boots.
      cipher: >-
        Both draw on the First Tier through the Grid. The Shaman's access is perception and
        changes nothing; the Druid's is direction, acting through living organisms. Both are
        filed under the First Tier despite their earthly appearance.
  - archetype: witch
    note:
      almanac: >-
        Neighbours in the same wood, and strangers under it. The Witch digs into the soil for
        what the deep has put there, the poison in the root and the metal in the stone; the
        Druid tends the living web that runs above all that and answers to the sky. Both gather
        and brew, and both are called wise by villages that cannot tell a cure from a curse.
        The Registry can: one art reaches down, and the other is reached down to.
      cipher: >-
        Both work with plants, soil and animals, from opposite sources. The Witch extracts
        chemistry belonging to the Second Tier; the Druid directs the Grid, which belongs to the
        First. A Witch's poison acts on a body directly; a Druid acts only through living
        organisms that the Grid reaches.
cipher: |-
  Being: a baseline human or Tier III Gamma. Source: the First Tier, through the Grid. Access: Tending the Grid.

  The Druid looks like the most earthly of practitioners and is not. The Grid, the planet-wide fungal web that links roots, soil and living things, carries the First Tier, and a Druid who has tended a place long enough can direct that web. Directed, it acts through the organisms it reaches: roots grow quickly where they are told, vines climb, spores bloom, and animals come or go.

  Everything a Druid does is done by something alive. A Druid does not grow a vine out of nothing; the vine must already be there, or its seed must be in the soil. The power scales with how much life is present and how long it has been cultivated, which is why the grove matters.

  Fiction often lets Druids take animal shapes. A body that changes its own form belongs to Tier III Alpha, and the Registry files that ability there; the Druid's art acts on other organisms, never on the Druid's own body.

  Limits: no living organisms means no power. Forced growth exhausts the soil and the creatures around it. Dead tissue lies outside the Grid, so the reanimated dead cannot be touched.
---

Under every field and forest runs a web finer than hair and older than the oldest oak, joining root to root and creature to creature. The Druid is its keeper.

That is the first thing to know about the Druid, and the thing most often missed. For the Druid wears bark and moss, keeps to the woods, and is reckoned the very spirit of the soil. Yet the web the Druid tends answers to the sky. The Vault runs through it as sap runs through a tree, and when the Druid lays a hand upon the web, it is the sky that hears.

The work is slow beyond any patience but a tree's. A keeper plants a grove and listens to it for a lifetime; the web grows thick beneath, learns the keeper's step, and in the end does the keeper's bidding: the bramble closing a road, the ivy pulling down a wall, the wolves leaving one valley for the next. Nothing is made from nothing. Whatever the Druid commands must already be there, and alive, and it does the work with its own strength.

The old tales give the Druid the bear's shape and the eagle's, but the Druid's art goes outward from the Druid and never inward. Flesh that changes its own form belongs to the Chimeric, and the Registry files it there.

What lives is the Druid's to ask, and what does not, is not. On bare stone, at sea or in a hall of dressed granite, the keeper is an old walker leaning on a stick; and the dead, who have left the web, are past any keeping at all.
