---
stage: written
name: Paladin
aliases: []
realm: vault
axis: 80
beings: [baseline-human]
access: warding
sigil: paladin
identity:
  material: steel and heraldic enamel
  palette: [argent, azure, gules, steel]
  geometry: heraldic-ordinaries
  motion: stillness-deflects
  layout: blazon-column
  interaction: ricochet-shield
  typeAccent: Cormorant Garamond capitals, widely spaced, as on a motto scroll
  entrance: banner-unfurls
  cursor: steel-mote
  initial: shield-capital
  sound: bell-and-steel
epithet: Shield of the Sky's Favour
cipherTitle: Warrior shielded by improbability
thesis:
  almanac: >-
    The Paladin is a sworn mortal held in the Vault's favour, so that every blow aimed true goes
    somehow astray for as long as the vow is kept.
  cipher: >-
    A Paladin is a baseline human committed to a First Tier purpose, around whom the First Tier
    keeps a defensive field that makes harm aimed at the Paladin improbable.
tropes:
  - plate armour, a shield and a sword
  - a sacred oath sworn at vigil
  - a shining aura in battle
  - smiting evil
  - a healing touch
  - the knight who cannot be killed
instruments:
  - object: The oath
    almanac: >-
      Spoken once on a vigil night and kept every day after, it sets the terms on which the
      favour is held. Break them, and the mail of fortune falls away like a cloak unpinned.
    cipher: >-
      The vow names the purpose the Paladin serves. The field holds while the Paladin acts
      within that purpose and fails when the Paladin abandons it.
  - object: The shield
    almanac: >-
      Painted with the arms of a house, and the least of the Paladin's defences: the steel turns
      what it meets, and the favour turns what it never has to meet.
    cipher: >-
      An ordinary shield. It stops the blows that reach it; the field makes sure that few blows
      arrive cleanly. The two are easily confused, which is why the armour takes the credit.
  - object: The blade
    almanac: >-
      Carried and drawn, but only after the other blade is drawn. The Paladin strikes as a sea
      wall strikes the wave that breaks against it.
    cipher: >-
      A plain weapon with no power of its own. The field does not help in attack, so once the
      defence is done a Paladin fights with ordinary skill.
costs:
  - almanac: >-
      The vow binds both ways. The favour that turns the arrow is held on terms, and a Paladin
      who breaks faith stands one dawn in plain steel, as mortal as any squire.
    cipher: >-
      Protection depends on keeping the purpose. Abandoning it removes the field, and the
      Paladin often learns this only when the next blow lands.
  - almanac: >-
      The favour will not strike. It turns harm away and does nothing more; a Paladin who would
      win must win by the sword, with no wonder in the arm.
    cipher: >-
      The field is defensive only. It improves the Paladin's chance of surviving, not of winning,
      and every attack is made with ordinary strength.
  - almanac: >-
      Those beside the Paladin stand outside the favour. An arrow that swerves from the Paladin
      still falls somewhere, and old companions learn to stand behind and never beside.
    cipher: >-
      The field protects the Paladin alone. Deflected missiles and broken blades keep travelling
      and can injure anyone nearby.
blindSpots:
  - almanac: >-
      The slow harm. The favour answers a blow, not a famine: the long hunger of a siege, a
      fever in the camp or the cold of a winter march has no single moment to turn aside.
    cipher: >-
      The field acts on discrete events that would harm the Paladin. Slow, spread-out harms such
      as starvation, disease or exhaustion offer no single event to make improbable.
counterparts:
  - archetype: cleric
    note:
      almanac: >-
        The Paladin goes first into the battle and the Cleric follows to tend the fallen, and
        so the songs have made one figure of them. They are two. The favour that turns a sword
        from the Paladin cannot close a single wound, and the light that closes wounds cannot
        turn a single sword.
      cipher: >-
        The Paladin is protected by a First Tier field and has no power to heal. The Cleric
        relays the Sealed Broadcast, which heals and cannot protect. A knight who does both is,
        to the Registry, practising two arts.
  - archetype: warlock
    note:
      almanac: >-
        Each may walk out of a slaughter without a scratch, and the crowd cannot tell them
        apart. The Paladin was spared because the sky would have the vow kept; the Warlock was
        spared because the deep was paid. One protection is given for a purpose and ends when
        the purpose is betrayed; the other is bought, and ends when the debt is called.
      cipher: >-
        Both can be protected from harm, by opposite sources on opposite terms. The Paladin's
        field comes from the First Tier and depends on serving its purpose; the Warlock's
        protection comes from the Second Tier under a Covenant and must be paid for.
cipher: |-
  Being: a baseline human, committed to a purpose. Source: the First Tier. Access: probability shielding.

  A Paladin has no unusual strength and works no spells. The First Tier, which governs probability, keeps a field around a person who is acting for one of its purposes, and inside that field harm aimed at the Paladin becomes unlikely to land. Arrows are caught by sudden gusts, blades break on hidden flaws and a charging horse stumbles. Each event is ordinary; their reliable arrival is not.

  The Paladin does not control the field. It answers threats to the Paladin, not the Paladin's wishes, so it cannot be aimed, cannot be used to attack and does nothing while nothing threatens. The oath matters because the field depends on the purpose: a Paladin who abandons it is unprotected.

  Fiction often gives the Paladin a healing touch. Healing belongs to the Cleric and the Sealed Broadcast; the Registry treats a healing knight as two practices in one person, and files the knight by the shield.

  Limits: the field is defensive only and protects only the Paladin, so deflected harm can strike companions. It acts on discrete events, so slow harms such as hunger and disease pass through it. It ends when the purpose is abandoned.
---

The Paladin swore, and the sky heard. That is the whole of the matter; the rest follows from it.

There is no fire in the Paladin's hands and no strength beyond a soldier's. What there is, is favour. The Vault, which disposes every likelihood under heaven, has taken this one mortal into its keeping for the sake of the vow, and so the world about the Paladin falls out a little kindly. The arrow meets a gust. The axe-head flies from a cracked haft. The lance that would have found the gap in the mail finds the boss of the shield instead, by a hand's breadth, again and again, until the enemy begins to speak of miracles.

It is not a miracle. It is likelihood leaned upon, as the Wizard leans upon it, but the Paladin does no reckoning: the favour reckons for itself, and only against harm. It will not throw the enemy down and it will not open the gate. A Paladin who would win must win as any knight wins, by steel and nerve, with the favour standing behind like a squire who only ever parries.

The painted windows crowd other gifts into the Paladin's hands, the healing touch above all. That gift is the Cleric's. Where a knight both shields and heals, the Registry sees two arts in one coat, and files the knight under the shield.

And the vow cuts both ways. The favour holds while the purpose is kept, and whoever turns from it finds, at the next blow, that the luck has gone out of the world. Nor does it shelter anyone else: arrows that swerve from the Paladin land somewhere, and wise companions stand behind and never beside.
