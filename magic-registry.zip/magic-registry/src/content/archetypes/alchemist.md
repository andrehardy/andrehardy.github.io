---
stage: written
name: Alchemist
aliases: []
realm: threshold
axis: 0
axisNote: unbound
beings: [baseline-human]
access: artifice
sigil: alchemist
identity:
  material: glassware, copper and a laboratory notebook
  palette: [verdigris, copper, mercury, sulfur]
  geometry: apparatus-diagram
  motion: distillation-stages
  layout: struck-notebook
  interaction: transmute-hover
  typeAccent: planetary-metal symbols set inline, with failed trials struck through
  entrance: flask-boils
  cursor: transmuting-droplet
  initial: planetary-capital
  sound: glass-and-bubbles
epithet: Apprentice to Nothing but the Furnace
cipherTitle: Experimenter without a source
thesis:
  almanac: >-
    The Alchemist was given nothing, by sky, deep or blood, and set out to take it all the same,
    with fire, glass and a notebook of failures, so that whatever the Alchemist can do was
    found out by trial and can be done again by anyone who reads the notes.
  cipher: >-
    An Alchemist is an ordinary person with no source of power who imitates the effects of
    others by experimental chemistry and metallurgy, producing crude but repeatable results.
tropes:
  - the philosopher's stone
  - turning lead into gold
  - the elixir of life
  - the cluttered laboratory and its bubbling glass
  - the explosion that blows out the windows
  - equivalent exchange
instruments:
  - object: The alembic
    almanac: >-
      Glass, blown to the Alchemist's own drawing, with a beak that drips into the receiving
      flask all night. What went in as a stinking mash comes out as one clear drop.
    cipher: >-
      A distilling apparatus for separating and concentrating substances. It is how an
      Alchemist isolates the active part of a material, and it can be built by anyone with the
      design.
  - object: The athanor
    almanac: >-
      The slow furnace, fed day and night for weeks, so that the heat in the egg-shaped vessel
      never rises or falls by a hair. An apprentice who lets it go out begins again.
    cipher: >-
      A furnace that holds a steady temperature for long periods. Many of the Alchemist's
      reactions only work under controlled heat over time.
  - object: The notebook
    almanac: >-
      Thick, scorched at the corners and written in a cipher of planets and metals: every
      measure, every hour, and every failure struck through but never torn out.
    cipher: >-
      A record of procedures, quantities and results. Because the Alchemist has no innate or
      borrowed power, the notes are the craft; anyone who follows them can repeat the result.
costs:
  - almanac: >-
      The laboratory bites. Mercury shakes the hands and loosens the wits, the fumes of the
      furnace scar the lungs, and an Alchemist who has kept all ten fingers is either very
      careful or very new.
    cipher: >-
      The work involves toxic metals, corrosive substances and unstable reactions. Poisoning,
      burns and explosions are routine hazards.
  - almanac: >-
      Most of it fails. For every working that answers, a hundred end in a cracked vessel and a
      black residue, and a lifetime is spent on the difference.
    cipher: >-
      Results come by trial and error. Most experiments fail, and progress is slow.
  - almanac: >-
      The copy is always cruder than the thing it copies. The Alchemist's draught opens the door
      the Shaman's key opens, but roughly, and the Alchemist's blast does what a Sorcerer does,
      but only once per flask.
    cipher: >-
      Synthetic imitations are less refined and less safe than what they imitate, and every
      effect is limited to the supply of material prepared.
blindSpots:
  - almanac: >-
      What cannot be weighed. Chance, foresight and the Sealed Light have no substance to put in
      a flask, and the Alchemist, who believes only in what can be measured, cannot touch them.
    cipher: >-
      Experiment works only on matter. Probability, perception through the First Tier and the
      Sealed Broadcast cannot be captured or synthesised.
counterparts:
  - archetype: shaman
    note:
      almanac: >-
        The Alchemist has heard of the Shaman's key, and spends years in a cellar trying to
        distil it from salts and spirits. What comes out of the alembic opens the door a crack,
        roughly and at a cost; what grows in the meadow opens it as it was meant to be opened.
        The Alchemist does not mind. The alembic's draught can be made again in any cellar.
      cipher: >-
        The Alchemist tries to synthesise compounds that imitate the Keys of Ingestion. The
        synthetic versions are cruder and more dangerous, but they can be reproduced from a
        procedure. The Shaman uses the natural keys, prepared by long tradition.
  - archetype: bard
    note:
      almanac: >-
        Two ordinary people who would not wait to be born gifted or to sign anything. The
        Bard listened to the world until it confessed its notes; the Alchemist took the world
        apart in a furnace. Both learned their craft as a trade is learned, and both can be
        undone by a single wrong measure.
      cipher: >-
        Both are ordinary people with learned techniques and no inherited capacity or
        Covenant. The Bard works through Acoustics with sound; the Alchemist works through
        Experiment with substances. Both depend on precise measurement.
cipher: |-
  Being: a baseline human. Source: none; the Unaligned. Access: Experiment.

  The Alchemist has no source. There is no inherited capacity, no access to either tier and no contract. What the Alchemist has is method: careful experiment with substances, heat and metals, recorded so that it can be repeated. The aim, historically and in fiction, is to reproduce what the gifted can do by other means.

  Two lines of work dominate. In the first, the Alchemist synthesises compounds that imitate the Keys of Ingestion and opens perception roughly, without the natural keys. In the second, the Alchemist refines heavy metals and reactive substances to imitate the force of the Second Tier: explosive mixtures, corrosives, anaesthetic vapours and the like. The legendary goals, gold from lead and the elixir of life, belong to the same project of taking by method what nature withheld.

  Everything an Alchemist achieves is chemistry and physics, so it can be taught, written down and repeated by anyone with the procedure and the materials. That is the Alchemist's strength and the reason the Registry files the Alchemist with no source at all.

  Limits: results are slow, crude and dangerous to the maker. Effects are limited to the material prepared. Nothing without substance, such as probability, the First Tier's record or the Sealed Broadcast, can be reached by experiment.
---

The Alchemist is what becomes of an ordinary person who will not accept that power is something one is given. Neither sky nor deep has spoken to the Alchemist; no gift runs in the blood, and no patron waits at the crossroads. There is a cellar, a furnace, a rack of glass, and a notebook.

From these the Alchemist sets out to take what others were handed. If the Shaman opens the walls of the mind with a root, the Alchemist will distil something that does the same out of salts and spirits, and drink it, and write down what happened. If the deep can split stone, the Alchemist will find the powder that splits it too. Most of it fails. A hundred vessels crack for every one that answers, and the failures are struck through in the notebook but never torn out, because they are part of the knowledge.

The successes are cruder than the things they imitate, and far more dangerous to the one who makes them. Quicksilver shakes the hands, fumes scar the lungs, and laboratories have a way of ending in fire. But they have one virtue that no gift has: they can be done again. Whatever the Alchemist learns can be written down and taught, and works for anyone who follows the recipe exactly.

The old goals were gold from lead and life without end, and nobody has reached them. The Registry is not interested in that. It files the Alchemist apart from every other practitioner for a different reason: the Alchemist is the only one whose power owes nothing to anyone.

What the Alchemist cannot do is touch what has no weight. Chance, foresight and the Sealed Light cannot be poured into a flask, and they are beyond the reach of a craft that believes only in what it can measure.
