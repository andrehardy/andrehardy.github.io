---
stage: written
name: Wizard
aliases: []
realm: vault
axis: 75
beings: [baseline-human]
access: study
sigil: wizard
identity:
  material: vellum ledger and brass astrolabe
  palette: [midnight indigo, brass, chalk]
  geometry: compass-construction
  motion: step-construction
  layout: ruled-grid
  interaction: thread-nudge
  typeAccent: tabular numerals and mathematical small caps
  entrance: compass-sweep
  cursor: compass-point
  initial: construction-capital
  sound: astrolabe-ticks
epithet: Reckoner of Probable Things
cipherTitle: Scholar of probability and timing
thesis:
  almanac: >-
    The Wizard is an ordinary mortal who has learned the arithmetic of the sky, and works
    wonders by asking the Vault to make the unlikely likely rather than by moving what is heavy.
  cipher: >-
    A Wizard is a baseline human who, through study alone, learns to address the First Tier in
    its own formulae, asking it to make one chosen outcome more probable at one place and time.
tropes:
  - robes, a long beard and a pointed hat
  - a staff or a wand
  - a tower full of books
  - prophecy and foresight
  - spells in an ancient tongue
  - the old mentor at the young hero's side
instruments:
  - object: The staff
    almanac: >-
      Not a lever but a lightning rod: a length of seasoned wood tipped with crystal, raised to
      the Vault and set down on the one place where the reckoning says the change must fall,
      so that the sky's answer comes to ground there and nowhere else.
    cipher: >-
      A directing instrument. Its crystal tip marks the exact point where the requested change
      is to happen and carries the request to the First Tier, as a lightning rod gives a strike
      one place to land. It stores no power.
  - object: The spellbook
    almanac: >-
      A ledger of tables rather than a book of words: the measures of hours and distances, the
      long columns of what follows what, copied and corrected by every hand that has held it.
    cipher: >-
      A reference of worked formulae for timing, distance and consequence, accumulated and
      corrected by generations of practitioners.
  - object: The incantation
    almanac: >-
      A petition in the Vault's own figures, said aloud. Each syllable is a figure set in its
      column, so that the sky is asked for precisely one thing, and the asking can be checked as
      it is made.
    cipher: >-
      The spoken formula is the request itself, addressed to the First Tier in the terms it
      answers to. One wrong term asks for the wrong outcome, so spells are spoken exactly, never
      improvised.
costs:
  - almanac: >-
      Years. No Wizard is born; every one is made slowly, at a desk, by candlelight, and many
      die before the arithmetic will answer them.
    cipher: >-
      Training takes years and most students never become proficient. There is no shortcut,
      because nothing is inherited.
  - almanac: >-
      The weight of the sums. A great working fills the mind as water fills a jar, and the body
      pays for it in fever, sleeplessness and early age.
    cipher: >-
      Large calculations exhaust the practitioner, mentally and physically, and errors made
      under that strain go wrong in unpredictable ways.
  - almanac: >-
      Nothing near at hand. A Wizard may arrange for an oak to fall on a road a mile away, yet
      cannot lift a pebble from the table; when the blow is already falling, there is no time
      left to reckon.
    cipher: >-
      A Wizard cannot apply force directly. Every effect needs time and existing circumstances
      to work through, so sudden physical danger is the Wizard's weakest moment.
blindSpots:
  - almanac: >-
      The changeling. A creature whose flesh changes at will leaves no steady mark in the sky's
      ledger, and slips out of every reckoning made to find it.
    cipher: >-
      Calculation works on patterns. Bodies that rewrite their own pattern (Tier III Alpha)
      change faster than they can be predicted, so a Wizard cannot track them.
  - almanac: >-
      The unforeseeable heart. Arithmetic counts what is likely, and love, spite and mercy are
      seldom likely.
    cipher: >-
      Calculation predicts probable behaviour. A deliberate, improbable choice by one person is
      the hardest thing for it to anticipate.
counterparts:
  - archetype: witch
    note:
      almanac: >-
        Legend gave this quarrel two faces, Merlin and Morgan le Fay, and in doing so proved
        that one word, magic, had been stretched over two arts. He read the sky and arranged
        what would happen; she worked flesh and earth and changed what was. He was never in the
        room when she came for him, and she was never where his reckoning looked. The Registry
        files Morgan herself as an Enchantress, but the war the legend tells is the war of
        these two arts, and neither won it: Camelot fell between them.
      cipher: >-
        The Wizard works on likelihood (the First Tier); the Witch works on matter and chemistry
        (the Second). Neither can target the other well. A Wizard's predictions lose track of a
        body that changes, and a Witch cannot catch someone whose every path has been made
        unlikely to cross hers. The legend of Merlin and Morgan le Fay is the classic case,
        although the Registry files Morgan as an Enchantress rather than a Witch.
  - archetype: sorcerer
    note:
      almanac: >-
        The Sorcerer has by birth what the Wizard earns by study, and spends it without
        counting. One builds a working stone by stone; the other breaks from the ground like a
        spring. The world confuses them because both may carry a wand.
      cipher: >-
        A Sorcerer's body generates force; a Wizard's never does. A Wizard calculates and waits
        for circumstance, while a Sorcerer acts at once and pays for it physically. Fiction
        often calls born practitioners wizards; the Registry files them by mechanism.
cipher: |-
  Being: a baseline human, with no inherited capacity. Source: the First Tier. Access: calculation.

  A Wizard's power is entirely learned, and none of it is the Wizard's own. The First Tier governs probability. A Wizard studies the formulae that describe it until they can work out exactly which small, ordinary event, at which place and moment, would produce the result they want. They then speak the formula through the staff, aimed at that place, and the First Tier makes that event more likely until it happens. The Wizard supplies the calculation and the aim; the First Tier supplies the change. Staffs, spellbooks and incantations are instruments of accuracy, not stores of power.

  Because the First Tier does not act on matter, a Wizard never produces force directly. Every visible effect is an ordinary physical event made probable at the chosen time: a fireball is leaking marsh gas and a lightning strike made to arrive together, not a flame thrown from the hand. A character who produces force from the body, especially as an untrained child, is a Sorcerer, whatever the story calls them.

  Limits: results need time and suitable circumstances, so a Wizard is weakest in sudden physical danger. Large calculations exhaust the practitioner, and errors go wrong unpredictably. Bodies that change their own pattern (Tier III Alpha) cannot be tracked by calculation.
---

The Wizard was born with nothing. No old blood stirs in those veins, no bargain was struck below, no mushroom or vine opened the door. There are only the desk, the candle and the sky's long tables, learned figure by figure over the better part of a life, until at last the Vault will answer.

What the tables teach is that the sky does not push; it disposes. Every hour holds a great many morrows, and the Vault chooses among them by likelihood, as a river chooses its course by the lie of the land. The Wizard learns to read that lie, and then to ask, in the sky's own figures, that it be altered by a hair: a word spoken at the right hour, a staff set down on the right stone, and the Vault, so asked, leans. What follows looks like wonder. It is arithmetic carried through to its end.

So the Wizard throws no fire. Where the Sorcerer hurls flame from the open palm, the Wizard waits for the marsh to breathe out its foul air and the storm to strike in the same instant, having arranged that both should come together. The flame is the same; the art is altogether different, and the Registry files the two apart, whatever their robes and wands may say.

This is why so many who are called wizards are not. A child who shatters a window in a fit of temper was born to power, and is a Sorcerer however long the beard grows afterwards. The true Wizard is known by a single sign: unlearn every page, and an ordinary mortal is all that remains, while a Sorcerer stripped of every lesson would still burn.

The art keeps a hard account. It is slow, and a working that must wait upon circumstance is of no use once the blade is already falling. It is heavy, for great sums fill the mind until the body sickens under them. And it is blind to whatever keeps no steady pattern: the changeling who wears a new face every hour, and the heart that chooses the unlikely thing for love.
