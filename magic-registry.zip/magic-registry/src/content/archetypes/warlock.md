---
stage: written
name: Warlock
aliases: []
realm: mantle
axis: -75
beings: [baseline-human]
access: covenant
sigil: warlock
identity:
  material: contract parchment, iron and wax
  palette: [contract parchment, iron grey, sulfur, signet crimson]
  geometry: binding-seals
  motion: contract-writes
  layout: numbered-clauses
  interaction: red-ink-signature
  typeAccent: blackletter clause heads
  entrance: unroll-and-stamp
  cursor: crimson-nib
  initial: chained-blackletter
  sound: quill-and-clasp
epithet: Signatory to the Deep
cipherTitle: Contracted agent of the Second Tier
thesis:
  almanac: >-
    The Warlock was born with nothing, learned nothing and brews nothing, and holds great power
    all the same, because a power under the earth has lent it in return for service and a debt
    that will one day be called.
  cipher: >-
    A Warlock is an ordinary person who has made a Covenant with an agent of the Second Tier,
    receiving protection, force or long life in exchange for work on the surface and a final
    payment.
tropes:
  - the pact signed in blood at midnight
  - the deal made at a crossroads
  - a patron who is never quite seen
  - ten years of fortune, and then the hounds
  - the soul as the price
  - the loophole that saves the clever, and the clause that damns the rest
instruments:
  - object: The contract
    almanac: >-
      Written in a hand no clerk on earth ever learned, and signed in the one ink that cannot
      be forged. Every power the Warlock has is a clause in it, and so is every debt.
    cipher: >-
      The terms of the Covenant. They define exactly what the Warlock receives and owes, and
      they are enforced literally. The Warlock's power extends no further than the text.
  - object: The crossroads
    almanac: >-
      Where two roads meet in the dark, far from any church, something may be called up to
      bargain. A box is buried in the dust, a name is spoken, and the patron's servant comes
      walking up the road.
    cipher: >-
      A place for opening negotiation. The Warlock has no standing power to reach the Second
      Tier; a prescribed ritual at a prescribed kind of place makes contact, and the agent
      comes to the Warlock.
  - object: The signet
    almanac: >-
      An iron ring, or a mark burned into the palm. Pressed to wax, or to the ground, it tells
      the patron that a clause is being called upon.
    cipher: >-
      A token issued under the Covenant. Using it signals a request to the agent, which then
      acts; the Warlock performs nothing personally.
costs:
  - almanac: >-
      The debt is called. Ten years, twenty, a lifetime: the term runs out, and what was
      pledged is taken, usually the life, and sometimes more than the life.
    cipher: >-
      Every Covenant has a term and a final payment, typically the Warlock's life. The
      Warlock cannot renegotiate once the term ends.
  - almanac: >-
      The work is owed. The patron has errands on the surface: wild ground to be smothered,
      iron and blood to be gathered, the houses of the sky's servants to be troubled. A
      Warlock who idles is reminded.
    cipher: >-
      The Covenant requires service on the surface in the Second Tier's interest, such as
      paving over living ground, gathering iron and blood, or disrupting the First Tier's
      agents. Neglecting the service ends the protection.
  - almanac: >-
      The letter of the bond. The patron gives exactly what was written and not one grain of
      what was meant, and has read more contracts than any Warlock has.
    cipher: >-
      The terms are applied literally by an agent that drafted many before. Ambiguity is
      resolved against the Warlock.
blindSpots:
  - almanac: >-
      The Paladin. A blow sent from below against one whom the sky has taken under its favour
      goes astray like every other blow, and the patron does not refund the asking.
    cipher: >-
      Force applied by the Second Tier is still harm, and probability shielding deflects it.
      A Warlock cannot reliably strike a Paladin who is serving the First Tier's purpose.
counterparts:
  - archetype: paladin
    note:
      almanac: >-
        Both may walk out of a slaughter without a scratch, and the crowd cannot tell them
        apart. But the Paladin was spared because the sky would have the vow kept, and the
        Warlock because the deep was paid. The Paladin can lose the favour only by betraying
        it; the Warlock loses the protection on a date already written down.
      cipher: >-
        Both can be protected from harm, on opposite terms. The Paladin's field comes from the
        First Tier and lasts while the Paladin serves its purpose; the Warlock's protection
        comes from the Second Tier under a Covenant and lasts until the term ends or the
        service lapses.
  - archetype: sorcerer
    note:
      almanac: >-
        The Sorcerer was born with power and the Warlock bought it, and that is the whole of the
        difference, but it is everything. The Sorcerer's gift cannot be taken away, and
        neither can its cost. The Warlock's power can be withdrawn, and the price was agreed in
        advance. Asked how a practitioner came by the fire, the Registry has its answer.
      cipher: >-
        Power that is inherited belongs to the Sorcerer; power that is granted under contract
        belongs to the Warlock. A Sorcerer produces effects from their own body. A Warlock
        produces none, and the agent of the Second Tier acts on the Warlock's request.
cipher: |-
  Being: a baseline human. Source: the Second Tier, by agreement. Access: Contract.

  A Warlock has no inherited capacity, no learned technique and no prepared substances. The power is borrowed. Through a prescribed ritual at a prescribed kind of place, the Warlock makes contact with an agent of the Second Tier and agrees terms: a Covenant. The agent then supplies what was agreed, which may be physical protection, force applied on request, wealth and standing, or a prolonged life.

  The Warlock pays in two ways. During the term the Warlock serves the Second Tier's interests on the surface: smothering living ground that carries the Grid, gathering iron and blood, and disrupting the First Tier's agents. At the end of the term a final payment falls due, usually the Warlock's life.

  The Warlock does not perform the effects. When the Warlock invokes a clause, the agent acts, often from deep underground: the ground shakes, the floor gives way, a blow is turned. This is why a Warlock can achieve great force from an ordinary body.

  Limits: the power is only what the terms specify, read literally. It can be withdrawn if the service lapses. The final payment cannot be avoided except through flaws in the text. Force from below is still harm, and probability shielding turns it aside.
---

The Warlock is the one practitioner who began with nothing. No blood of the deep runs in the Warlock's veins; no book was mastered and no pot was ever tended. A Warlock is an ordinary person who went at night to the place where roads cross, called up something that was waiting beneath it, and struck a bargain.

The bargain is the whole of the art. What lives under the Mantle is old and patient, and it wants hands on the surface. In return it lends what it has: a skin that blades turn from, a word that makes the floor fall away, fortune, rank, a lifespan longer than the others in the churchyard. The Warlock speaks, and something far below answers. Every power is a clause, and every clause was written by the other side.

The service is not light. A Warlock owes errands: wild ground smothered under stone, iron and blood gathered, the works of the sky's servants troubled. A Warlock who forgets is reminded. And beneath the service runs the term, ten years or twenty or a long life, at the end of which the debt is called and the hounds come down the road.

Some Warlocks are clever. They read every line, find the word that can be bent, and set one creditor against another until both are ruined and the Warlock walks away. The Registry records such escapes, and records how rare they are.

What a Warlock cannot do is strike against the sky's own favour. A blow from the deep is still a blow, and one aimed at a Paladin in the midst of the vow goes astray like all the rest.
