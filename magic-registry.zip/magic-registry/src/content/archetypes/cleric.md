---
stage: written
name: Cleric
aliases: [Priest]
realm: sealed
axis: 100
beings: [baseline-human]
access: broadcast
sigil: cleric
identity:
  material: gold leaf, stained glass and clean vellum
  palette: [white, aureate gold, lapis]
  geometry: radial-rays
  motion: light-shafts
  layout: cathedral-symmetry
  interaction: light-pools
  typeAccent: Cinzel uncials
  entrance: dawn-window
  cursor: soft-halo
  initial: gilded-lapis-capital
  sound: choral-tone
epithet: Bearer of the Sealed Light
cipherTitle: Vetted carrier of a restorative signal
thesis:
  almanac: >-
    The Cleric is an ordinary mortal entrusted with a light that no one may study, brew or buy,
    and through whose hands the flesh is returned to the shape it was first made in.
  cipher: >-
    A Cleric is a baseline human permitted to relay the Sealed Broadcast, which restores living
    tissue to its original pattern and undoes what the other Tiers have done to it.
tropes:
  - vestments, a mitre or a plain grey habit
  - a holy symbol raised against the dark
  - healing by the laying on of hands
  - turning back the walking dead
  - blessings, prayers and holy water
  - the village priest who is braver than the knights
instruments:
  - object: The holy symbol
    almanac: >-
      Not a key but a seal of office: a sign worn at the breast to show what light its bearer
      answers to, as a herald's tabard shows a house. It opens nothing of itself, and in a
      thief's hand it is only silver.
    cipher: >-
      An emblem of permission. It marks the carrier to the Sealed Tier and gives the relay a
      point to issue from, but it holds no power of its own; a stolen symbol does nothing.
  - object: The laying on of hands
    almanac: >-
      The light passes as warmth passes, palm to brow, and where it goes the flesh remembers
      itself. The touch is the narrowest of doors, so that what comes through falls on one body
      and on no other.
    cipher: >-
      Contact concentrates the relay on a single body, so the restoration acts there and nowhere
      else. Without contact the effect is weaker and less exact.
  - object: Holy water
    almanac: >-
      Water that has stood in the light until it carries a little of it, as a stone keeps the
      sun's warmth after dusk. It soothes the whole and scalds whatever the deep has made.
    cipher: >-
      Water exposed to the Sealed Broadcast keeps a trace of it for a time. On tissue altered by
      the Second Tier it reverses the alteration, painfully; on healthy tissue it does nothing.
costs:
  - almanac: >-
      Worthiness, kept daily. The light is lent and never given, and a Cleric who turns it to
      cruelty or to gain wakes one morning to find that the hands are only hands.
    cipher: >-
      Access is conditional and can be withdrawn. A carrier who misuses the Sealed Broadcast
      loses the ability to relay it, without warning and without appeal.
  - almanac: >-
      Nothing for the asking. The light will not lift a cup, open a lock or strike a foe who is
      merely a foe; it mends, and it burns only what is corrupt.
    cipher: >-
      The relay has one function: restoring tissue and undoing corruption. It cannot be turned
      to force, persuasion or prediction.
  - almanac: >-
      The vessel tires. A long night in the plague-house empties the Cleric as surely as it
      fills the beds with the mended.
    cipher: >-
      Relaying strains the carrier's body. Long or repeated healing leaves the Cleric exhausted
      and, in the end, ill.
blindSpots:
  - almanac: >-
      Clean malice. A healthy villain with a knife has nothing in him for the light to mend or
      to burn, and before him the Cleric must stand aside or call for a shield.
    cipher: >-
      The Sealed Broadcast acts only on injury and corruption. An uncorrupted attacker is
      unaffected by it, so a Cleric depends on others for protection.
counterparts:
  - archetype: paladin
    note:
      almanac: >-
        They stand side by side in every chapel window and are mistaken for one another in
        every song, but they keep different gifts. The Cleric carries a light that heals what it
        touches; the Paladin wears a favour that turns aside what would touch him. One walks
        into the plague-house, and the other walks into the battle a step ahead of the first.
      cipher: >-
        Both act for the upper sources, by different means. The Cleric relays the Sealed
        Broadcast, which restores tissue; the Paladin stands inside a First Tier field that makes
        harm improbable. The Cleric heals and cannot defend; the Paladin defends and cannot
        heal.
  - archetype: necromancer
    note:
      almanac: >-
        The two ends of the long axis meet over the same body. Where the Necromancer sets a
        corpse walking on strings drawn from the deep, the Cleric's light reaches it and gives
        it back its rest: the flesh remembers the shape it was made in, and that shape never
        walked after death. They cannot share a room for long.
      cipher: >-
        The Necromancer moves dead tissue through the Second Tier. The Sealed Broadcast returns
        tissue to its original pattern, and that pattern does not include being driven from
        outside, so a reanimated corpse within reach of the relay stops and falls.
cipher: |-
  Being: a baseline human, vetted. Source: the Sealed Tier. Access: the Sealed Broadcast.

  A Cleric generates nothing and calculates nothing. The Sealed Tier is a closed source above the First Tier; it cannot be reached by study, chemistry, inheritance or contract, and it answers only to carriers it has accepted. Those carriers relay it. The Cleric's part is to remain acceptable and to place the relay where it is needed: a hand on a wound, a symbol raised over a body, water carried into a sickroom.

  What the Sealed Broadcast does to living tissue is restore it to its original, uncorrupted pattern. An infection clears, a wound closes and a growth recedes, because none of them belonged to the body as it was first made. Tissue that the Second Tier has altered, such as the flesh of a reanimated corpse or a body changed by the deep, is returned to its pattern too, and for those bodies the return is destructive. That is the whole of what fiction calls holy light: not heat and not force, but correction.

  Limits: the relay has a single function and cannot be redirected to move objects, compel minds or predict events. It acts only on injury and corruption, so a healthy attacker is unaffected. Access can be withdrawn without warning from a carrier who misuses it, and relaying tires the body.
---

No one reaches the Sealed Light. It reaches down, and it chooses. The Cleric is one whom it has found: an ordinary mortal, no older in blood than the miller or the ploughman, who has been weighed and judged fit to carry what cannot be made.

For the light above the Vault keeps its own counsel. The Wizard may reckon the sky and the Witch may brew the soil, but no sum unlocks this light, no cup holds it, and no bargain buys an hour of it. It is a hymn sung closed, whose words are known only to the choir, and it is lent to those who keep faith with it, from hand to hand down the long line of the entrusted.

What it does, it does to the flesh, and it does one thing only: it remembers. Laid on a wound, it recalls the skin as it was before the blade; laid on a fever, it recalls the blood before the sickness came. Nothing is added and nothing is forced. The body is shown its first pattern and returns to it, as a bent bough springs upright when the snow slides off.

So the light is gentle with the living and terrible to what the deep has made. A body worked from below, whether a corpse walked on strings or a face remade by the Mantle, has no first pattern that includes such workings. Shown the light, it unmakes them, and that unmaking is the fire the old painters set about the priest's raised hand.

The office has plain rules. The light will not lift a cup or open a door, and against a healthy foe with a knife it is no use at all. It is lent and not given, and those who turn it to their own ends wake one morning with empty hands. The Cleric carries it as a candle is carried down a draughty nave: with care, for others, and never long enough to forget whose flame it is.
