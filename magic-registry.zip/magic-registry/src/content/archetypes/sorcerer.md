---
stage: written
name: Sorcerer
aliases: []
realm: threshold
axis: 0
axisNote: oscillating
beings: [tier3-gamma, tier3-alpha]
access: bloodline
sigil: sorcerer
identity:
  material: scorched paper with veins of light
  palette: [white-hot core, ember, arterial red, char]
  geometry: lichtenberg-branching
  motion: charge-and-flare
  layout: cracked-containers
  interaction: static-flare
  typeAccent: Cormorant Garamond bold, scorched and set slightly off its baseline
  entrance: light-crack
  cursor: crackling-ember
  initial: burned-capital
  sound: static-and-thrum
epithet: The Fire in the Blood
cipherTitle: Born generator of force
thesis:
  almanac: >-
    The Sorcerer studied nothing, brewed nothing and signed nothing, and still the lightning
    comes, because the power was born in the blood and runs there whether it is wanted or not.
  cipher: >-
    A Sorcerer is a Tier III being whose own body generates force, electrical or kinetic,
    without tools, study or contract, at a heavy and growing cost to that body.
tropes:
  - lightning from the fingertips
  - power that wakes in anger or fear
  - a bloodline of mages, or one born without warning
  - the child who breaks things without touching them
  - the mad king
  - the bleeding nose after a great working
instruments:
  - object: The hand
    almanac: >-
      Open, or clenched, or flung out toward the thing that must break. It is not a tool so
      much as a direction; the force goes where the hand has pointed it.
    cipher: >-
      Gesture serves to aim and steady the release. The force is produced inside the body; the
      hand directs it and helps the Sorcerer control when it goes.
  - object: The wand
    almanac: >-
      The world puts one into every Sorcerer's hand, and it is a fine thing of holly or yew. It
      steadies the aim and calms the nerves. It has never yet made a Sorcerer, and a Sorcerer
      who loses it is not one whit the weaker.
    cipher: >-
      A focusing aid adopted by custom. It may help with precision and confidence, but it adds
      no power: a Sorcerer without one can still act, and an ordinary person with one cannot.
  - object: The family tree
    almanac: >-
      Kept in the great houses on a long scroll, with the gifted marked in red, and studied
      before every marriage. It is the nearest thing the Sorcerer has to a book.
    cipher: >-
      The capacity is inherited, though it can skip generations or appear without a known
      ancestor. Families with the trait track it, because it cannot be acquired any other way.
costs:
  - almanac: >-
      The body pays for every bolt. Blood runs from the nose, the eyes go dark, and after a
      great working the Sorcerer may lie a day and a night as if dead.
    cipher: >-
      Generating force strains the body directly. Bleeding, exhaustion and collapse follow
      heavy use, and repeated strain causes lasting damage.
  - almanac: >-
      The mind pays too. The old chronicles are full of kings with fire in the blood who began
      wise and ended raving, and the Registry does not think this an accident.
    cipher: >-
      A human body carrying this capacity is under constant strain, and long use is associated
      with instability of mood and judgement, sometimes ending in madness.
  - almanac: >-
      It cannot be laid down. Fear wakes it, and grief, and rage; a Sorcerer in a passion is a
      danger to the very people standing nearest.
    cipher: >-
      The capacity responds to strong emotion and can release without intent. Control must be
      learned and is never complete.
blindSpots:
  - almanac: >-
      The fine and the far. The Sorcerer can break a door, a wall or a heart, but cannot mend a
      thread, foretell a single hour, or reach what the eye cannot find.
    cipher: >-
      The capacity produces force, not precision or knowledge. A Sorcerer cannot calculate
      chance, foresee events or act on a target that cannot be perceived.
counterparts:
  - archetype: wizard
    note:
      almanac: >-
        The Wizard earns by study what the Sorcerer was given at birth, and spends it by the
        grain where the Sorcerer spends it by the bucket. One builds a working stone by stone
        and checks every sum; the other breaks out of the ground like a spring and cannot be
        stopped. Both may carry a wand, and that is why the world confuses them, and why the
        Registry sorts by where the power came from and not by what was in the hand.
      cipher: >-
        The Wizard has no innate power and works by calculation through the First Tier, with
        precision and little force. The Sorcerer produces raw force from the body, with no study
        and little precision. A wand indicates neither: what separates them is whether the
        power was learned or inherited.
  - archetype: warlock
    note:
      almanac: >-
        The Sorcerer was born with power and the Warlock bought it, and that is the whole of the
        difference, but it is everything. The Sorcerer's gift cannot be taken away, and neither
        can its cost. The Warlock's can be withdrawn, and its price was agreed in advance.
      cipher: >-
        Inherited power belongs to the Sorcerer; power granted under contract belongs to the
        Warlock. A Sorcerer produces effects from their own body. A Warlock produces none, and
        an agent of the Second Tier acts on the Warlock's request.
cipher: |-
  Being: Tier III, usually Gamma, sometimes Alpha. Source: none outside the body; the Unaligned. Access: Inherited capacity.

  A Sorcerer is born able to generate force. The Tier III body, often human in appearance, carries an inherited capacity that the ordinary human body lacks: the nervous system can produce large electrical discharges, and can push or pull matter at a distance. No study, preparation, ritual or contract is involved. The capacity usually wakes in childhood or adolescence, often in a moment of fear or anger.

  This is the power fiction most often calls magic, and the Registry files much of fiction's magic here. Any practitioner whose ability is inherited, who can act without learning and without tools, and who is born into a world divided between those who have the power and those who do not, is a Sorcerer, whatever the work calls them.

  The cost is paid by the body. Heavy use causes bleeding, exhaustion and collapse, and long use is associated with instability and, in the worst cases, madness. The capacity responds to emotion and can discharge without intent.

  Limits: the power is force, not knowledge or precision; a Sorcerer cannot calculate chance, foresee events or affect what cannot be perceived. Every use costs the Sorcerer's own body. It cannot be given up, lent or taught.
---

The Sorcerer is the one the old stories mean when they speak of magic, and the one they most often misname. There is no book behind the Sorcerer, no pot, no bargain struck at a crossroads. There is only the blood, and something in it that was there before the first word was learned.

It wakes early, and seldom gently. A child is frightened, or furious, and the windows burst; a girl is cornered, and the man who cornered her is flung against the wall. After that it can be trained, as a horse is trained, but never quite broken. The force comes out of the Sorcerer's own body, as lightning from the fingers, as a blow that falls without a hand, and it goes where the Sorcerer's will points it.

The cost is paid in the same coin. Blood runs from the nose after a great working, the knees give way, and the Sorcerer may sleep like the dead for a day. Over a lifetime the strain tells on the mind as well as the body. The chronicles are full of kings with fire in their veins who began as wonders and ended in madness, and the Registry thinks the two facts belong together.

Much that the world calls wizardry is this. Whenever a story divides people into those born with the gift and those born without it, whenever power bursts out of a child who has never opened a book, the Registry looks past the robe and the wand and files a Sorcerer. The Wizard learns; the Sorcerer is born. A wand in the hand changes nothing.

What the Sorcerer cannot do is the subtle thing. The fire can break any door, but it cannot foretell which door will open, or mend what it has broken, or find a foe who is not in sight. It is strength, only strength, and it is paid for in flesh.
