---
stage: written
name: Bard
aliases: []
realm: mantle
axis: -35
beings: [baseline-human]
access: resonance
sigil: bard
identity:
  material: walnut, velvet and score paper
  palette: [crimson velvet, walnut, gilt]
  geometry: chladni-stave
  motion: resonant-ripple
  layout: verse-stave
  interaction: pluck-string
  typeAccent: EB Garamond swash italic, set to the stave
  entrance: string-plucked
  cursor: resonant-waveform
  initial: stave-woven-capital
  sound: lute-note
epithet: Master of the Hidden Note
cipherTitle: Acoustician of body, mind and matter
thesis:
  almanac: >-
    The Bard has learned that every thing, a goblet, a wall, a heart, has a note of its own,
    and that the right note, sung or struck, will shake it until it gives way.
  cipher: >-
    A Bard is an ordinary person who uses precisely produced sound to act on objects through
    resonance and on people through the body's responses to pitch, rhythm and very low
    frequencies.
tropes:
  - the travelling minstrel with a lute
  - the song that stirs an army to courage
  - the lullaby that sends a hall to sleep
  - the satire that ruins a king
  - the note that shatters a goblet
  - the charming rogue with a silver tongue
instruments:
  - object: The lute
    almanac: >-
      Walnut and gut, and tuned by no rule of any guild. Each string can be drawn up or let
      down until it finds the one pitch that the thing across the room was waiting for.
    cipher: >-
      A finely adjustable source of tones. The Bard tunes it to the resonant pitch of a target
      object or to rhythms and intervals that affect a listener's mood and attention.
  - object: The trained voice
    almanac: >-
      Years of practice at the edge of the sea, singing against the wind, until one breath can
      fill a cathedral or thread through a keyhole to a single ear.
    cipher: >-
      A voice trained for precise pitch, sustained tone and volume. Used alone, it can drive
      resonance, carry suggestion in rhythm, and be directed at one listener in a crowd.
  - object: The great drum
    almanac: >-
      So low that it is felt more than heard, and played softly. Those who stand near it grow
      dizzy and afraid, and cannot say of what.
    cipher: >-
      A source of very low frequencies, below or near the bottom of human hearing. These act on
      the inner ear and the eye, causing dizziness, blurred vision and unexplained fear.
costs:
  - almanac: >-
      The ear wears out. A lifetime of hunting notes leaves the Bard ringing in the night and
      deaf before old age.
    cipher: >-
      Long exposure to loud and very low sound damages the Bard's own hearing. Most Bards lose
      it in later life.
  - almanac: >-
      The note is no respecter of persons. What is sung to make one man afraid makes every man
      in hearing afraid, the Bard's friends along with the foe.
    cipher: >-
      Sound spreads to everyone within range. Effects aimed at one target reach others nearby,
      including allies, unless the Bard has positioned them carefully.
  - almanac: >-
      It must be heard. A shuttered window, a clamour of bells or a gale off the sea can steal
      the song before it reaches its mark.
    cipher: >-
      Distance, barriers and competing noise weaken or block the effect. The Bard needs a
      clear acoustic path to the target.
blindSpots:
  - almanac: >-
      The stopped ear and the empty head. A sailor with wax in his ears hears nothing, and the
      Necromancer's dead, whose ears serve no one, cannot be frightened or soothed.
    cipher: >-
      Effects on a mind need a working inner ear and a living brain. A deafened target, or a
      reanimated body, is unaffected except by resonance strong enough to break bone.
counterparts:
  - archetype: enchantress
    note:
      almanac: >-
        Both win with the voice, and the ear cannot tell them apart. The Bard learned the note
        that shakes a heart and could teach it to an apprentice; the Enchantress was born with a
        throat that sings it, and no one could learn her song. The Bard plays upon the listener,
        and the Enchantress becomes the thing the listener longs for.
      cipher: >-
        Both use sound to act on a listener. The Bard is an ordinary person using learned
        acoustics; the Enchantress is Tier III and combines voice with scent and physical
        change. A Bard's effect is in the sound alone, so it can be recorded, taught and
        repeated.
  - archetype: alchemist
    note:
      almanac: >-
        Two ordinary people who would not wait to be born gifted or to sign anything. The
        Alchemist took the world apart in a furnace; the Bard listened to it until it
        confessed its notes. Both learned their craft as a trade is learned, and both can be
        undone by a single wrong measure.
      cipher: >-
        Both are ordinary people with learned techniques and no inherited capacity or
        Covenant. The Alchemist works through Experiment with substances; the Bard works
        through Acoustics with sound. Both depend on precise measurement.
cipher: |-
  Being: a baseline human. Source: the Second Tier, through vibration. Access: Acoustics.

  The Second Tier governs mass, pressure and vibration, and every physical thing vibrates most easily at certain pitches, its resonant frequencies. A Bard is trained to find those pitches and produce them precisely, with an instrument or the voice. Sustained at the right pitch and volume, the sound drives an object to vibrate until it fails: glass cracks, mortar loosens, a string snaps.

  People respond to sound as well. Rhythm and interval change mood, attention and courage, which is why a march steadies a column and a lullaby quiets a room. Very low frequencies act directly on the inner ear and the eye, producing dizziness, blurred vision, nausea and fear with no apparent cause. A skilled Bard combines these to frighten, calm, rally or disorient.

  None of this requires belief or consent. The effect is in the sound, so it can be taught, written down and repeated by anyone with the training.

  Limits: the effect needs a clear path to the target and weakens with distance, walls and noise. Sound reaches everyone in range, not only the target. Deafened listeners and reanimated bodies are unaffected except by force strong enough to break them. Long practice damages the Bard's hearing.
---

Every thing in the world has a note of its own. Strike a goblet with a fingernail and it sings it; a bell sings it louder, and a stone wall, if it could be struck hard enough, would sing it too. The Bard is one who has spent a lifetime learning to hear those notes, and to sing them back.

Sung back, they do work. A goblet held at its own pitch trembles, then rings, then flies apart. A doorway can be made to shed its mortar. And people have notes as well, though not in their glass: the rhythm that steadies a frightened column, the interval that makes a hall weep, the deep thrum below hearing that turns the stomach and fills a brave man with a terror he cannot name.

The Bard is reckoned a wanderer, a teller of tales and a charmer at the table, and is all of these. But the lute is tuned by ear to whatever stands across the room, and the drum at the Bard's side is played too low for a feast. The craft is in the measure: the right note, at the right strength, held for the right count.

It is a learned art, and a physical one. Nothing comes from the sky and nothing is borrowed; the Bard was born like anyone else and simply listened harder. That is also its weakness. A note must be heard, and wax in the ears, a gale or a shuttered window will stop it. It strikes every ear in reach, friend and foe alike. And it spends the hearing of the one who makes it, so that most old Bards play by memory and by touch.
