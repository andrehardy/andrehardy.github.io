---
stage: written
name: Shaman
aliases: []
realm: vault
axis: 55
beings: [baseline-human]
access: ingestion
sigil: shaman
identity:
  material: hide, ochre and smoke
  palette: [smoked hide, ochre, smoke, vision cyan]
  geometry: entoptic-rings
  motion: drumbeat-pulse
  layout: radial-drum
  interaction: trance-deepens
  typeAccent: IM Fell English roman, letterspaced and set around circular baselines
  entrance: drum-strike
  cursor: ochre-handprint
  initial: entoptic-capital
  sound: frame-drum-and-breath
epithet: Listener at the Opened Door
cipherTitle: Perceiver by the Keys of Ingestion
thesis:
  almanac: >-
    The Shaman is an ordinary mortal who eats the sky's key, and with the walls of the self
    thrown down hears all that the Vault knows, though the hands that sit by the fire can move
    nothing.
  cipher: >-
    A Shaman is a baseline human who consumes Keys of Ingestion to perceive the First Tier
    directly, gaining knowledge of causes and outcomes but no power over matter.
tropes:
  - a frame drum, a rattle and a fire
  - the spirit journey
  - the sacred mushroom, cactus or vine
  - trance, chant and dance
  - speaking with ancestors
  - animal guides
instruments:
  - object: The key
    almanac: >-
      The sacrament itself, gathered in its season and taken in its measure: too little, and the
      door stays shut; too much, and the traveller does not come home.
    cipher: >-
      The ingested compound suspends the mind's ordinary filters so that the First Tier can be
      perceived. The dose is narrow: too little does nothing, too much injures the body.
  - object: The drum
    almanac: >-
      A steady beat to walk out on and to walk home by. While the body sits by the fire, the
      drum is the road the self follows back.
    cipher: >-
      Rhythm anchors the practitioner during perception. It gives the mind a fixed point to
      return to and lowers the risk of losing the way.
  - object: The watcher at the fire
    almanac: >-
      The one who stays: a second at the hearth who keeps the body warm, keeps the drum going,
      and calls the name when the night grows long.
    cipher: >-
      A sober attendant guards the practitioner's body, which is helpless during the trance, and
      can draw the practitioner out if the dose goes wrong.
costs:
  - almanac: >-
      The body left behind. While the Shaman listens, the flesh sits by the fire like an empty
      coat, and anything at all may come up to it.
    cipher: >-
      During perception the practitioner is physically helpless and unaware of the room.
  - almanac: >-
      The venom in the key. Every sacrament is a little poison, and taken often it eats at the
      liver, the heart and the sleep.
    cipher: >-
      The compounds are toxic. Repeated use damages the body and, over time, the mind.
  - almanac: >-
      Too much seen. The Vault knows more than one mind can hold, and some who listen too long
      come home with a stranger's eyes.
    cipher: >-
      The First Tier carries more than a human mind can order. Overload can cause lasting
      confusion or madness.
blindSpots:
  - almanac: >-
      Anything that must be done. The Shaman may see the falling stone, the hidden road and the
      traitor's purpose, and cannot lift a finger against any of them until the trance is over,
      by which time the moment has often gone.
    cipher: >-
      Perception is not action. A Shaman can know what is about to happen and has no means to
      affect it, and what is learned in a trance can only be acted on afterwards, often too
      late.
counterparts:
  - archetype: druid
    note:
      almanac: >-
        Both answer to the living web beneath the forest, and both are taken for earth-folk
        because they smell of leaf and smoke; both, in truth, draw from the sky. The Shaman
        opens the self to the web and listens. The Druid lays a hand upon it and gives it work.
        One comes home with knowledge, the other leaves a changed grove.
      cipher: >-
        Both draw on the First Tier through the Grid, not on the Second Tier, despite their
        earthly look. The Shaman perceives through the Grid and changes nothing; the Druid
        directs it to act on living things. The Shaman knows, and the Druid does.
  - archetype: alchemist
    note:
      almanac: >-
        The Alchemist has heard of the key too, and spends years in a cellar trying to distil
        it from salts and spirits. What comes out of the alembic opens the door a crack,
        roughly and at a cost; what grows in the meadow opens it as it was meant to be opened.
      cipher: >-
        The Alchemist tries to synthesise compounds that imitate the Keys of Ingestion. The
        synthetic versions are cruder and more dangerous. The Shaman uses the natural keys,
        prepared by long tradition.
  - archetype: necromancer
    note:
      almanac: >-
        Both are said to speak with the dead, and only the Shaman does. The ancestors have gone
        up into the sky's keeping, and the Shaman, with the walls down, can hear them there. The
        Necromancer stays below with the bodies they left behind, which can be made to walk, and
        which keep for a little while a few fading scraps of memory, but never the person.
      cipher: >-
        What made a person is held by the First Tier after death, where a Shaman in trance may
        perceive it. The remaining body belongs to the Second Tier's domain, which is all a
        Necromancer can work; it holds only short-lived fragments of memory. The Shaman perceives
        the record, the Necromancer the residue, and neither reaches what the other reaches.
cipher: |-
  Being: a baseline human. Source: the First Tier. Access: Keys of Ingestion.

  The Shaman draws from the sky, not the earth, despite the hide, the smoke and the roots. The First Tier carries knowledge of causes, outcomes and the past, and it runs through the Grid, the fungal web in living things. Certain organic compounds, the Keys of Ingestion, suspend the mind's usual filters when consumed, and with those filters down a human mind can perceive what the First Tier carries.

  What returns from a trance is knowledge: where a lost herd has gone, what is wrong inside a sick body, what a stranger intends, what happened in a place long ago. Fiction calls the sources of that knowledge spirits and ancestors; the Registry treats them as the First Tier's record, perceived by a mind opened to it.

  The access is perception only. A Shaman in trance moves nothing and is physically helpless, and anything learned can only be acted on afterwards, by ordinary means.

  Limits: the compounds are toxic and the dose is narrow. Overload can damage the mind for good. The body is defenceless during the trance and needs a guard. This entry describes the practitioner of fantasy and fiction; it makes no claim about real traditions of healing or worship that share the name.
---

The Shaman eats the key and the walls come down. That is the art, all of it, and it is older than the oldest book.

The key is a plain thing: a mushroom cap gathered in the wet of autumn, a bitter root, a vine boiled through a day and a night. It comes up out of the earth, and so the Shaman is taken for an earth-worker, kin to the Witch at her cauldron. The Registry files otherwise. The key grows in the soil, but it opens onto the sky. The living web of spore and root that carries it answers to the Vault, and what the Shaman hears, once the walls are down, is the Vault speaking.

What it says is what is known. Where the herd went in the snow. What sits in the sick child's chest. What the stranger at the fire means to do before dawn. The old tellings call the voices spirits and ancestors, and there is truth enough in that, for the Vault forgets nothing and the dead are written in it as plainly as the living.

But the Shaman only hears. The drum beats, the body sits by the fire with its eyes turned up, and the hands lie as still as stones. No storm is called and no enemy struck; whatever the trance reveals must wait for morning and the ordinary use of hand and voice, and often the morning comes too late.

The key takes its price from the body a little at a time, and from the mind all at once, when too much has been seen. So there is always a second at the fire: one who keeps the body warm, keeps the drum going, and calls the traveller home by name.
