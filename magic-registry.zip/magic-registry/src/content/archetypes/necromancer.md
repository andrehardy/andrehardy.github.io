---
stage: written
name: Necromancer
aliases: []
realm: mantle
axis: -90
beings: [baseline-human]
access: reanimation
sigil: necromancer
identity:
  material: bone, grave-earth and tarnished silver
  palette: [bone ivory, tarnished silver, cold verdigris, black]
  geometry: ossuary-anatomy
  motion: string-stutter
  layout: anatomy-plate
  interaction: string-pull
  typeAccent: IM Fell English small capitals on numbered callouts
  entrance: bones-assemble
  cursor: puppet-crossbar
  initial: ossuary-capital
  sound: dry-clicks
epithet: Puppeteer of the Emptied House
cipherTitle: Operator of dead tissue
thesis:
  almanac: >-
    The Necromancer does not call back the dead, who have gone where no art can follow, but raises
    the house they left behind and works it from the deep like a puppet on strings.
  cipher: >-
    A Necromancer is an ordinary person who drives dead bodies with a current drawn from the
    Second Tier, producing crude movement in tissue that no longer holds a person.
tropes:
  - skeletons rising from the grave
  - an army of the dead on the march
  - the black-robed figure in the crypt
  - speaking with the dead
  - the stolen corpse and the anatomist's table
  - a living body wasting as its master's power grows
instruments:
  - object: The silver needle
    almanac: >-
      Long and fine, and driven in where the skull meets the spine. Through it the strings are
      fastened, and the corpse sits up.
    cipher: >-
      A conductor placed at the base of the skull. It carries the current that drives the
      dead nervous system, and without it, or a substitute, the body cannot be worked.
  - object: The grave-mould
    almanac: >-
      A grey bloom scraped from the walls of old tombs and kept in a sealed jar. Sown in a
      fresh corpse, it threads the dead flesh with strings of its own.
    cipher: >-
      A fungus of the Second Tier that grows through dead tissue and carries the current
      without a needle. It lets a Necromancer work many bodies at once, at the cost of faster
      decay.
  - object: The ossuary
    almanac: >-
      Every Necromancer keeps one, and it is the Necromancer's true wealth: shelf upon shelf of
      bone, sorted and numbered like the stock of a careful shop.
    cipher: >-
      A store of remains. A Necromancer's power is limited by the number and condition of the
      bodies available, so supply matters more than skill.
costs:
  - almanac: >-
      The deep takes its toll on the one who draws on it. A Necromancer grows thin, grey and
      cold in the hands, and is old before the age of forty.
    cipher: >-
      Drawing the current through the body damages the Necromancer's own health over time.
      Long practice produces visible wasting.
  - almanac: >-
      The strings must be held. A puppet left untended drops where it stands, and a
      Necromancer leading a host cannot sleep while it walks.
    cipher: >-
      Reanimated bodies have no will or memory to guide them. They move only while the
      Necromancer directs them, and attention is the limit on how many can be worked at once.
  - almanac: >-
      What is raised still rots. Every corpse is a dwindling coin, and a dead army gathered in
      the autumn is a heap of bones by spring.
    cipher: >-
      Reanimation does not stop decay. Tissue continues to break down and eventually cannot be
      moved.
blindSpots:
  - almanac: >-
      The living. A living body is held by its own tenant, and the strings find no purchase in
      it; the Necromancer must first make a corpse, by ordinary means.
    cipher: >-
      A living nervous system overrides the current. A Necromancer cannot work a living person,
      and has to kill them first.
  - almanac: >-
      The Cleric. Under the Sealed Light the dead flesh remembers its first pattern, in which it
      lay still, and every puppet in reach falls at once.
    cipher: >-
      The Sealed Broadcast restores tissue to its original pattern, which does not include
      external driving, so reanimated bodies stop and fall within its reach.
counterparts:
  - archetype: cleric
    note:
      almanac: >-
        The two ends of the long axis meet over the same body. The Necromancer sets a corpse
        walking on strings from the deep, and the Cleric's light finds it and gives it back its
        rest. Neither can make the other's work hold in a room they share, and the dead lie down
        wherever the Cleric goes.
      cipher: >-
        The Necromancer moves dead tissue with a current from the Second Tier. The Sealed
        Broadcast returns tissue to its original pattern, which does not include being driven
        from outside, so reanimated bodies stop and fall in a Cleric's presence.
  - archetype: shaman
    note:
      almanac: >-
        Both are said to speak with the dead, and only one of them does. The Shaman goes up to
        where the dead have gone and hears them; the Necromancer stays below with what they left
        behind. One has the voice without the body, and the other has the body without the
        voice.
      cipher: >-
        When a person dies, what made them a person is held by the First Tier, where a Shaman in
        trance may perceive it. The body that remains belongs to the Second Tier's domain, and
        that is all a Necromancer can work. Neither reaches what the other reaches.
cipher: |-
  Being: a baseline human, worn down by the work. Source: the Second Tier, through dead tissue. Access: Reanimation.

  The Necromancer does not command souls. When a person dies, what made them a person is held by the First Tier, beyond the Necromancer's reach. What stays behind is tissue: a nervous system that no longer runs and muscle that no longer moves.

  The Necromancer drives that tissue from outside. A current drawn from the Second Tier is carried into the dead nervous system, by a conductor at the base of the skull or by a fungus that grows through the body, and the muscles respond. The result is crude movement under direct control: walking, gripping, lifting, striking. The body has no will and no memory of its own while it moves.

  Some traces of memory remain in dead brain tissue for a short time. A Necromancer who consumes or otherwise takes in that tissue may recover fragments of what the person knew. Fiction often presents this as speaking with the dead. It is the reading of residue.

  Limits: only dead tissue can be worked, so a living target must be killed first. Bodies continue to decay. Control lasts only while the Necromancer directs it. The work wears down the Necromancer's own body. The Sealed Broadcast stops reanimated bodies within its reach.
---

The Necromancer is misunderstood by everyone who fears the Necromancer, which is everyone. The dead are not called back. When a life ends, the one who lived it goes up, out of reach of any art practised under the sky, and the Necromancer has never once spoken with a departed soul. What the Necromancer has is the house they left: the bones, the sinews, the cold brain in its case.

That is enough. The deep holds a current that dead flesh will still answer, and the Necromancer knows how to carry it in, by a silver needle at the base of the skull, or by a grey mould sown in the corpse that threads it through like strings. The dead hand closes. The dead knees bend. And the thing gets up and does what it is told, no more and no less, with nothing behind its eyes.

A Necromancer's wealth is counted in bones. The puppets rot as they walk, so there must always be more; they drop the moment they are not watched, so their master hardly sleeps; and the current that moves them moves through the Necromancer first, and wears the living body down to grey and bone.

Some, it is told, eat of the dead to learn what the dead knew. A few memories linger in the brain for a little while after the tenant has gone, and they can be taken in. It is not conversation. It is rummaging through an empty room.

Two things defeat the Necromancer utterly. The living cannot be worked, for their own tenant holds the strings; to use a living foe, the Necromancer must first make a corpse of them in the ordinary way. And the Sealed Light, wherever it falls, sets the dead flesh back in its first pattern, in which it lay still, and every puppet in the room drops.
