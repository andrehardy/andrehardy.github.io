import type { RealmId } from '~/data/palettes';
import type { GLOSSARY_IDS } from '~/data/schemas';

export type GlossId = (typeof GLOSSARY_IDS)[number];

/** The glossary entry for each realm: the realms are named in the glossary in full. */
export const REALM_GLOSS: Record<RealmId, GlossId> = {
  sealed: 'sealed-light',
  vault: 'vault',
  threshold: 'threshold',
  mantle: 'mantle',
};
