/**
 * The sky over the reader (R-SKY-01, R-SKY-02, R-SKY-03, R-SKY-04): sidereal time, where a star
 * stands, the Moon's place and its rising, the planets' mean motions, and when a meteor may
 * fall. Low-precision formulae from Jean Meeus, Astronomical Algorithms (2nd ed.): chapters 12
 * (sidereal time), 13 (horizontal coordinates), 15 (rising), 22 (obliquity) and 47 (the Moon,
 * its principal terms only, good to a few tenths of a degree), and the J2000 mean elements of
 * the planets (Standish, JPL). Ample for an engraved sky; this is not an ephemeris.
 */
import { julianDay } from './astronomy';

const RAD = Math.PI / 180;
const norm = (deg: number) => ((deg % 360) + 360) % 360;
const sin = (deg: number) => Math.sin(deg * RAD);
const cos = (deg: number) => Math.cos(deg * RAD);
const asin = (x: number) => Math.asin(Math.max(-1, Math.min(1, x))) / RAD;
const atan2 = (y: number, x: number) => Math.atan2(y, x) / RAD;

const centuries = (date: Date) => (julianDay(date) - 2_451_545) / 36_525;

/** Greenwich mean sidereal time, in degrees (Meeus 12.4). */
export function siderealTime(date: Date): number {
  const d = julianDay(date) - 2_451_545;
  const T = d / 36_525;
  return norm(280.46061837 + 360.98564736629 * d + 0.000387933 * T ** 2 - T ** 3 / 38_710_000);
}

export interface Observer {
  /** Latitude, degrees north. */
  lat: number;
  /** Longitude, degrees east. */
  lon: number;
}

export interface Horizontal {
  /** Altitude above the horizon, degrees. */
  alt: number;
  /** Azimuth, degrees east of north. */
  az: number;
}

/** Where a body of the given right ascension and declination stands for the observer (Meeus 13). */
export function horizontal(ra: number, dec: number, at: Observer, date: Date): Horizontal {
  const H = siderealTime(date) + at.lon - ra;
  const alt = asin(sin(at.lat) * sin(dec) + cos(at.lat) * cos(dec) * cos(H));
  const az = norm(
    atan2(-cos(dec) * sin(H), sin(dec) * cos(at.lat) - cos(dec) * cos(H) * sin(at.lat)),
  );
  return { alt, az };
}

/** Southern time zones, by the first part of their IANA name or the whole of it. */
const SOUTH =
  /^(Australia|Antarctica|Pacific\/(Auckland|Chatham|Fiji|Tongatapu|Apia|Noumea)|America\/(Argentina|Santiago|Sao_Paulo|Montevideo|Asuncion|La_Paz|Lima)|Africa\/(Johannesburg|Maputo|Harare|Windhoek|Gaborone|Maseru|Mbabane|Lusaka|Blantyre)|Indian\/(Mauritius|Reunion|Antananarivo))/;

/**
 * The reader's sky without asking where they are: the longitude their clock keeps (fifteen
 * degrees an hour from Greenwich) and a temperate latitude on their side of the equator. Good
 * enough to show the stars that are overhead tonight, and it asks for no permission.
 */
export function observerFrom(zone: string, offsetMinutes: number): Observer {
  return { lat: SOUTH.test(zone) ? -34 : 42, lon: (-offsetMinutes / 60) * 15 };
}

const OBLIQUITY_J2000 = 23.4392911;

/** The Moon's geocentric right ascension and declination, from Meeus 47's principal terms. */
export function moonPlace(date: Date): { ra: number; dec: number; lon: number; lat: number } {
  const T = centuries(date);
  const Lp = norm(218.3164477 + 481267.88123421 * T);
  const D = norm(297.8501921 + 445267.1114034 * T);
  const M = norm(357.5291092 + 35999.0502909 * T);
  const Mp = norm(134.9633964 + 477198.8675055 * T);
  const F = norm(93.272095 + 483202.0175233 * T);
  const lon = norm(
    Lp +
      6.288774 * sin(Mp) +
      1.274027 * sin(2 * D - Mp) +
      0.658314 * sin(2 * D) +
      0.213618 * sin(2 * Mp) -
      0.185116 * sin(M) -
      0.114332 * sin(2 * F) +
      0.058793 * sin(2 * D - 2 * Mp) +
      0.057066 * sin(2 * D - M - Mp) +
      0.053322 * sin(2 * D + Mp) +
      0.045758 * sin(2 * D - M),
  );
  const lat =
    5.128122 * sin(F) +
    0.280602 * sin(Mp + F) +
    0.277693 * sin(Mp - F) +
    0.173237 * sin(2 * D - F) +
    0.055413 * sin(2 * D - Mp + F) +
    0.046271 * sin(2 * D - Mp - F);
  const e = OBLIQUITY_J2000 - 0.0130042 * T;
  const ra = norm(atan2(sin(lon) * cos(e) - Math.tan(lat * RAD) * sin(e), cos(lon)));
  const dec = asin(sin(lat) * cos(e) + cos(lat) * sin(e) * sin(lon));
  return { ra, dec, lon, lat };
}

/** The altitude at which the Moon's upper limb touches the horizon (Meeus 15: +0.125°). */
export const MOONRISE_ALTITUDE = 0.125;

/**
 * When the Moon next rises after `from`, within a day, or null if it does not rise in that
 * day (it can miss one, about once a month, and near the poles for longer). Its altitude is
 * sampled every ten minutes and the crossing found between samples.
 */
export function moonrise(from: Date, at: Observer): Date | null {
  const STEP = 10 * 60_000;
  const altAt = (t: number) => {
    const m = moonPlace(new Date(t));
    return horizontal(m.ra, m.dec, at, new Date(t)).alt - MOONRISE_ALTITUDE;
  };
  let t0 = from.getTime();
  let a0 = altAt(t0);
  for (let t1 = t0 + STEP; t1 <= from.getTime() + 86_400_000; t1 += STEP) {
    const a1 = altAt(t1);
    if (a0 < 0 && a1 >= 0) return new Date(t0 + (STEP * -a0) / (a1 - a0));
    t0 = t1;
    a0 = a1;
  }
  return null;
}

/** The planets the orrery carries: their sidereal periods in days and J2000 mean longitudes. */
export const PLANETS = [
  { id: 'mercury', name: 'Mercury', period: 87.969, L0: 252.250906 },
  { id: 'venus', name: 'Venus', period: 224.701, L0: 181.979801 },
  { id: 'earth', name: 'Earth', period: 365.256, L0: 100.464457 },
  { id: 'mars', name: 'Mars', period: 686.98, L0: 355.433 },
  { id: 'jupiter', name: 'Jupiter', period: 4332.59, L0: 34.351519 },
  { id: 'saturn', name: 'Saturn', period: 10759.22, L0: 50.077444 },
] as const;

export type Planet = (typeof PLANETS)[number];

/** A planet's mean heliocentric longitude on the date, degrees: where its ring sets it now. */
export function meanLongitude(p: Planet, date: Date): number {
  return norm(p.L0 + (360 / p.period) * (julianDay(date) - 2_451_545));
}

/**
 * How long one turn of each ring takes on the page, in seconds: the true periods, in
 * proportion, with a day of the sky passing in `daySeconds` of the reader's.
 */
export function ringSeconds(p: Planet, daySeconds = 1): number {
  return p.period * daySeconds;
}

/** At most one meteor a minute (R-SKY-03), never on a schedule the eye can learn. */
export const METEOR_GAP = 60_000;

/** When the next meteor may fall, given the last (or null for none yet) and a random draw. */
export function nextMeteor(last: number | null, now: number, draw: number): number {
  if (last === null) return now + 12_000 + draw * 30_000;
  return Math.max(now, last + METEOR_GAP + draw * 60_000);
}

/**
 * Where a body stands on the Vault's panorama: azimuth across, altitude up, the reader facing
 * the pole that does not set behind them (south in the north, north in the south). x runs 0 to
 * 1 across `span` degrees of azimuth; y is 0 at the zenith and 1 at the horizon, and goes on
 * past 1 below it, where the stars become the mineral flecks of the ground.
 */
export function panorama(h: Horizontal, at: Observer, span: number): { x: number; y: number } {
  const facing = at.lat >= 0 ? 180 : 0;
  const d = ((h.az - facing + 540) % 360) - 180;
  return { x: 0.5 + d / span, y: 1 - h.alt / 90 };
}
