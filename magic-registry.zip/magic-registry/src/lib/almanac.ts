/** Book furniture shared by every page: paths under the base, folio numerals, the sections. */

/** Joins a site path onto a base, so every link resolves under the published project path. */
export function withBase(base: string, path = ''): string {
  return `${base.replace(/\/+$/, '')}/${path.replace(/^\/+/, '')}`;
}

/** A path inside the registry. */
export const url = (path = ''): string => withBase(import.meta.env.BASE_URL, path);

const NUMERALS: [number, string][] = [
  [1000, 'm'],
  [900, 'cm'],
  [500, 'd'],
  [400, 'cd'],
  [100, 'c'],
  [90, 'xc'],
  [50, 'l'],
  [40, 'xl'],
  [10, 'x'],
  [9, 'ix'],
  [5, 'v'],
  [4, 'iv'],
  [1, 'i'],
];

/** Lower-case roman numerals, as front matter is folioed. */
export function roman(n: number): string {
  if (!Number.isInteger(n) || n < 1) throw new RangeError(`no roman numeral for ${n}`);
  let out = '';
  for (const [value, glyph] of NUMERALS)
    while (n >= value) {
      out += glyph;
      n -= value;
    }
  return out;
}

export type SectionId = 'preface' | 'axis' | 'codex' | 'trials' | 'ledger' | 'bestiary';

/** The sections in book order, as the masthead names them. */
export const SECTIONS: { id: SectionId; path: string; title: string }[] = [
  { id: 'preface', path: 'preface/', title: 'Preface' },
  { id: 'axis', path: '', title: 'The Axis Mundi' },
  { id: 'codex', path: 'codex/', title: 'The Codex' },
  { id: 'trials', path: 'trials/', title: 'The Trials' },
  { id: 'ledger', path: 'ledger/', title: 'The Ledger' },
  { id: 'bestiary', path: 'bestiary/', title: 'The Bestiary' },
];

/** How a position on the axis is read: altitude above the horizon, or depth below it. */
export function axisReading(axis: number): string {
  if (axis === 0) return 'On the horizon';
  return axis > 0 ? `Altitude ${axis}` : `Depth ${-axis}`;
}
