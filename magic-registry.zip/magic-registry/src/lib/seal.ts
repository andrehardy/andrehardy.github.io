/** Sealing wax: the pooled, uneven edge a seal leaves when it is pressed into a warm drop. */

const WANDER = [
  1.6, -0.8, 2.4, 0.4, -1.4, 1.9, -0.2, 2.8, -1.1, 0.9, 1.7, -0.6, 2.1, -1.5, 0.6, 1.2,
];

/** A circle whose radius wanders, closed with smooth curves (`scale` sizes the wander). */
export function wax(cx: number, cy: number, r: number, scale = 1): string {
  const pts = WANDER.map((w, i) => {
    const t = (i / WANDER.length) * Math.PI * 2;
    return [cx + (r + w * scale) * Math.cos(t), cy + (r + w * scale) * Math.sin(t)] as const;
  });
  const mid = (a: readonly [number, number], b: readonly [number, number]) =>
    `${((a[0] + b[0]) / 2).toFixed(2)} ${((a[1] + b[1]) / 2).toFixed(2)}`;
  let path = `M${mid(pts.at(-1)!, pts[0]!)}`;
  pts.forEach((p, i) => {
    path += `Q${p[0].toFixed(2)} ${p[1].toFixed(2)} ${mid(p, pts[(i + 1) % pts.length]!)}`;
  });
  return `${path}Z`;
}
