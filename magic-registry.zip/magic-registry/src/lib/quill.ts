/**
 * The registry's own hand (R-SIG-02): on every leaf that is not a folio, the pointer is a quill,
 * and as it moves it lets fall motes of ink that fade as they dry: gold where it passes over the
 * Vault and the Sealed Light, iron-red over the Mantle, each the accent of the ground beneath
 * it. A folio has its archetype's own cursor instead. Only for a mouse or pen; the motes fall
 * only where motion is allowed.
 */

const SPACING = 26;
const MOST = 16;

let teardown: (() => void) | undefined;

function start() {
  teardown?.();
  teardown = undefined;
  const body = document.body;
  if (body.dataset.archetype || !matchMedia('(pointer: fine)').matches) return;
  body.classList.add('cursor-quill');
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) {
    teardown = () => body.classList.remove('cursor-quill');
    return;
  }
  const layer = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  layer.classList.add('ink-motes');
  layer.setAttribute('aria-hidden', 'true');
  layer.setAttribute('focusable', 'false');
  body.append(layer);
  let last: [number, number] | null = null;
  let motes = 0;
  const move = (e: PointerEvent) => {
    if (e.pointerType !== 'mouse' && e.pointerType !== 'pen') return;
    const p: [number, number] = [e.clientX, e.clientY];
    if (last && Math.hypot(p[0] - last[0], p[1] - last[1]) < SPACING) return;
    last = p;
    const under = document.elementFromPoint(p[0], p[1])?.closest<HTMLElement>('[data-realm]');
    const realm = under?.dataset.realm ?? body.dataset.realm ?? 'sealed';
    const mote = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    mote.setAttribute('class', 'ink-mote');
    mote.setAttribute('cx', p[0].toFixed(1));
    mote.setAttribute('cy', (p[1] + 1).toFixed(1));
    mote.setAttribute('r', (0.9 + Math.random() * 1.2).toFixed(2));
    mote.dataset.tone = realm === 'mantle' ? 'iron' : 'gold';
    mote.style.fill = getComputedStyle(under ?? body).getPropertyValue('--accent');
    mote.addEventListener('animationend', () => mote.remove());
    layer.append(mote);
    layer.dataset.motes = String(++motes);
    while (layer.childElementCount > MOST) layer.firstElementChild?.remove();
  };
  document.addEventListener('pointermove', move, { passive: true });
  teardown = () => {
    document.removeEventListener('pointermove', move);
    layer.remove();
    body.classList.remove('cursor-quill');
  };
}

let bound = false;
export function bindQuill() {
  if (bound) return;
  bound = true;
  document.addEventListener('astro:page-load', start);
  document.addEventListener('astro:before-swap', () => {
    teardown?.();
    teardown = undefined;
  });
}
