/**
 * Versal initials (R-TYPE-01). The Wizard's is a construction capital (R-FLO-WIZ-INI): the
 * Roman letter built inside a square with its inscribed circle, as the Renaissance geometers
 * drew their alphabets, its stem a ninth of the height and its serifs swung with the compass.
 * The letter sits in a field of 100 units; the guides are the lines it was built on.
 */
import { ornamentCapital, ornamentTiming } from './ornaments';

export interface Guide {
  kind: 'line' | 'circle';
  /** A line: x1 y1 x2 y2. A circle: cx cy r, with an optional arc span in degrees. */
  at: number[];
  span?: [number, number];
}

export interface Capital {
  letter: string;
  /** The letter's outline, in a 100-unit square. */
  d: string;
  guides: Guide[];
}

/** The square, its circle and its diagonals: every construction capital begins with these. */
const FRAME: Guide[] = [
  { kind: 'line', at: [0, 0, 100, 0] },
  { kind: 'line', at: [100, 0, 100, 100] },
  { kind: 'line', at: [100, 100, 0, 100] },
  { kind: 'line', at: [0, 100, 0, 0] },
  { kind: 'circle', at: [50, 50, 50] },
  { kind: 'line', at: [0, 0, 100, 100] },
  { kind: 'line', at: [100, 0, 0, 100] },
];

/** A stem is a ninth of the height. */
const STEM = 100 / 9;

const CAPITALS: Record<string, Capital> = {
  T: {
    letter: 'T',
    d:
      `M9 0H91L92.6 15.5Q89.5 7.6 80 7H${50 + STEM / 2}V85` +
      `Q${50 + STEM / 2} 98 67.5 98.8V100H32.5V98.8Q${50 - STEM / 2} 98 ${50 - STEM / 2} 85` +
      `V7H20Q10.5 7.6 7.4 15.5Z`,
    guides: [
      ...FRAME,
      { kind: 'line', at: [50 - STEM / 2, 0, 50 - STEM / 2, 100] },
      { kind: 'line', at: [50 + STEM / 2, 0, 50 + STEM / 2, 100] },
      { kind: 'line', at: [0, 7, 100, 7] },
      { kind: 'circle', at: [67.5, 85, 12], span: [90, 200] },
      { kind: 'circle', at: [32.5, 85, 12], span: [-20, 90] },
      { kind: 'circle', at: [80, 16.5, 9.5], span: [180, 300] },
      { kind: 'circle', at: [20, 16.5, 9.5], span: [240, 360] },
    ],
  },
};

/**
 * The initial's choreography, in seconds: each guide draws in turn, the gold is laid as the
 * last guides finish, and `finished` is when the passage beside it may begin to appear.
 */
export function timing(cap: Capital) {
  const gap = 0.09;
  const draw = 0.5;
  const guidesEnd = (cap.guides.length - 1) * gap + draw;
  const gildAt = +(guidesEnd - 0.25).toFixed(2);
  const gild = 0.7;
  return { gap, draw, gildAt, gild, finished: +(gildAt + gild).toFixed(2) };
}

/** The letters a construction capital can be built for. */
export const CONSTRUCTED = Object.keys(CAPITALS);

export function constructionCapital(letter: string): Capital {
  const c = CAPITALS[letter.toUpperCase()];
  if (!c) throw new Error(`no construction capital is drawn for "${letter}"`);
  return c;
}

/** When the passage beside an initial of this kind may begin to appear, in seconds. */
export function initialFinished(kind: string, letter: string): number {
  if (kind === 'construction-capital') return timing(constructionCapital(letter)).finished;
  return ornamentTiming(ornamentCapital(kind)).finished;
}

/** The first letter of a passage, which its initial replaces. */
export function firstLetter(text: string): string {
  const m = /[A-Za-z]/.exec(text);
  if (!m) throw new Error('the passage has no letter to illuminate');
  return m[0].toUpperCase();
}

/** A guide as SVG path data. */
export function guideD(g: Guide): string {
  if (g.kind === 'line') {
    const [x1, y1, x2, y2] = g.at;
    return `M${x1} ${y1}L${x2} ${y2}`;
  }
  const [cx, cy, r] = g.at as [number, number, number];
  const [a0, a1] = g.span ?? [0, 360];
  const pt = (deg: number) => {
    const a = (deg * Math.PI) / 180;
    return `${(cx + r * Math.cos(a)).toFixed(2)} ${(cy + r * Math.sin(a)).toFixed(2)}`;
  };
  if (a1 - a0 >= 360) return `M${pt(0)}A${r} ${r} 0 1 1 ${pt(180)}A${r} ${r} 0 1 1 ${pt(360)}`;
  return `M${pt(a0)}A${r} ${r} 0 ${a1 - a0 > 180 ? 1 : 0} 1 ${pt(a1)}`;
}
