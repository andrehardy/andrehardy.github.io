/**
 * The registry's voices (R-CHOR-05, R-FLO-*-SND): what each realm and each archetype sounds
 * like, written as recipes the sound engine plays. Nothing here makes a sound: sound is off
 * until the reader asks for it, and every voice is made on the spot from oscillators and
 * noise, so there is nothing to download. The levels are low on purpose: an almanac hums, it
 * does not play music at the reader.
 */
import { ARCHETYPE_IDS, type ArchetypeId } from '~/data/palettes';

export type Wave = 'sine' | 'triangle' | 'sawtooth';

export interface Filter {
  type: 'lowpass' | 'highpass' | 'bandpass';
  hz: number;
  q?: number;
}

/** A slow swell: the layer's level (or its filter) rises and falls `depth` of the way, `rate` times a second. */
export interface Swell {
  rate: number;
  depth: number;
  target?: 'gain' | 'filter';
}

/** A held tone: partials sounding together, for as long as the voice plays. */
export interface Drone {
  kind: 'drone';
  wave: Wave;
  partials: number[];
  gain: number;
  filter?: Filter;
  swell?: Swell;
}

/** A bed of noise: white for air and hiss, brown for the low roar of the ground. */
export interface Bed {
  kind: 'bed';
  color: 'white' | 'brown';
  gain: number;
  filter: Filter;
  swell?: Swell;
}

/** One struck sound: a click, a blip, a bell, a pluck. */
export interface Hit {
  source: Wave | 'noise';
  /** A pitch, or a range to draw from, or a set to choose among. */
  hz?: number | [number, number];
  pick?: number[];
  /** Where the pitch has gone by the end, as a multiple of where it began. */
  glide?: number;
  /** Partials as multiples of the pitch (a bell's are inharmonic). */
  partials?: number[];
  attack: number;
  decay: number;
  gain: number;
  filter?: Filter;
}

/** Hits, now and then (`every` seconds, drawn from the range), or once (`once` seconds in). */
export interface Events {
  kind: 'events';
  every?: [number, number];
  once?: number;
  hit: Hit;
}

export type Layer = Drone | Bed | Events;

export interface Voice {
  /** What the reader would say it sounds like. */
  heard: string;
  layers: Layer[];
}

export type RealmVoiceId = 'vault' | 'mantle';
export type VoiceId = RealmVoiceId | ArchetypeId;

const airy: Layer[] = [
  {
    kind: 'drone',
    wave: 'sine',
    partials: [880, 1318.5, 1760],
    gain: 0.012,
    swell: { rate: 0.07, depth: 0.6 },
  },
  {
    kind: 'bed',
    color: 'white',
    gain: 0.004,
    filter: { type: 'bandpass', hz: 5200, q: 0.7 },
    swell: { rate: 0.05, depth: 0.5 },
  },
];
const earthen: Layer[] = [
  {
    kind: 'drone',
    wave: 'sine',
    partials: [55, 110.4, 165.2],
    gain: 0.04,
    swell: { rate: 0.11, depth: 0.3 },
  },
  {
    kind: 'bed',
    color: 'brown',
    gain: 0.05,
    filter: { type: 'lowpass', hz: 180, q: 0.5 },
    swell: { rate: 0.04, depth: 0.4 },
  },
];

export const VOICES: Record<VoiceId, Voice> = {
  vault: { heard: 'a high, airy drone', layers: airy },
  mantle: { heard: 'a low, earthen hum', layers: earthen },
  wizard: {
    heard: 'the soft ticking of an astrolabe’s gears',
    layers: [
      {
        kind: 'events',
        every: [0.42, 0.9],
        hit: {
          source: 'noise',
          attack: 0.001,
          decay: 0.012,
          gain: 0.05,
          filter: { type: 'highpass', hz: 3200 },
        },
      },
      {
        kind: 'events',
        every: [5, 9],
        hit: { source: 'sine', hz: 1180, attack: 0.002, decay: 0.08, gain: 0.02 },
      },
      { ...(airy[0] as Drone), gain: 0.006 },
    ],
  },
  witch: {
    heard: 'a low simmer, and a crow far off',
    layers: [
      {
        kind: 'events',
        every: [0.06, 0.32],
        hit: {
          source: 'sine',
          hz: [170, 420],
          glide: 1.4,
          attack: 0.004,
          decay: 0.07,
          gain: 0.025,
        },
      },
      { kind: 'bed', color: 'brown', gain: 0.03, filter: { type: 'lowpass', hz: 300 } },
      {
        kind: 'events',
        every: [18, 40],
        hit: {
          source: 'sawtooth',
          hz: [600, 680],
          glide: 0.68,
          attack: 0.02,
          decay: 0.34,
          gain: 0.018,
          filter: { type: 'bandpass', hz: 1400, q: 3 },
        },
      },
    ],
  },
  shaman: {
    heard: 'a frame drum, and breath',
    layers: [
      {
        kind: 'events',
        every: [1.16, 1.24],
        hit: { source: 'sine', hz: 78, glide: 0.66, attack: 0.003, decay: 0.45, gain: 0.2 },
      },
      {
        kind: 'bed',
        color: 'white',
        gain: 0.02,
        filter: { type: 'bandpass', hz: 900, q: 0.8 },
        swell: { rate: 0.16, depth: 1 },
      },
    ],
  },
  sorcerer: {
    heard: 'a static hiss over a low thrum',
    layers: [
      { kind: 'bed', color: 'white', gain: 0.006, filter: { type: 'highpass', hz: 4000 } },
      {
        kind: 'events',
        every: [0.08, 0.9],
        hit: {
          source: 'noise',
          attack: 0.0005,
          decay: 0.006,
          gain: 0.06,
          filter: { type: 'highpass', hz: 2000 },
        },
      },
      {
        kind: 'drone',
        wave: 'sawtooth',
        partials: [44, 88, 132],
        gain: 0.02,
        filter: { type: 'lowpass', hz: 220 },
        swell: { rate: 0.3, depth: 0.5 },
      },
    ],
  },
  enchantress: {
    heard: 'a distant voice without words',
    layers: [
      {
        kind: 'drone',
        wave: 'sawtooth',
        partials: [220],
        gain: 0.03,
        filter: { type: 'bandpass', hz: 700, q: 8 },
        swell: { rate: 0.09, depth: 0.9 },
      },
      {
        kind: 'drone',
        wave: 'sawtooth',
        partials: [220.6],
        gain: 0.018,
        filter: { type: 'bandpass', hz: 1150, q: 9 },
        swell: { rate: 0.09, depth: 0.9 },
      },
    ],
  },
  warlock: {
    heard: 'a quill scratching, and an iron clasp',
    layers: [
      {
        kind: 'events',
        every: [0.06, 0.24],
        hit: {
          source: 'noise',
          attack: 0.002,
          decay: 0.03,
          gain: 0.03,
          filter: { type: 'bandpass', hz: 3000, q: 2 },
        },
      },
      {
        kind: 'events',
        every: [20, 40],
        hit: {
          source: 'triangle',
          hz: 420,
          partials: [1, 2.76, 5.4, 8.9],
          attack: 0.001,
          decay: 0.9,
          gain: 0.05,
        },
      },
    ],
  },
  druid: {
    heard: 'wind through leaves, and a bough creaking',
    layers: [
      {
        kind: 'bed',
        color: 'white',
        gain: 0.025,
        filter: { type: 'bandpass', hz: 1100, q: 0.6 },
        swell: { rate: 0.07, depth: 0.8 },
      },
      {
        kind: 'events',
        every: [15, 30],
        hit: {
          source: 'sawtooth',
          hz: 95,
          glide: 0.84,
          attack: 0.3,
          decay: 1.2,
          gain: 0.025,
          filter: { type: 'lowpass', hz: 600 },
        },
      },
    ],
  },
  necromancer: {
    heard: 'dry clicks in a low wind',
    layers: [
      {
        kind: 'events',
        every: [0.4, 2.5],
        hit: {
          source: 'noise',
          attack: 0.0005,
          decay: 0.01,
          gain: 0.06,
          filter: { type: 'bandpass', hz: 1700, q: 4 },
        },
      },
      {
        kind: 'bed',
        color: 'brown',
        gain: 0.04,
        filter: { type: 'lowpass', hz: 400 },
        swell: { rate: 0.05, depth: 0.9 },
      },
    ],
  },
  cleric: {
    heard: 'a sustained choral tone',
    layers: [
      {
        kind: 'drone',
        wave: 'triangle',
        partials: [146.8, 220, 293.7, 370],
        gain: 0.02,
        filter: { type: 'lowpass', hz: 1300 },
        swell: { rate: 0.06, depth: 0.4 },
      },
    ],
  },
  paladin: {
    heard: 'a struck bell, and steel ringing',
    layers: [
      {
        kind: 'events',
        every: [9, 14],
        hit: {
          source: 'sine',
          hz: 196,
          partials: [1, 2, 2.4, 3, 4.2, 5.4],
          attack: 0.002,
          decay: 5.5,
          gain: 0.05,
        },
      },
      {
        kind: 'events',
        every: [5, 9],
        hit: { source: 'sine', hz: 2640, attack: 0.001, decay: 3, gain: 0.01 },
      },
    ],
  },
  alchemist: {
    heard: 'glass chimes, and bubbling',
    layers: [
      {
        kind: 'events',
        every: [1.5, 4.5],
        hit: {
          source: 'sine',
          pick: [1568, 1760, 2093, 2349, 2637],
          attack: 0.002,
          decay: 1.4,
          gain: 0.025,
        },
      },
      {
        kind: 'events',
        every: [0.08, 0.6],
        hit: {
          source: 'sine',
          hz: [300, 520],
          glide: 2.2,
          attack: 0.003,
          decay: 0.06,
          gain: 0.025,
        },
      },
    ],
  },
  bard: {
    heard: 'one plucked lute note that resolves the page',
    layers: [
      {
        kind: 'events',
        once: 0.6,
        hit: {
          source: 'triangle',
          hz: 196,
          partials: [1, 2, 3, 4],
          attack: 0.004,
          decay: 2.6,
          gain: 0.09,
        },
      },
    ],
  },
};

/** The voice for a leaf: its archetype's on a folio; on the Mantle's ground, its hum; else the sky's. */
export function voiceFor(archetype: string | undefined, realm: string | undefined): VoiceId {
  if (archetype && (ARCHETYPE_IDS as readonly string[]).includes(archetype))
    return archetype as ArchetypeId;
  return realm === 'mantle' ? 'mantle' : 'vault';
}
