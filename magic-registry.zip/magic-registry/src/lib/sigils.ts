/**
 * Sigils, each made by its archetype's own geometry (R-ID-*-03). The Wizard's is a compass and
 * straightedge construction (R-ID-WIZ-03, R-PH4-01): a circle; two arcs of the same span about
 * the ends of its diameter, which cut it into six; the two triangles of those six points; and
 * the orbits found where the triangles cross. The plate draws it in exactly this order.
 */
import type { ArchetypeId } from '~/data/palettes';
import { Construction } from './construction';
import { DRAWINGS } from './drawings';
import type { Pt } from './ink';

export interface SigilSpec {
  build: () => Construction;
  /** Turns the construction upright on the plate (unit radius, centred on the origin). */
  upright: (p: Pt) => Pt;
  /** The point the construction resolves to, upright: where the Wizard's threads converge. */
  focus: string;
}

export function wizardConstruction(): Construction {
  const s3 = Math.sqrt(3) / 2;
  return new Construction()
    .given('O', [0, 0])
    .given('A', [1, 0])
    .circle('orbit', 'O', 'A', 'cut')
    .line('horizon', 'O', 'A', 'guide', [-1.12, 1.12])
    .meet('B', 'horizon', 'orbit', [-1, 0])
    .circle('east-arc', 'A', 'O', 'guide', [105, 255])
    .circle('west-arc', 'B', 'O', 'guide', [-75, 75])
    .meet('P1', 'east-arc', 'orbit', [0.5, -s3])
    .meet('P2', 'east-arc', 'orbit', [0.5, s3])
    .meet('P3', 'west-arc', 'orbit', [-0.5, -s3])
    .meet('P4', 'west-arc', 'orbit', [-0.5, s3])
    .line('rising-1', 'A', 'P3', 'cut')
    .line('rising-2', 'P3', 'P4', 'cut')
    .line('rising-3', 'P4', 'A', 'cut')
    .line('falling-1', 'B', 'P1', 'cut')
    .line('falling-2', 'P1', 'P2', 'cut')
    .line('falling-3', 'P2', 'B', 'cut')
    .meet('Q', 'rising-1', 'falling-1', [0, -0.58])
    .circle('inner-orbit', 'O', 'Q', 'cut')
    .meet('M', 'falling-2', 'horizon', [0.5, 0])
    .circle('least-orbit', 'O', 'M', 'cut')
    .line('meridian', 'Q', 'O', 'guide', [-0.94, 2.94])
    .prick('O')
    .prick('B');
}

export const SIGILS: Partial<Record<ArchetypeId, SigilSpec>> = {
  wizard: {
    build: wizardConstruction,
    // The first given point stands at the top: the rising triangle points to the sky.
    upright: ([x, y]) => [y, -x],
    focus: 'B',
  },
};

/** Whether an archetype's sigil is cut, by construction or by drawing. */
export function hasSigil(id: ArchetypeId): boolean {
  return id in SIGILS || id in DRAWINGS;
}

/** Places a sigil's construction on a plate: upright, centred at (cx, cy), at radius r. */
export function placer(spec: SigilSpec, cx: number, cy: number, r: number): (p: Pt) => Pt {
  return (p) => {
    const [x, y] = spec.upright(p);
    return [cx + r * x, cy + r * y];
  };
}
