/**
 * The Ledger's rules, shared by the Ledger, the folios and the tests: only confirmed portrayals
 * are ever shown (R-RES-04, R-DATA-08), the misfiled lead (R-ROUTE-05), and a work's year is
 * written as a reader would expect it, before or after Christ.
 */
import type { MEDIA, VERDICT_KINDS } from '~/data/schemas';

type Medium = (typeof MEDIA)[number];
type Kind = (typeof VERDICT_KINDS)[number];

/** Only confirmed portrayals reach a page; a proposed one is never rendered. */
export const shown = <T extends { data: { status: string } }>(entries: T[]): T[] =>
  entries.filter((e) => e.data.status === 'confirmed');

/** 1818 stays 1818; 8 is AD 8; -700 is 700 BC. */
export function era(year: number): string {
  if (year < 0) return `${-year} BC`;
  if (year < 1000) return `AD ${year}`;
  return String(year);
}

export const MEDIUM_NAMES: Record<Medium, string> = {
  myth: 'Myth and scripture',
  book: 'Books and plays',
  film: 'Film',
  tv: 'Television',
  game: 'Games',
  anime: 'Anime',
  comic: 'Comics',
};

export const KIND_NAMES: Record<Kind, string> = {
  misfiled: 'Misfiled',
  anomaly: 'An anomaly',
  'true-to-label': 'True to the label',
};

const KIND_ORDER: Record<Kind, number> = { misfiled: 0, anomaly: 1, 'true-to-label': 2 };

/** The misfiled first, then the anomalies, then the rest; within each, by name. */
export const ledgerOrder = (
  a: { data: { verdictKind: Kind; character: string } },
  b: { data: { verdictKind: Kind; character: string } },
): number =>
  KIND_ORDER[a.data.verdictKind] - KIND_ORDER[b.data.verdictKind] ||
  a.data.character.localeCompare(b.data.character);
