/**
 * Sorting the Ledger (R-ROUTE-05). Each choice narrows the entries shown; the choices are kept in
 * the address (?realm=mantle&kind=misfiled), so a view can be shared and comes back with the
 * reader. The form stays hidden without a script, and then the whole Ledger stands open.
 */

/** Form field name, and the entry attribute it is matched against. */
const FIELDS = [
  ['realm', 'realmOf'],
  ['filed', 'filed'],
  ['medium', 'medium'],
  ['kind', 'kind'],
] as const;

function start() {
  const form = document.querySelector<HTMLFormElement>('[data-ledger-filter]');
  const list = document.querySelector<HTMLElement>('[data-ledger]');
  if (!form || !list) return;
  const entries = [...list.querySelectorAll<HTMLElement>(':scope > li')];
  const tally = form.querySelector<HTMLElement>('[data-tally]')!;
  const none = document.querySelector<HTMLElement>('[data-ledger-none]');

  const asked = new URL(location.href).searchParams;
  for (const [name] of FIELDS) {
    const value = asked.get(name);
    if (!value) continue;
    const field = form.elements.namedItem(name);
    if (field instanceof RadioNodeList || field instanceof HTMLSelectElement) field.value = value;
  }

  const apply = () => {
    const chosen = new FormData(form);
    let count = 0;
    for (const entry of entries) {
      const fits = FIELDS.every(([name, key]) => {
        const want = chosen.get(name);
        return !want || entry.dataset[key] === want;
      });
      entry.hidden = !fits;
      if (fits) count++;
    }
    tally.innerHTML =
      count === entries.length
        ? `All <span class="figures-tabular">${count}</span> entries`
        : `<span class="figures-tabular">${count}</span> of the <span class="figures-tabular">${entries.length}</span> entries`;
    if (none) none.hidden = count > 0;
    form.dataset.shown = String(count);

    const address = new URL(location.href);
    for (const [name] of FIELDS) {
      const value = chosen.get(name);
      if (value) address.searchParams.set(name, String(value));
      else address.searchParams.delete(name);
    }
    if (address.href !== location.href) history.replaceState(history.state, '', address);
  };

  form.hidden = false;
  form.addEventListener('change', apply);
  form.addEventListener('submit', (e) => e.preventDefault());
  apply();
}

let bound = false;
export function bindLedger() {
  if (bound) return;
  bound = true;
  document.addEventListener('astro:page-load', start);
}
