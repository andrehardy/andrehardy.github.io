/**
 * The marks of a Trial's outcomes: one engraved sign for each kind of result, so that twelve
 * outcomes can be read at a glance before a word of them is.
 */
import type { RESULT_KINDS } from '~/data/schemas';

export type ResultKind = (typeof RESULT_KINDS)[number];

export const RESULT_NAMES: Record<ResultKind, string> = {
  moved: 'Moved',
  untouched: 'Untouched',
  conditional: 'On terms',
  shattered: 'Shattered',
  denied: 'Refused',
};

/** The order a tally is read in: from the task done to the task refused. */
export const RESULT_ORDER: ResultKind[] = [
  'moved',
  'conditional',
  'untouched',
  'shattered',
  'denied',
];

/** Each sign on a 24-unit square: a fall, a ring held, a ring halved, a crack, a cross. */
export const RESULT_SIGNS: Record<ResultKind, string[]> = {
  moved: ['M12 3V19', 'M6.5 13.5L12 19L17.5 13.5'],
  untouched: ['M12 4A8 8 0 1 1 11.99 4Z'],
  conditional: ['M12 4A8 8 0 1 1 11.99 4Z', 'M12 4V20'],
  shattered: ['M12 3L9.5 9L14 12.5L10 17L12 21', 'M4.5 11L9.5 9', 'M19.5 10.5L14 12.5'],
  denied: ['M6.5 6.5L17.5 17.5', 'M17.5 6.5L6.5 17.5'],
};

const WORDS = [
  'no',
  'one',
  'two',
  'three',
  'four',
  'five',
  'six',
  'seven',
  'eight',
  'nine',
  'ten',
  'eleven',
  'twelve',
];

/** "Five moved, three on terms, four shattered": a Trial's outcomes, counted in words. */
export function tally(kinds: ResultKind[]): string {
  const parts = RESULT_ORDER.flatMap((k) => {
    const n = kinds.filter((x) => x === k).length;
    return n ? [`${WORDS[n] ?? n} ${RESULT_NAMES[k].toLowerCase()}`] : [];
  });
  const text = parts.join(', ');
  return text.charAt(0).toUpperCase() + text.slice(1);
}
