/**
 * Pieces that wait to be seen (D-29). Anything marked data-on-view that starts below the fold
 * holds its animations on their first frame (the .waiting class in motion.css) until it
 * scrolls into view. Under reduced motion nothing waits: the finished state is shown at once.
 */

let watcher: IntersectionObserver | undefined;

export function watchOnView(root: ParentNode = document): void {
  watcher?.disconnect();
  watcher = undefined;
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const pieces = [...root.querySelectorAll<HTMLElement>('[data-on-view]')];
  if (!pieces.length) return;
  watcher = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        entry.target.classList.remove('waiting');
        watcher?.unobserve(entry.target);
      }
    },
    { rootMargin: '0px 0px -12% 0px' },
  );
  const fold = innerHeight * 0.88;
  for (const piece of pieces) {
    if (piece.getBoundingClientRect().top < fold) continue;
    piece.classList.add('waiting');
    watcher.observe(piece);
  }
}
