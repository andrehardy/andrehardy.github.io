/**
 * The Wizard's reckoning in the margin (D-24): the day counted from a known new moon, the
 * whole months of the Moon elapsed since, and the Moon's age within the present month, by the
 * mean synodic month. It is set when the leaf is printed and set again when it is opened, so
 * the figures are the reader's own day.
 */
import { julianDay } from './astronomy';

/** The new moon of 6 January 2000, 18:14 UT, as a Julian day (Meeus, chapter 49). */
export const EPOCH_NEW_MOON = 2_451_550.26;
/** The mean synodic month, in days. */
export const MEAN_MONTH = 29.530588853;

export interface Reckoning {
  /** The Julian day. */
  julianDay: number;
  /** Whole days since the epoch new moon. */
  days: number;
  /** Whole months of the Moon since the epoch new moon. */
  lunations: number;
  /** Days since the most recent mean new moon. */
  age: number;
}

export function reckon(date: Date): Reckoning {
  const jd = julianDay(date);
  const elapsed = jd - EPOCH_NEW_MOON;
  const lunations = Math.floor(elapsed / MEAN_MONTH);
  return {
    julianDay: jd,
    days: Math.floor(elapsed),
    lunations,
    age: elapsed - lunations * MEAN_MONTH,
  };
}

export type ReckonKey = 'julian-day' | 'days' | 'lunations' | 'age';

const grouped = new Intl.NumberFormat('en-GB', { maximumFractionDigits: 0 });

/** The figures as the margin sets them. */
export function figures(r: Reckoning): Record<ReckonKey, string> {
  return {
    'julian-day': new Intl.NumberFormat('en-GB', {
      minimumFractionDigits: 1,
      maximumFractionDigits: 1,
    }).format(Math.floor(r.julianDay * 10) / 10),
    days: grouped.format(r.days),
    lunations: grouped.format(r.lunations),
    age: (Math.floor(r.age * 10) / 10).toFixed(1),
  };
}

/** The lines of the reckoning, in both voices. */
export const RECKONING_LINES: { key: ReckonKey; almanac: string; cipher: string }[] = [
  { key: 'julian-day', almanac: 'The day, by the Julian count', cipher: 'Julian day' },
  {
    key: 'days',
    almanac: 'Days since the new moon of the sixth of January, 2000',
    cipher: 'Days since the new moon of 6 January 2000',
  },
  { key: 'lunations', almanac: 'Moons since', cipher: 'Whole lunar months since then' },
  {
    key: 'age',
    almanac: 'The age of the present moon, in days',
    cipher: 'Days since the last new moon',
  },
];
