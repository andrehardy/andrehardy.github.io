/**
 * Gold leaf is specular (R-MAT-02): its one bright band sits where the light is. With a mouse,
 * the light is the reader's hand: each gilded piece turns its sheen toward the pointer. On a
 * phone or tablet the light follows the tilt of the device, once the reader's first touch on the
 * gold has let the page ask for it (some browsers ask permission; others simply allow it). Under
 * reduced motion the leaf keeps its resting light.
 */

const GILDED = '.gilt-text, .gilt-surface';
const clamp = (x: number) => Math.max(-20, Math.min(120, x));

type Teardown = () => void;

function byPointer(): Teardown {
  let queued = 0;
  let at: [number, number] = [0, 0];
  const apply = () => {
    queued = 0;
    for (const el of document.querySelectorAll<HTMLElement>(GILDED)) {
      const r = el.getBoundingClientRect();
      if (r.bottom < 0 || r.top > innerHeight || !r.width) continue;
      el.style.setProperty('--gx', `${clamp(((at[0] - r.left) / r.width) * 100).toFixed(1)}%`);
      el.style.setProperty('--gy', `${clamp(((at[1] - r.top) / r.height) * 100).toFixed(1)}%`);
    }
  };
  const move = (e: PointerEvent) => {
    if (e.pointerType !== 'mouse' && e.pointerType !== 'pen') return;
    at = [e.clientX, e.clientY];
    if (!queued) queued = requestAnimationFrame(apply);
  };
  document.addEventListener('pointermove', move, { passive: true });
  return () => {
    document.removeEventListener('pointermove', move);
    cancelAnimationFrame(queued);
  };
}

type Orientation = typeof DeviceOrientationEvent & { requestPermission?: () => Promise<string> };

function byTilt(): Teardown {
  const Orient = (globalThis as { DeviceOrientationEvent?: Orientation }).DeviceOrientationEvent;
  if (!Orient) return () => undefined;
  let queued = 0;
  let want: [number, number] = [50, 50];
  let shown: [number, number] = [NaN, NaN];
  const apply = () => {
    queued = 0;
    if (Math.abs(want[0] - shown[0]) < 0.5 && Math.abs(want[1] - shown[1]) < 0.5) return;
    shown = want;
    const gx = `${want[0].toFixed(1)}%`;
    const gy = `${want[1].toFixed(1)}%`;
    for (const el of document.querySelectorAll<HTMLElement>(GILDED)) {
      const r = el.getBoundingClientRect();
      if (r.bottom < 0 || r.top > innerHeight) continue;
      el.style.setProperty('--gx', gx);
      el.style.setProperty('--gy', gy);
    }
  };
  const tilt = (e: DeviceOrientationEvent) => {
    if (e.gamma === null || e.beta === null) return;
    want = [clamp(50 + e.gamma * 1.4), clamp(50 + (e.beta - 40) * 1.4)];
    if (!queued) queued = requestAnimationFrame(apply);
  };
  let listening = false;
  const begin = () => {
    if (listening) return;
    listening = true;
    addEventListener('deviceorientation', tilt, { passive: true });
  };
  // Only a touch on the gold itself asks to follow the tilt, so the question comes in context.
  const ask = (e: TouchEvent) => {
    if (!(e.target as Element | null)?.closest?.(GILDED)) return;
    document.removeEventListener('touchend', ask);
    if (Orient.requestPermission)
      void Orient.requestPermission()
        .then((answer) => answer === 'granted' && begin())
        .catch(() => undefined);
    else begin();
  };
  document.addEventListener('touchend', ask, { passive: true });
  return () => {
    document.removeEventListener('touchend', ask);
    removeEventListener('deviceorientation', tilt);
    cancelAnimationFrame(queued);
  };
}

let bound = false;
export function bindGilt() {
  if (bound || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  bound = true;
  byPointer();
  if (matchMedia('(pointer: coarse)').matches) byTilt();
}
