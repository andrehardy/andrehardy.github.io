/**
 * Everything a folio sets on its leaves, gathered once at build: the marks of realm, being
 * and access; the counterparts by name; the archetype's outcome in each trial; and its ledger,
 * which files confirmed portrayals by rank and also lists those a work calls by this
 * archetype's name but the Registry files elsewhere.
 */
import { getCollection, type CollectionEntry } from 'astro:content';
import type { ArchetypeId } from '~/data/palettes';
import type { WrittenArchetype } from '~/data/schemas';
import { filedElsewhere, labelsOf } from './labels';
import { shown } from './ledger';

type Portrayal = CollectionEntry<'portrayals'>;

export interface FolioData {
  id: ArchetypeId;
  a: WrittenArchetype;
  realm: CollectionEntry<'realms'>['data'] & { id: string };
  beings: (CollectionEntry<'beings'>['data'] & { id: string })[];
  access: CollectionEntry<'access'>['data'];
  counterparts: {
    id: ArchetypeId;
    name: string;
    note: WrittenArchetype['counterparts'][number]['note'];
  }[];
  trials: {
    id: string;
    title: CollectionEntry<'trials'>['data']['title'];
    outcome: CollectionEntry<'trials'>['data']['outcomes'][number];
  }[];
  /** Confirmed portrayals filed here: the exemplar, the runner-up, then the rest by year. */
  ledger: Portrayal[];
  /** Confirmed portrayals whose work names this archetype but which are filed under another. */
  misfiledOut: (Portrayal & { filedAs: string })[];
  /** Archetype names by id, for "filed here as the ..." lines. */
  names: Record<string, string>;
}

const RANK_ORDER = { exemplar: 0, 'runner-up': 1, notable: 2 } as const;

export async function folioData(entry: CollectionEntry<'archetypes'>): Promise<FolioData> {
  const a = entry.data;
  if (a.stage !== 'written') throw new Error(`the ${a.name} is not written yet`);
  const id = entry.id as ArchetypeId;
  const archetypes = await getCollection('archetypes');
  const names = Object.fromEntries(archetypes.map((x) => [x.id, x.data.name]));
  const realm = (await getCollection('realms')).find((r) => r.id === a.realm)!;
  const beings = (await getCollection('beings')).filter((b) => a.beings.some((x) => x === b.id));
  const access = (await getCollection('access')).find((x) => x.id === a.access)!.data;
  const trials = (await getCollection('trials'))
    .sort((x, y) => x.id.localeCompare(y.id))
    .flatMap((t) => {
      const outcome = t.data.outcomes.find((o) => o.archetype === id);
      return outcome ? [{ id: t.id, title: t.data.title, outcome }] : [];
    });
  const confirmed = shown(await getCollection('portrayals'));
  const labels = labelsOf(archetypes);
  return {
    id,
    a,
    realm: { id: realm.id, ...realm.data },
    beings: beings.map((b) => ({ id: b.id, ...b.data })),
    access,
    counterparts: a.counterparts.map((c) => ({
      id: c.archetype,
      name: names[c.archetype]!,
      note: c.note,
    })),
    trials,
    ledger: confirmed
      .filter((p) => p.data.verdict === id)
      .sort(
        (x, y) =>
          RANK_ORDER[x.data.rank] - RANK_ORDER[y.data.rank] ||
          x.data.year - y.data.year ||
          x.id.localeCompare(y.id),
      ),
    misfiledOut: filedElsewhere(confirmed, id, labels).map((p) => ({
      ...p,
      filedAs: names[p.data.verdict]!,
    })),
    names,
  };
}

/** A cipher reading is written as plain paragraphs separated by blank lines. */
export function paragraphs(text: string): string[] {
  return text
    .split(/\n\s*\n/)
    .map((p) => p.replace(/\s+/g, ' ').trim())
    .filter(Boolean);
}
