/**
 * The Codex grid (R-ROUTE-03). A peopled crossing, chosen from the grid, opens beneath it and the
 * one before closes; the address keeps the crossing (#crossing-…), so it can be shared. As the
 * hand or the focus crosses the grid, its row and column heads take the rubric.
 */

function start() {
  const codex = document.querySelector<HTMLElement>('[data-codex]');
  const grid = codex?.querySelector<HTMLTableElement>('[data-codex-grid]');
  if (!codex || !grid) return;
  const openers = [...codex.querySelectorAll<HTMLAnchorElement>('[data-crossing]')];
  const panels = new Map(
    [...codex.querySelectorAll<HTMLElement>('[data-crossing-panel]')].map((p) => [
      p.dataset.crossingPanel!,
      p,
    ]),
  );

  const open = (id: string, from?: HTMLElement) => {
    for (const [key, panel] of panels) panel.toggleAttribute('data-open', key === id);
    for (const a of openers) {
      if (a.dataset.crossing === id) a.setAttribute('aria-current', 'true');
      else a.removeAttribute('aria-current');
    }
    codex.dataset.open = id;
    if (from) {
      history.replaceState(history.state, '', `#crossing-${id}`);
      const still = matchMedia('(prefers-reduced-motion: reduce)').matches;
      panels.get(id)?.scrollIntoView({ block: 'nearest', behavior: still ? 'auto' : 'smooth' });
    }
  };

  const asked = location.hash.replace(/^#crossing-/, '');
  open(panels.has(asked) ? asked : openers[0]!.dataset.crossing!);
  codex.toggleAttribute('data-live', true);

  for (const a of openers)
    a.addEventListener('click', (e) => {
      e.preventDefault();
      open(a.dataset.crossing!, a);
    });

  const mark = (e: Event) => {
    const cell = (e.target as Element).closest<HTMLElement>('td[data-row], th[data-row]');
    grid.dataset.atRow = cell?.dataset.row ?? '';
    grid.dataset.atCol = cell?.dataset.col ?? '';
  };
  grid.addEventListener('pointerover', mark);
  grid.addEventListener('focusin', mark);
  grid.addEventListener('pointerleave', () => {
    delete grid.dataset.atRow;
    delete grid.dataset.atCol;
  });
}

let bound = false;
export function bindCodex() {
  if (bound) return;
  bound = true;
  document.addEventListener('astro:page-load', start);
}
