/**
 * Compass and straightedge (R-PH4-01). A construction begins from two given points and grows
 * only by the two classical moves: a line laid through two known points, and a circle drawn
 * about a known point through another. A new point exists only where two drawn figures meet.
 * Every move is kept in order, so a plate can draw them one after another, as a geometer would,
 * and a test can replay them to prove nothing was placed by eye.
 */
import type { Pt } from './ink';

export type Role = 'guide' | 'cut';

export interface LineFigure {
  kind: 'line';
  id: string;
  /** The two known points the straightedge is laid through. */
  through: [string, string];
  /** How much of the line is drawn, as multiples of the run from the first point to the second. */
  span: [number, number];
  role: Role;
}

export interface CircleFigure {
  kind: 'circle';
  id: string;
  centre: string;
  /** The known point the compass is opened to. */
  through: string;
  /** How much of the circle is drawn, in degrees; the whole circle by default. */
  span: [number, number];
  role: Role;
}

export type Figure = LineFigure | CircleFigure;

export type Move =
  | { kind: 'given'; point: string; at: Pt }
  | { kind: 'figure'; figure: Figure }
  | { kind: 'meet'; point: string; of: [string, string]; at: Pt }
  | { kind: 'prick'; point: string };

/** What a plate draws: a figure, or a prick marking a point. */
export type Mark = Figure | { kind: 'prick'; point: string };

const EPS = 1e-9;

export class Construction {
  readonly points = new Map<string, Pt>();
  readonly figures = new Map<string, Figure>();
  readonly moves: Move[] = [];

  /** One of the two points the construction is given. */
  given(name: string, at: Pt): this {
    if (this.moves.some((m) => m.kind !== 'given') || this.points.size >= 2)
      throw new Error('a construction is given exactly two points, before anything is drawn');
    this.points.set(name, at);
    this.moves.push({ kind: 'given', point: name, at });
    return this;
  }

  line(id: string, a: string, b: string, role: Role, span: [number, number] = [0, 1]): this {
    this.need(a, b);
    return this.add({ kind: 'line', id, through: [a, b], span, role });
  }

  circle(
    id: string,
    centre: string,
    through: string,
    role: Role,
    span: [number, number] = [0, 360],
  ): this {
    this.need(centre, through);
    return this.add({ kind: 'circle', id, centre, through, span, role });
  }

  /** Names the meeting of two drawn figures nearest to a rough position. */
  meet(name: string, f: string, g: string, near: Pt): this {
    const a = this.figures.get(f);
    const b = this.figures.get(g);
    if (!a || !b) throw new Error(`${name}: ${f} and ${g} must both be drawn first`);
    const found = intersections(a, b, this.points);
    if (!found.length) throw new Error(`${name}: ${f} and ${g} do not meet`);
    const at = found.reduce((best, p) => (dist(p, near) < dist(best, near) ? p : best));
    this.points.set(name, at);
    this.moves.push({ kind: 'meet', point: name, of: [f, g], at });
    return this;
  }

  /** Pricks a known point: the dot a geometer leaves to mark it. */
  prick(point: string): this {
    this.need(point);
    this.moves.push({ kind: 'prick', point });
    return this;
  }

  /** The figures and pricks in the order they were made: what a plate draws. */
  get marks(): Mark[] {
    return this.moves.flatMap((m): Mark[] =>
      m.kind === 'figure' ? [m.figure] : m.kind === 'prick' ? [m] : [],
    );
  }

  private need(...names: string[]) {
    for (const n of names) if (!this.points.has(n)) throw new Error(`point ${n} is not yet known`);
  }

  private add(figure: Figure): this {
    if (this.figures.has(figure.id)) throw new Error(`figure ${figure.id} is drawn twice`);
    this.figures.set(figure.id, figure);
    this.moves.push({ kind: 'figure', figure });
    return this;
  }
}

export const dist = (p: Pt, q: Pt): number => Math.hypot(p[0] - q[0], p[1] - q[1]);

/** The radius of a drawn circle. */
export function radius(c: CircleFigure, points: Map<string, Pt>): number {
  return dist(points.get(c.centre)!, points.get(c.through)!);
}

/** Every point where two figures meet (lines are taken whole, however much is drawn). */
export function intersections(a: Figure, b: Figure, points: Map<string, Pt>): Pt[] {
  if (a.kind === 'line' && b.kind === 'line') return lineLine(a, b, points);
  if (a.kind === 'circle' && b.kind === 'circle') return circleCircle(a, b, points);
  return a.kind === 'line'
    ? lineCircle(a, b as CircleFigure, points)
    : lineCircle(b as LineFigure, a, points);
}

function lineLine(a: LineFigure, b: LineFigure, pts: Map<string, Pt>): Pt[] {
  const [p, q] = a.through.map((n) => pts.get(n)!) as [Pt, Pt];
  const [r, s] = b.through.map((n) => pts.get(n)!) as [Pt, Pt];
  const d1: Pt = [q[0] - p[0], q[1] - p[1]];
  const d2: Pt = [s[0] - r[0], s[1] - r[1]];
  const den = d1[0] * d2[1] - d1[1] * d2[0];
  if (Math.abs(den) < EPS) return [];
  const t = ((r[0] - p[0]) * d2[1] - (r[1] - p[1]) * d2[0]) / den;
  return [[p[0] + t * d1[0], p[1] + t * d1[1]]];
}

function lineCircle(l: LineFigure, c: CircleFigure, pts: Map<string, Pt>): Pt[] {
  const [p, q] = l.through.map((n) => pts.get(n)!) as [Pt, Pt];
  const o = pts.get(c.centre)!;
  const r = radius(c, pts);
  const d: Pt = [q[0] - p[0], q[1] - p[1]];
  const f: Pt = [p[0] - o[0], p[1] - o[1]];
  const A = d[0] ** 2 + d[1] ** 2;
  const B = 2 * (f[0] * d[0] + f[1] * d[1]);
  const C = f[0] ** 2 + f[1] ** 2 - r * r;
  const disc = B * B - 4 * A * C;
  if (disc < -EPS) return [];
  const root = Math.sqrt(Math.max(0, disc));
  return [(-B - root) / (2 * A), (-B + root) / (2 * A)].map((t): Pt => [
    p[0] + t * d[0],
    p[1] + t * d[1],
  ]);
}

function circleCircle(a: CircleFigure, b: CircleFigure, pts: Map<string, Pt>): Pt[] {
  const p = pts.get(a.centre)!;
  const q = pts.get(b.centre)!;
  const r1 = radius(a, pts);
  const r2 = radius(b, pts);
  const d = dist(p, q);
  if (d < EPS || d > r1 + r2 + EPS || d < Math.abs(r1 - r2) - EPS) return [];
  const along = (r1 * r1 - r2 * r2 + d * d) / (2 * d);
  const h = Math.sqrt(Math.max(0, r1 * r1 - along * along));
  const m: Pt = [p[0] + (along * (q[0] - p[0])) / d, p[1] + (along * (q[1] - p[1])) / d];
  return [
    [m[0] + (h * (q[1] - p[1])) / d, m[1] - (h * (q[0] - p[0])) / d],
    [m[0] - (h * (q[1] - p[1])) / d, m[1] + (h * (q[0] - p[0])) / d],
  ];
}

/** Whether a point lies on a figure (taken whole). */
export function lies(p: Pt, f: Figure, points: Map<string, Pt>): boolean {
  if (f.kind === 'circle')
    return Math.abs(dist(p, points.get(f.centre)!) - radius(f, points)) < 1e-7;
  const [a, b] = f.through.map((n) => points.get(n)!) as [Pt, Pt];
  const cross = (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]);
  return Math.abs(cross) / dist(a, b) < 1e-7;
}

/** Samples the drawn part of a figure, scaled and turned for a plate. */
export function sample(f: Figure, points: Map<string, Pt>, place: (p: Pt) => Pt, n = 64): Pt[] {
  if (f.kind === 'line') {
    const [a, b] = f.through.map((x) => points.get(x)!) as [Pt, Pt];
    const at = (t: number): Pt => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
    const out: Pt[] = [];
    for (let i = 0; i <= 12; i++)
      out.push(place(at(f.span[0] + ((f.span[1] - f.span[0]) * i) / 12)));
    return out;
  }
  const o = points.get(f.centre)!;
  const r = radius(f, points);
  const out: Pt[] = [];
  const [a0, a1] = f.span.map((deg) => (deg * Math.PI) / 180) as [number, number];
  const steps = Math.max(8, Math.round((n * Math.abs(a1 - a0)) / (2 * Math.PI)));
  for (let i = 0; i <= steps; i++) {
    const a = a0 + ((a1 - a0) * i) / steps;
    out.push(place([o[0] + r * Math.cos(a), o[1] + r * Math.sin(a)]));
  }
  return out;
}
