/**
 * The Moon as an almanac gives it: how much of the face is lit, and whether it is waxing.
 * Low-precision formulae from Jean Meeus, Astronomical Algorithms (2nd ed.), chapters 47-48:
 * the illuminated fraction is good to about 0.01, ample for an engraved roundel.
 */

const RAD = Math.PI / 180;
const SYNODIC_MONTH = 29.530588853;

export type PhaseName =
  | 'New Moon'
  | 'Waxing Crescent'
  | 'First Quarter'
  | 'Waxing Gibbous'
  | 'Full Moon'
  | 'Waning Gibbous'
  | 'Last Quarter'
  | 'Waning Crescent';

export interface MoonPhase {
  /** Illuminated fraction of the disc, 0 to 1. */
  fraction: number;
  /** Position in the cycle, 0 to 1: 0 new, 0.25 first quarter, 0.5 full, 0.75 last quarter. */
  cycle: number;
  waxing: boolean;
  name: PhaseName;
}

export function julianDay(date: Date): number {
  return date.getTime() / 86_400_000 + 2_440_587.5;
}

const norm = (deg: number) => ((deg % 360) + 360) % 360;
const sin = (deg: number) => Math.sin(deg * RAD);
const cos = (deg: number) => Math.cos(deg * RAD);

export function moonPhase(date: Date): MoonPhase {
  const T = (julianDay(date) - 2_451_545) / 36_525;
  // Mean elongation of the Moon, mean anomaly of the Sun, mean anomaly of the Moon (Meeus 47).
  const D = norm(
    297.8501921 + 445267.1114034 * T - 0.0018819 * T ** 2 + T ** 3 / 545868 - T ** 4 / 113065000,
  );
  const M = norm(357.5291092 + 35999.0502909 * T - 0.0001536 * T ** 2 + T ** 3 / 24490000);
  const Mp = norm(
    134.9633964 + 477198.8675055 * T + 0.0087414 * T ** 2 + T ** 3 / 69699 - T ** 4 / 14712000,
  );
  // Phase angle (Meeus 48.4).
  const i = norm(
    180 -
      D -
      6.289 * sin(Mp) +
      2.1 * sin(M) -
      1.274 * sin(2 * D - Mp) -
      0.658 * sin(2 * D) -
      0.214 * sin(2 * Mp) -
      0.11 * sin(D),
  );
  const fraction = (1 + cos(i)) / 2;
  const cycle = norm(180 - i) / 360;
  return { fraction, cycle, waxing: cycle < 0.5, name: phaseName(cycle) };
}

/** A principal phase is named within a day of its instant; between them, the long names. */
export function phaseName(cycle: number): PhaseName {
  const day = 1 / SYNODIC_MONTH;
  const near = (target: number) =>
    Math.min(Math.abs(cycle - target), 1 - Math.abs(cycle - target)) <= day;
  if (near(0)) return 'New Moon';
  if (near(0.25)) return 'First Quarter';
  if (near(0.5)) return 'Full Moon';
  if (near(0.75)) return 'Last Quarter';
  if (cycle < 0.25) return 'Waxing Crescent';
  if (cycle < 0.5) return 'Waxing Gibbous';
  if (cycle < 0.75) return 'Waning Gibbous';
  return 'Waning Crescent';
}

/**
 * The lit part of a disc of radius r centred on (c, c), as seen from the northern hemisphere:
 * the limb on the lit side, closed by the terminator, an ellipse whose half-width is
 * r·|1 - 2·fraction|. Waxing light stands on the right, waning on the left.
 */
export function litPath(
  phase: Pick<MoonPhase, 'fraction' | 'waxing'>,
  c: number,
  r: number,
): string {
  const f = Math.min(1, Math.max(0, phase.fraction));
  if (f < 0.005) return '';
  const rx = +(r * Math.abs(1 - 2 * f)).toFixed(3);
  const side = phase.waxing ? 1 : 0;
  // Crescent: the terminator bows toward the lit limb; gibbous: away from it.
  const bow = f < 0.5 ? 1 - side : side;
  const top = `${c} ${c - r}`;
  const bottom = `${c} ${c + r}`;
  return `M${top}A${r} ${r} 0 0 ${side} ${bottom}A${rx} ${r} 0 0 ${bow} ${top}Z`;
}

/** "Waxing Gibbous, 78 per cent lit": the roundel's accessible description. */
export function describe(phase: MoonPhase): string {
  return `${phase.name}, ${Math.round(phase.fraction * 100)} per cent lit`;
}
