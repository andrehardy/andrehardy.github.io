/**
 * The illuminated initials of the other eleven (R-TYPE-01, R-FLO-*-INI). Each is the passage's
 * own first letter, set in the archetype's face and laid in gold, with an ornament drawn
 * about it by that archetype's hand: rays on lapis, a shield, entoptic dots, roots, nightshade,
 * a mirror, a chain, small bones, a stave, a scorch, the signs of the seven metals. The
 * ornament draws first and the gold is laid last; a few ornaments (the chain, the stave's
 * upper lines) are drawn over the gold, and the passage waits for those too.
 */
import { polylineD, type Pt } from './ink';
import { beziers, corners, polar, ring } from './drawings/kit';
import { shieldOutline } from './drawings/sky';

export interface Ornament {
  /** Path data in the initial's 100-unit square. */
  d?: string;
  /** A dot, which surfaces rather than draws. */
  dot?: { at: Pt; r: number };
  /** Drawn over the gold, after it is laid. */
  over?: boolean;
  /** A filled shape (a leaf, a berry, a bone's knuckle) rather than a line. */
  fill?: boolean;
  weight?: number;
}

export interface OrnamentCapital {
  kind: string;
  /** The face the letter is cut in (a CSS font-family value). */
  face: string;
  style?: 'italic';
  weight?: number;
  /** The ground behind the letter. */
  field: 'well' | 'lapis' | 'char' | 'ground';
  ornaments: Ornament[];
  /** The letter is shown a second time, mirrored, a little out of true. */
  mirrored?: boolean;
}

const at = (pts: Pt[], s = 1, ox = 50, oy = 50): string =>
  polylineD(pts.map(([x, y]) => [ox + x * s, oy + y * s]));

const leaf = (base: Pt, deg: number, len: number, w: number): string => {
  const tip = [
    base[0] + len * Math.cos((deg * Math.PI) / 180),
    base[1] + len * Math.sin((deg * Math.PI) / 180),
  ] as Pt;
  const n = [-(tip[1] - base[1]) / len, (tip[0] - base[0]) / len];
  const mid = (t: number, side: number): Pt => [
    base[0] + (tip[0] - base[0]) * t + n[0]! * w * side,
    base[1] + (tip[1] - base[1]) * t + n[1]! * w * side,
  ];
  return polylineD(
    [
      ...beziers([base, mid(0.3, 1), mid(0.7, 1), tip], 10),
      ...beziers([tip, mid(0.7, -1), mid(0.3, -1), base], 10).slice(1),
    ],
    true,
  );
};

const bone = (a: Pt, b: Pt): Ornament[] => [
  { d: polylineD([a, b]), weight: 2.4 },
  ...[a, b].flatMap(([x, y]) => {
    const dx = b[0] - a[0];
    const dy = b[1] - a[1];
    const l = Math.hypot(dx, dy);
    const nx = (-dy / l) * 1.5;
    const ny = (dx / l) * 1.5;
    return [
      { dot: { at: [x + nx, y + ny] as Pt, r: 1.7 } },
      { dot: { at: [x - nx, y - ny] as Pt, r: 1.7 } },
    ];
  }),
];

/** The signs of the seven metals, each in a 10-unit cell centred on c. */
export function metalSign(name: string, c: Pt, s = 1): string[] {
  return metalStrokes(name).map((pts) =>
    polylineD(pts.map(([x, y]) => [c[0] + x * s, c[1] + y * s])),
  );
}

/** The strokes of a planetary metal's sign, about its own centre, some ten units across. */
export function metalStrokes(name: string): Pt[][] {
  const P = (pts: Pt[]) => pts;
  const circle = (r: number, oy = 0) => ring(r, [0, oy], 32);
  switch (name) {
    case 'sol':
      return [circle(4), P(ring(0.6, [0, 0], 8))];
    case 'luna':
      return [
        P(
          beziers(
            [
              [1, -4.5],
              [-5, -3.5],
              [-5, 3.5],
              [1, 4.5],
              [-2.5, 2.5],
              [-2.5, -2.5],
              [1, -4.5],
            ],
            12,
          ),
        ),
      ];
    case 'mercurius':
      return [
        circle(2.4, -0.6),
        P(ring(1.8, [0, -4.6], 12).slice(26, 74)),
        P([
          [0, 1.8],
          [0, 5],
        ]),
        P([
          [-1.6, 3.6],
          [1.6, 3.6],
        ]),
      ];
    case 'venus':
      return [
        circle(2.8, -1.6),
        P([
          [0, 1.2],
          [0, 5],
        ]),
        P([
          [-1.8, 3.2],
          [1.8, 3.2],
        ]),
      ];
    case 'mars':
      return [
        circle(2.8, 1.4),
        P([
          [2, -0.6],
          [4.4, -3],
        ]),
        P([
          [1.8, -3],
          [4.4, -3],
          [4.4, -0.4],
        ]),
      ];
    case 'iupiter':
      return [
        P(
          beziers(
            [
              [-3, -2],
              [-2, -4.5],
              [1, -4],
              [-1.5, 1.5],
            ],
            10,
          ),
        ),
        P([
          [-3, 1.5],
          [3.5, 1.5],
        ]),
        P([
          [1.6, -4],
          [1.6, 4.5],
        ]),
      ];
    case 'saturnus':
      return [
        P([
          [-1.5, -4.5],
          [-1.5, 3],
        ]),
        P([
          [-3.2, -2.8],
          [0.2, -2.8],
        ]),
        P(
          beziers(
            [
              [-1.5, 0],
              [1, -2],
              [3.5, 0],
              [0.5, 4.5],
            ],
            10,
          ),
        ),
      ];
  }
  throw new Error(`no sign for ${name}`);
}

export const METALS = ['sol', 'luna', 'mercurius', 'venus', 'mars', 'iupiter', 'saturnus'] as const;

const CAPITALS: Record<string, () => Omit<OrnamentCapital, 'kind'>> = {
  'gilded-lapis-capital': () => ({
    face: 'var(--font-seal)',
    weight: 600,
    field: 'lapis',
    ornaments: [
      { d: at(ring(34)), weight: 0.8 },
      ...Array.from({ length: 16 }, (_, k) => ({
        d: at([polar(36, k * 22.5 - 90), polar(k % 2 ? 44 : 50, k * 22.5 - 90)]),
        weight: k % 2 ? 0.6 : 1,
      })),
    ],
  }),
  'shield-capital': () => ({
    face: 'var(--font-display)',
    weight: 600,
    field: 'well',
    ornaments: [
      { d: at(shieldOutline(), 50), weight: 1.4 },
      { d: at(shieldOutline(0.88), 50), weight: 0.6 },
    ],
  }),
  'entoptic-capital': () => {
    const zig = (y: number): Pt[] =>
      Array.from({ length: 13 }, (_, i) => [4 + i * 7.67, y + (i % 2 ? 5 : -5)]);
    const dots: Ornament[] = [];
    for (let i = 0; i < 6; i++)
      for (const y of [22, 78])
        dots.push({ dot: { at: [10 + i * 16 + (y > 50 ? 8 : 0), y], r: 1.4 } });
    const spiral: Pt[] = Array.from({ length: 60 }, (_, i) =>
      polar(1 + (i / 60) * 7, (i / 60) * 2.5 * 360),
    );
    return {
      face: 'var(--font-margin)',
      field: 'well',
      ornaments: [
        { d: polylineD(zig(9)), weight: 1 },
        { d: polylineD(zig(91)), weight: 1 },
        ...dots,
        { d: at(spiral, 1, 88, 50), weight: 0.8 },
        { d: at(spiral, 1, 12, 50), weight: 0.8 },
      ],
    };
  },
  'root-capital': () => ({
    face: 'var(--font-body)',
    field: 'well',
    ornaments: [
      {
        d: polylineD(
          beziers(
            [
              [50, 100],
              [44, 84],
              [20, 86],
              [12, 70],
              [4, 54],
              [22, 40],
              [8, 22],
            ],
            14,
          ),
        ),
        weight: 1.3,
      },
      {
        d: polylineD(
          beziers(
            [
              [50, 100],
              [58, 86],
              [80, 88],
              [88, 72],
              [96, 56],
              [78, 44],
              [92, 26],
            ],
            14,
          ),
        ),
        weight: 1.3,
      },
      {
        d: polylineD(
          beziers(
            [
              [12, 70],
              [26, 74],
              [30, 92],
              [40, 96],
            ],
            10,
          ),
        ),
        weight: 0.7,
      },
      {
        d: polylineD(
          beziers(
            [
              [88, 72],
              [74, 76],
              [70, 92],
              [60, 96],
            ],
            10,
          ),
        ),
        weight: 0.7,
      },
      {
        d: polylineD(
          beziers(
            [
              [8, 22],
              [14, 10],
              [30, 14],
              [34, 4],
            ],
            10,
          ),
        ),
        weight: 0.7,
      },
      {
        d: polylineD(
          beziers(
            [
              [92, 26],
              [86, 12],
              [70, 16],
              [66, 4],
            ],
            10,
          ),
        ),
        weight: 0.7,
      },
    ],
  }),
  'nightshade-capital': () => ({
    face: 'var(--font-margin)',
    style: 'italic',
    field: 'well',
    ornaments: [
      {
        d: polylineD(
          beziers(
            [
              [6, 98],
              [2, 70],
              [20, 64],
              [10, 40],
              [2, 18],
              [24, 4],
              [44, 6],
              [66, 8],
              [84, 2],
              [96, 14],
            ],
            16,
          ),
        ),
        weight: 1.2,
      },
      { d: leaf([10, 72], 200, 14, 4), fill: true },
      { d: leaf([12, 44], -20, 13, 4), fill: true },
      { d: leaf([30, 5], 250, 11, 3.5), fill: true },
      { d: leaf([70, 7], 80, 12, 3.6), fill: true },
      {
        d: polylineD([
          [96, 14],
          [94, 26],
        ]),
        weight: 0.6,
      },
      { dot: { at: [94, 29], r: 3.4 } },
      { dot: { at: [89, 33], r: 2.8 } },
      { dot: { at: [97, 35], r: 2.6 } },
      {
        d: at(
          Array.from({ length: 11 }, (_, i) => polar(i % 2 ? 2 : 6, i * 36 - 90)),
          1,
          52,
          7,
        ),
        weight: 0.7,
      },
    ],
  }),
  'mirrored-capital': () => ({
    face: 'var(--font-display)',
    style: 'italic',
    weight: 300,
    field: 'well',
    mirrored: true,
    ornaments: [
      {
        d: polylineD([
          [50, 0],
          [50, 100],
        ]),
        weight: 0.4,
      },
      {
        d: polylineD(
          beziers(
            [
              [50, 4],
              [30, 12],
              [44, 30],
              [24, 40],
              [6, 50],
              [26, 70],
              [10, 96],
            ],
            14,
          ),
        ),
        weight: 0.9,
      },
      {
        d: polylineD(
          beziers(
            [
              [50, 4],
              [70, 12],
              [56, 30],
              [76, 40],
              [94, 50],
              [74, 70],
              [90, 96],
            ],
            14,
          ),
        ),
        weight: 0.9,
      },
      { dot: { at: [24, 40], r: 2.2 } },
      { dot: { at: [76, 40], r: 2.2 } },
    ],
  }),
  'chained-blackletter': () => {
    const links: Ornament[] = [];
    for (let i = 0; i < 9; i++) {
      const c: Pt = [2 + i * 12, 4 + i * 11.5];
      const pts = ring(1, [0, 0], 24).map(([x, y]): Pt => {
        const [ex, ey] = i % 2 ? [3.2, 6.2] : [6.2, 3.2];
        const a = Math.PI / 4;
        const px = x * ex;
        const py = y * ey;
        return [
          c[0] + px * Math.cos(a) - py * Math.sin(a),
          c[1] + px * Math.sin(a) + py * Math.cos(a),
        ];
      });
      links.push({ d: polylineD(pts, true), over: true, weight: 1.3 });
    }
    return {
      face: 'var(--font-blackletter)',
      field: 'well',
      ornaments: [
        {
          d: polylineD(
            corners([
              [0, 0],
              [100, 0],
              [100, 100],
              [0, 100],
              [0, 0],
            ]),
          ),
          weight: 0.5,
        },
        ...links,
      ],
    };
  },
  'ossuary-capital': () => {
    const bones: Ornament[] = [];
    for (let i = 0; i < 5; i++) {
      bones.push(...bone([8 + i * 19, 4], [20 + i * 19, 4]));
      bones.push(...bone([8 + i * 19, 96], [20 + i * 19, 96]));
    }
    for (let i = 0; i < 4; i++) {
      bones.push(...bone([4, 14 + i * 21], [4, 26 + i * 21]));
      bones.push(...bone([96, 14 + i * 21], [96, 26 + i * 21]));
    }
    return { face: 'var(--font-smallcaps)', field: 'well', ornaments: bones };
  },
  'stave-woven-capital': () => ({
    face: 'var(--font-display)',
    style: 'italic',
    weight: 500,
    field: 'well',
    ornaments: [
      ...[30, 40, 50, 60, 70].map((y, i) => ({
        d: polylineD([
          [0, y],
          [100, y],
        ]),
        weight: 0.7,
        over: i % 2 === 1,
      })),
      {
        d: polylineD(
          beziers(
            [
              [10, 88],
              [2, 70],
              [20, 54],
              [12, 40],
              [4, 26],
              [18, 12],
              [14, 4],
            ],
            12,
          ),
        ),
        weight: 1.1,
      },
    ],
  }),
  'burned-capital': () => {
    const rough: Pt[] = Array.from({ length: 41 }, (_, i) => {
      const a = (i / 40) * 360;
      const r = 44 + Math.sin(i * 2.7) * 3.5 + Math.sin(i * 7.1) * 2;
      return polar(r, a);
    });
    const crack = (a: number, len: number): Pt[] => [
      polar(30, a),
      polar(30 + len * 0.5, a + 6),
      polar(30 + len, a - 3),
    ];
    return {
      face: 'var(--font-display)',
      weight: 600,
      field: 'char',
      ornaments: [
        { d: at(rough), weight: 1.6 },
        ...[20, 95, 160, 230, 300].map((a) => ({ d: at(crack(a, 16)), weight: 0.8 })),
      ],
    };
  },
  'planetary-capital': () => ({
    face: 'var(--font-seal)',
    field: 'well',
    ornaments: METALS.flatMap((m, i) => {
      const c: Pt = i < 4 ? [12 + i * 25.3, 8] : [24.6 + (i - 4) * 25.3, 92];
      return metalSign(m, c, 0.9).map((d) => ({ d, weight: 0.8 }));
    }),
  }),
};

export const ORNAMENTED = Object.keys(CAPITALS);

export function ornamentCapital(kind: string): OrnamentCapital {
  const make = CAPITALS[kind];
  if (!make) throw new Error(`the ${kind} initial is not cut yet`);
  return { kind, ...make() };
}

/**
 * The choreography: the ornaments under the letter draw in turn, the gold is laid as the last
 * finishes, those over it draw after, and `finished` is when the passage may begin.
 */
export function ornamentTiming(cap: OrnamentCapital) {
  const under = cap.ornaments.filter((o) => !o.over).length;
  const over = cap.ornaments.length - under;
  const gap = Math.min(0.12, 2 / Math.max(1, cap.ornaments.length));
  const draw = 0.6;
  const gildAt = +((under - 1) * gap + draw - 0.2).toFixed(2);
  const gild = 0.7;
  const overAt = +(gildAt + gild * 0.6).toFixed(2);
  const end = over ? overAt + (over - 1) * gap + draw : gildAt + gild;
  return { gap, draw, gildAt, gild, overAt, finished: +end.toFixed(2) };
}
