/**
 * The sound of the registry (R-CHOR-05): off unless the reader turns it on, and then only the
 * voice of the leaf they are reading, faded in and out across each turn of the page. The
 * choice lasts for the reading session. A browser will not let sound start before the reader
 * has touched the page, so a session that resumes with sound on stays silent until they do.
 * The one switch is any [data-sound] button: the masthead's, or the Bard's on its folio.
 */
import {
  VOICES,
  voiceFor,
  type Bed,
  type Drone,
  type Events,
  type Hit,
  type Voice,
  type VoiceId,
} from './voices';

const KEY = 'mr-sound';
const FADE = 1.2;
const root = () => document.documentElement;

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let noise: { white: AudioBuffer; brown: AudioBuffer } | null = null;
let playing: { id: VoiceId; stop: () => void } | null = null;
let on = false;

export const soundOn = () => on;

/** The running context and the master bus, if sound is on and the reader has let it start. */
export function audio(): { ctx: AudioContext; out: AudioNode } | null {
  return ctx && master && ctx.state === 'running' ? { ctx, out: master } : null;
}

function buffers(c: AudioContext) {
  const make = (brown: boolean) => {
    const b = c.createBuffer(1, c.sampleRate * 2, c.sampleRate);
    const d = b.getChannelData(0);
    let last = 0;
    for (let i = 0; i < d.length; i++) {
      const w = Math.random() * 2 - 1;
      last = brown ? (last + 0.02 * w) / 1.02 : w;
      d[i] = brown ? last * 3.5 : w;
    }
    return b;
  };
  return { white: make(false), brown: make(true) };
}

const draw = ([lo, hi]: [number, number]) => lo + Math.random() * (hi - lo);

function filterOf(c: AudioContext, f: { type: BiquadFilterType; hz: number; q?: number }) {
  const n = c.createBiquadFilter();
  n.type = f.type;
  n.frequency.value = f.hz;
  if (f.q !== undefined) n.Q.value = f.q;
  return n;
}

/** A slow swell on a parameter, made from an oscillator added to it. */
function swell(c: AudioContext, param: AudioParam, base: number, rate: number, depth: number) {
  const lfo = c.createOscillator();
  const amt = c.createGain();
  lfo.frequency.value = rate;
  amt.gain.value = (base * depth) / 2;
  param.value = base * (1 - depth / 2);
  lfo.connect(amt).connect(param);
  lfo.start();
  return lfo;
}

/** Plays one hit into `out`. */
export function strike(c: AudioContext, out: AudioNode, hit: Hit, when = c.currentTime) {
  const hz = hit.pick
    ? hit.pick[Math.floor(Math.random() * hit.pick.length)]!
    : Array.isArray(hit.hz)
      ? draw(hit.hz)
      : (hit.hz ?? 440);
  const env = c.createGain();
  env.gain.setValueAtTime(0.0001, when);
  env.gain.exponentialRampToValueAtTime(hit.gain, when + hit.attack);
  env.gain.exponentialRampToValueAtTime(0.0001, when + hit.attack + hit.decay);
  let tail: AudioNode = env;
  if (hit.filter) tail = env.connect(filterOf(c, hit.filter));
  tail.connect(out);
  const end = when + hit.attack + hit.decay + 0.05;
  if (hit.source === 'noise') {
    const src = c.createBufferSource();
    src.buffer = noise!.white;
    src.connect(env);
    src.start(when, Math.random());
    src.stop(end);
    return;
  }
  for (const [i, ratio] of (hit.partials ?? [1]).entries()) {
    const osc = c.createOscillator();
    osc.type = hit.source;
    osc.frequency.setValueAtTime(hz * ratio, when);
    if (hit.glide) osc.frequency.exponentialRampToValueAtTime(hz * ratio * hit.glide, end);
    const g = c.createGain();
    g.gain.value = 1 / (1 + i * 0.8);
    osc.connect(g).connect(env);
    osc.start(when);
    osc.stop(end);
  }
}

/** Starts a voice; returns its stop, which fades it out and lets it go. */
function play(c: AudioContext, out: AudioNode, voice: Voice): () => void {
  const bus = c.createGain();
  bus.gain.setValueAtTime(0.0001, c.currentTime);
  bus.gain.exponentialRampToValueAtTime(1, c.currentTime + FADE);
  bus.connect(out);
  const sources: AudioScheduledSourceNode[] = [];
  const timers: number[] = [];
  for (const layer of voice.layers) {
    if (layer.kind === 'drone') {
      const d = layer as Drone;
      const g = c.createGain();
      g.gain.value = d.gain;
      let tail: AudioNode = g;
      const f = d.filter && filterOf(c, d.filter);
      if (f) tail = g.connect(f);
      tail.connect(bus);
      d.partials.forEach((hz, i) => {
        const osc = c.createOscillator();
        osc.type = d.wave;
        osc.frequency.value = hz;
        osc.detune.value = (i % 2 ? 1 : -1) * 3;
        osc.connect(g);
        osc.start();
        sources.push(osc);
      });
      if (d.swell)
        sources.push(
          d.swell.target === 'filter' && f
            ? swell(c, f.frequency, f.frequency.value, d.swell.rate, d.swell.depth)
            : swell(c, g.gain, d.gain, d.swell.rate, d.swell.depth),
        );
    } else if (layer.kind === 'bed') {
      const b = layer as Bed;
      const src = c.createBufferSource();
      src.buffer = noise![b.color];
      src.loop = true;
      const f = filterOf(c, b.filter);
      const g = c.createGain();
      g.gain.value = b.gain;
      src.connect(f).connect(g).connect(bus);
      src.start(0, Math.random() * 1.5);
      sources.push(src);
      if (b.swell)
        sources.push(
          b.swell.target === 'filter'
            ? swell(c, f.frequency, b.filter.hz, b.swell.rate, b.swell.depth)
            : swell(c, g.gain, b.gain, b.swell.rate, b.swell.depth),
        );
    } else {
      const e = layer as Events;
      if (e.once !== undefined) {
        strike(c, bus, e.hit, c.currentTime + e.once);
        continue;
      }
      const every = e.every!;
      const next = () => {
        strike(c, bus, e.hit);
        timers.push(window.setTimeout(next, draw(every) * 1000));
      };
      timers.push(window.setTimeout(next, draw(every) * 1000));
    }
  }
  return () => {
    timers.forEach(clearTimeout);
    const t = c.currentTime;
    bus.gain.cancelScheduledValues(t);
    bus.gain.setValueAtTime(Math.max(0.0001, bus.gain.value), t);
    bus.gain.exponentialRampToValueAtTime(0.0001, t + FADE / 2);
    for (const s of sources) s.stop(t + FADE / 2 + 0.05);
    window.setTimeout(() => bus.disconnect(), (FADE / 2 + 0.2) * 1000);
  };
}

/** The voice the leaf now shown calls for, playing if sound is on and the context runs. */
function sync() {
  const id = voiceFor(document.body.dataset.archetype, document.body.dataset.realm);
  const live = audio();
  if (!soundOn() || !live) {
    playing?.stop();
    playing = null;
    delete root().dataset.soundVoice;
    return;
  }
  if (playing?.id !== id) {
    playing?.stop();
    playing = { id, stop: play(live.ctx, live.out, VOICES[id]) };
  }
  root().dataset.soundVoice = id;
}

/** Wakes the context inside a gesture of the reader's, which is the only time a browser allows it. */
async function wake() {
  if (!soundOn()) return;
  if (!ctx) {
    ctx = new AudioContext();
    master = ctx.createGain();
    master.gain.value = 0.8;
    master.connect(ctx.destination);
    noise = buffers(ctx);
  }
  if (ctx.state !== 'running') await ctx.resume().catch(() => undefined);
  sync();
}

/** Every switch shows the one state, and the root carries it for the stylesheets. */
function reflect() {
  root().toggleAttribute('data-sound-on', on);
  document
    .querySelectorAll('button[data-sound]')
    .forEach((b) => b.setAttribute('aria-pressed', String(on)));
}

function set(next: boolean) {
  on = next;
  try {
    sessionStorage.setItem(KEY, on ? '1' : '0');
  } catch {
    // Storage refused: the choice lasts for this page.
  }
  reflect();
  if (on) void wake();
  else {
    sync();
    void ctx?.suspend();
  }
}

let bound = false;
export function bindSound() {
  if (bound) return;
  bound = true;
  try {
    on = sessionStorage.getItem(KEY) === '1';
  } catch {
    // Storage refused: sound starts off.
  }
  document.addEventListener('click', (e) => {
    const button = e.target instanceof Element ? e.target.closest('button[data-sound]') : null;
    if (button) set(!on);
  });
  const gesture = () => void wake();
  document.addEventListener('pointerdown', gesture, { passive: true });
  document.addEventListener('keydown', gesture, { passive: true });
  document.addEventListener('astro:after-swap', reflect);
  document.addEventListener('astro:page-load', () => {
    reflect();
    sync();
  });
  reflect();
}

export { VOICES };
