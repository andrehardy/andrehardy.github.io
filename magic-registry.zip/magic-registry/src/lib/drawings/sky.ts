/**
 * The sigils of the Sky (R-ID-CLE-03, R-ID-PAL-03, R-ID-SHA-03, R-ID-DRU-03).
 *
 * - Cleric: rays turned about a centre. Every cut is repeated at each twelfth of a turn, so the
 *   figure is the same from every side, as light is.
 * - Paladin: the ordinaries laid on a heater shield. Every line is straight and every mark has
 *   its twin across the pale; nothing is curved but the shield's own base.
 * - Shaman: the forms seen behind closed eyes (dots, zigzags, a spiral) set inside the
 *   concentric rings of a frame drum, all about one centre.
 * - Druid: seeds set one by one at the golden angle, each a little further out (r ∝ √n), inside
 *   one growth ring, with threads of mycelium reaching past it.
 */
import {
  arc,
  beziers,
  corners,
  dot,
  line,
  polar,
  ring,
  seeded,
  stroke,
  type Drawing,
  type DrawMark,
  type Pt,
} from './kit';

export const CLERIC_FOLD = 12;

export function clericDrawing(): Drawing {
  const marks: DrawMark[] = [stroke('limit', ring(1), 'guide'), stroke('halo', ring(0.3))];
  marks.push(stroke('halo-outer', ring(0.42)));
  const step = 360 / CLERIC_FOLD;
  // A long ray on each twelfth of the turn, a short one between: still the same from every side.
  for (let k = 0; k < CLERIC_FOLD * 2; k++) {
    const a = (k * step) / 2 - 90;
    const long = k % 2 === 0;
    marks.push(stroke(`ray-${k}`, line(polar(0.48, a), polar(long ? 0.97 : 0.72, a), 16)));
  }
  for (let k = 0; k < CLERIC_FOLD; k++) {
    const a = k * step - 90;
    // A petal of the rose between the two halos, on the same twelfth of the turn as its ray.
    const pts = arc(
      ...polar(0.36, a),
      0.06,
      ((a + 90) * Math.PI) / 180,
      ((a + 270) * Math.PI) / 180,
      16,
    );
    marks.push(stroke(`petal-${k}`, pts));
  }
  for (let k = 0; k < CLERIC_FOLD; k++) {
    const a = k * step - 90 + step / 2;
    marks.push(dot(`star-${k}`, polar(0.86, a), 0.022));
  }
  marks.push(dot('source', [0, 0], 0.06));
  return { marks, focus: [0, 0] };
}

/** The heater shield: a straight chief, straight flanks, and a base swept to a point. */
export function shieldOutline(scale = 1): Pt[] {
  const s = (p: Pt): Pt => [p[0] * scale, p[1] * scale];
  const top: Pt[] = corners([s([0.72, -0.86]), s([-0.72, -0.86]), s([-0.72, 0.02])], 14);
  const left = beziers([s([-0.72, 0.02]), s([-0.72, 0.5]), s([-0.4, 0.8]), s([0, 0.98])], 24);
  const right = beziers([s([0, 0.98]), s([0.4, 0.8]), s([0.72, 0.5]), s([0.72, 0.02])], 24);
  return [
    ...top,
    ...left.slice(1),
    ...right.slice(1),
    ...corners([s([0.72, 0.02]), s([0.72, -0.86])], 14).slice(1),
  ];
}

export function paladinDrawing(): Drawing {
  const marks: DrawMark[] = [
    stroke('pale-guide', line([0, -1], [0, 1], 4), 'guide'),
    stroke('fess-guide', line([-0.8, -0.1], [0.8, -0.1], 4), 'guide'),
    stroke('shield', shieldOutline()),
    stroke('bordure', shieldOutline(0.86)),
    stroke(
      'chief',
      corners(
        [
          [-0.62, -0.46],
          [0.62, -0.46],
        ],
        16,
      ),
    ),
    stroke(
      'chevron-upper',
      corners(
        [
          [-0.56, 0.42],
          [0, -0.16],
          [0.56, 0.42],
        ],
        12,
      ),
    ),
    stroke(
      'chevron-lower',
      corners(
        [
          [-0.46, 0.62],
          [0, 0.06],
          [0.46, 0.62],
        ],
        12,
      ),
    ),
  ];
  for (const [i, x] of [-0.38, 0, 0.38].entries())
    marks.push(dot(`roundel-${i}`, [x, -0.66], 0.075));
  marks.push(dot('roundel-base', [0, 0.6], 0.06));
  return { marks, focus: [0, 0.6] };
}

export const SHAMAN_RINGS = [1, 0.9, 0.6, 0.3];

export function shamanDrawing(): Drawing {
  const marks: DrawMark[] = SHAMAN_RINGS.map((r, i) => stroke(`ring-${i}`, ring(r)));
  const teeth = 24;
  const zig: Pt[] = [];
  for (let i = 0; i <= teeth * 2; i++)
    zig.push(polar(i % 2 === 0 ? 0.65 : 0.85, (i * 360) / (teeth * 2) - 90));
  marks.push(stroke('zigzag', zig));
  // The dot field between the inner rings: three circles of points, offset like woven grain.
  for (const [band, r] of [0.38, 0.46, 0.54].entries()) {
    const n = 12 + band * 4;
    for (let k = 0; k < n; k++)
      marks.push(dot(`dot-${band}-${k}`, polar(r, (k * 360) / n + band * 7.5 - 90), 0.016));
  }
  const spiral: Pt[] = [];
  for (let i = 0; i <= 160; i++) {
    const t = i / 160;
    spiral.push(polar(0.03 + 0.23 * t, t * 3 * 360 - 90));
  }
  marks.push(stroke('spiral', spiral));
  return { marks, focus: spiral.at(-1)! };
}

export const GOLDEN_ANGLE = 180 * (3 - Math.sqrt(5));
/** A Fibonacci count, so the 8, 13 and 21 spirals of the head all show at sigil size. */
export const DRUID_SEEDS = 144;
const SEED_SPREAD = 0.86 / Math.sqrt(DRUID_SEEDS);

export function druidDrawing(): Drawing {
  const marks: DrawMark[] = [stroke('growth-ring-rim', ring(0.9))];
  for (let n = 1; n <= DRUID_SEEDS; n++)
    marks.push(
      dot(
        `seed-${n}`,
        polar(SEED_SPREAD * Math.sqrt(n), n * GOLDEN_ANGLE - 90),
        0.012 + 0.016 * (n / DRUID_SEEDS),
      ),
    );
  const rand = seeded(23);
  for (let k = 0; k < 7; k++) {
    const a = (k * 360) / 7 + rand() * 20 - 100;
    const from = polar(0.9, a);
    const mid = polar(0.97, a + 6 + rand() * 6);
    const to = polar(1.04, a + 12 + rand() * 10);
    marks.push(stroke(`mycelium-${k}`, beziers([from, polar(0.93, a + 2), mid, to], 16)));
    const fork = polar(1.02, a - 8 - rand() * 8);
    marks.push(stroke(`mycelium-${k}-fork`, beziers([mid, polar(0.99, a + 2), fork, fork], 10)));
  }
  return {
    marks,
    focus: polar(SEED_SPREAD * Math.sqrt(DRUID_SEEDS), DRUID_SEEDS * GOLDEN_ANGLE - 90),
  };
}
