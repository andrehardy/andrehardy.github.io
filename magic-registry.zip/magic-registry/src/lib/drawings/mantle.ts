/**
 * The sigils of the Deep Mantle (R-ID-WIT-03, R-ID-ENC-03, R-ID-WAR-03, R-ID-NEC-03, R-ID-BAR-03).
 *
 * - Witch: a pressed specimen of nightshade, drawn from the root up as a botanist draws a plate.
 *   Leaves alternate up the stem and no two are alike; nothing in it is symmetric.
 * - Enchantress: a hand-glass drawn in curves only, every one of them answered by its reflection
 *   across the middle. There is no straight line in it anywhere.
 * - Warlock: a seal bound by a closed chain. The links alternate, one seen flat and the next on
 *   its edge, each passing through its neighbours, so the chain has no end.
 * - Necromancer: an ossuary rosette, as the bone-houses set them: long bones turned about a skull
 *   at each eighth of a turn, every bone with its knuckles at both ends, ringed by vertebrae.
 * - Bard: the nodal lines of a struck square plate (a Chladni figure), traced where its
 *   vibration is zero, drawn from the clamp outward as the sand gathers.
 */
import {
  beziers,
  corners,
  dot,
  line,
  polar,
  ring,
  rotate,
  seeded,
  stroke,
  type Drawing,
  type DrawMark,
  type Pt,
} from './kit';

const add = (a: Pt, b: Pt, k = 1): Pt => [a[0] + b[0] * k, a[1] + b[1] * k];
const unit = ([x, y]: Pt): Pt => {
  const l = Math.hypot(x, y) || 1;
  return [x / l, y / l];
};

/* ------------------------------------------------------------------ Witch */

/** The stem, from the root (t = 0) to the tip (t = 1). */
const STEM: [Pt, Pt, Pt, Pt] = [
  [0.1, 0.82],
  [0.24, 0.3],
  [-0.3, -0.18],
  [-0.08, -0.88],
];

function stemAt(t: number): { p: Pt; tan: Pt } {
  const [a, b, c, d] = STEM;
  const u = 1 - t;
  const p: Pt = [
    u * u * u * a[0] + 3 * u * u * t * b[0] + 3 * u * t * t * c[0] + t * t * t * d[0],
    u * u * u * a[1] + 3 * u * u * t * b[1] + 3 * u * t * t * c[1] + t * t * t * d[1],
  ];
  const tan: Pt = [
    3 * u * u * (b[0] - a[0]) + 6 * u * t * (c[0] - b[0]) + 3 * t * t * (d[0] - c[0]),
    3 * u * u * (b[1] - a[1]) + 6 * u * t * (c[1] - b[1]) + 3 * t * t * (d[1] - c[1]),
  ];
  return { p, tan: unit(tan) };
}

/** Where each leaf joins the stem; the leaves alternate sides, beginning on the right. */
export const WITCH_LEAVES = [0.16, 0.3, 0.44, 0.58, 0.72];

export function witchDrawing(): Drawing {
  const rand = seeded(61);
  const marks: DrawMark[] = [
    stroke('label-rule', line([-0.62, 0.98], [-0.1, 0.98], 4), 'guide'),
    stroke('pin-guide', line([-0.5, -0.5], [0.5, -0.5], 4), 'guide'),
  ];
  const [root] = STEM;
  // The roots first, as the plant was lifted, each a little different.
  for (let k = 0; k < 4; k++) {
    const a = 60 + k * 22 + rand() * 10;
    const len = 0.16 + rand() * 0.12;
    const end = add(root, polar(len, a));
    const mid = add(root, polar(len * 0.5, a - 14 + rand() * 10));
    marks.push(stroke(`root-${k}`, beziers([root, mid, mid, end], 10)));
  }
  marks.push(stroke('stem', beziers(STEM, 48)));
  WITCH_LEAVES.forEach((t, i) => {
    const { p, tan } = stemAt(t);
    const side = i % 2 === 0 ? 1 : -1;
    const normal: Pt = [-tan[1] * side, tan[0] * side];
    const dir = unit(add(normal, tan, 0.75 + rand() * 0.3));
    const len = (0.36 - i * 0.035) * (0.85 + rand() * 0.3);
    const w = len * (0.32 + rand() * 0.1);
    const across: Pt = [-dir[1], dir[0]];
    const tip = add(p, dir, len);
    const at = (along: number, out: number): Pt => add(add(p, dir, len * along), across, out);
    marks.push(
      stroke(
        `leaf-${i}`,
        beziers(
          [p, at(0.25, w), at(0.7, w * 0.85), tip, at(0.7, -w * 0.8), at(0.25, -w * 1.05), p],
          14,
        ),
      ),
    );
    marks.push(stroke(`leaf-${i}-rib`, line(p, at(0.88, 0), 8)));
  });
  // A bell hanging from the upper stem, on a curved stalk.
  const bellFrom = stemAt(0.84).p;
  const bellTop = add(bellFrom, [0.22, 0.06]);
  marks.push(
    stroke(
      'bell-stalk',
      beziers([bellFrom, add(bellFrom, [0.1, -0.08]), add(bellTop, [0, -0.08]), bellTop], 12),
    ),
  );
  const mouth = 0.17;
  marks.push(
    stroke(
      'bell',
      beziers(
        [
          bellTop,
          add(bellTop, [-0.07, 0.01]),
          add(bellTop, [-0.08, mouth * 0.7]),
          add(bellTop, [-0.1, mouth]),
          add(bellTop, [-0.03, mouth + 0.03]),
          add(bellTop, [0.03, mouth + 0.03]),
          add(bellTop, [0.1, mouth]),
          add(bellTop, [0.08, mouth * 0.7]),
          add(bellTop, [0.07, 0.01]),
          bellTop,
        ],
        10,
      ),
    ),
  );
  // The berry, low on the stem on the far side from the bell, in its starred calyx.
  const berryFrom = stemAt(0.5).p;
  const berry = add(berryFrom, [-0.26, 0.12]);
  marks.push(
    stroke(
      'berry-stalk',
      beziers([berryFrom, add(berryFrom, [-0.1, -0.02]), add(berry, [0.06, -0.08]), berry], 12),
    ),
  );
  for (let k = 0; k < 5; k++) {
    const a = -90 + k * 72 + rand() * 12;
    marks.push(
      stroke(
        `sepal-${k}`,
        beziers(
          [
            berry,
            add(berry, polar(0.05, a - 12)),
            add(berry, polar(0.09, a + 6)),
            add(berry, polar(0.11, a)),
          ],
          6,
        ),
      ),
    );
  }
  marks.push(dot('berry', berry, 0.055));
  // The strips of tape that hold the specimen to the sheet.
  for (const [i, t] of [0.08, 0.64].entries()) {
    const { p, tan } = stemAt(t);
    const across: Pt = [-tan[1], tan[0]];
    marks.push(stroke(`tape-${i}`, line(add(p, across, -0.08), add(p, across, 0.08), 6)));
  }
  marks.push(dot('pin', [0.42, -0.5], 0.018));
  return { marks, focus: berry };
}

/* ------------------------------------------------------------ Enchantress */

const flip = (pts: Pt[]): Pt[] => pts.map(([x, y]) => [-x, y]);
const oval = (rx: number, ry: number, cy: number, n = 96): Pt[] =>
  ring(1, [0, 0], n).map(([x, y]) => [x * rx, cy + y * ry]);

export function enchantressDrawing(): Drawing {
  const marks: DrawMark[] = [
    stroke('axis', line([0, -1.02], [0, 1.02], 4), 'guide'),
    stroke('glass', oval(0.44, 0.54, -0.28)),
    stroke('glass-inner', oval(0.36, 0.45, -0.28)),
  ];
  const pair = (id: string, right: Pt[]) => {
    marks.push(stroke(`${id}-right`, right), stroke(`${id}-left`, flip(right)));
  };
  // The frame's scrolls, from the crest round to the throat of the handle.
  pair(
    'scroll',
    beziers(
      [
        [0.06, -0.86],
        [0.34, -0.98],
        [0.62, -0.7],
        [0.56, -0.36],
        [0.5, -0.02],
        [0.3, 0.3],
        [0.1, 0.32],
      ],
      18,
    ),
  );
  pair(
    'curl',
    beziers(
      [
        [0.56, -0.36],
        [0.7, -0.3],
        [0.74, -0.14],
        [0.62, -0.12],
        [0.54, -0.11],
        [0.56, -0.2],
        [0.6, -0.2],
      ],
      10,
    ),
  );
  // The handle tapers in a long double curve to its pearl.
  pair(
    'handle',
    beziers(
      [
        [0.1, 0.32],
        [0.24, 0.5],
        [-0.04, 0.64],
        [0.07, 0.86],
      ],
      18,
    ),
  );
  pair(
    'reflection',
    beziers(
      [
        [0.1, -0.62],
        [0.22, -0.56],
        [0.26, -0.4],
        [0.2, -0.26],
      ],
      12,
    ),
  );
  for (let k = 1; k <= 4; k++) {
    const [x, y] = polar(1, -90 + k * 30);
    const at: Pt = [x * 0.5, -0.28 + y * 0.6];
    marks.push(dot(`pearl-${k}-right`, at, 0.026), dot(`pearl-${k}-left`, [-at[0], at[1]], 0.026));
  }
  marks.push(dot('pearl-crest', [0, -0.92], 0.032));
  marks.push(dot('pearl-drop', [0, 0.93], 0.05));
  return { marks, focus: [0, 0.93] };
}

/* ---------------------------------------------------------------- Warlock */

export const WARLOCK_LINKS = 14;
export const WARLOCK_CHAIN_R = 0.76;
/** Half the length of a link, end to end: long enough to pass through both neighbours. */
export const WARLOCK_LINK_HALF = 0.23;

/** A link's outline: a stadium on the circle of the chain, laid along it. */
function link(k: number, flat: boolean): Pt[] {
  const theta = (k * 360) / WARLOCK_LINKS - 90;
  const b = flat ? 0.075 : 0.022;
  const a = WARLOCK_LINK_HALF - b;
  const local: Pt[] = [
    ...line([-a, -b], [a, -b], 10),
    ...Array.from({ length: 13 }, (_, i): Pt => {
      const t = -Math.PI / 2 + (i / 12) * Math.PI;
      return [a + b * Math.cos(t), b * Math.sin(t)];
    }).slice(1),
    ...line([a, b], [-a, b], 10).slice(1),
    ...Array.from({ length: 13 }, (_, i): Pt => {
      const t = Math.PI / 2 + (i / 12) * Math.PI;
      return [-a + b * Math.cos(t), b * Math.sin(t)];
    }).slice(1),
  ];
  const c = polar(WARLOCK_CHAIN_R, theta);
  // Local x runs along the chain (the tangent), local y outward.
  return local.map(([x, y]) => add(c, rotate([y, x], theta)));
}

export function warlockDrawing(): Drawing {
  const marks: DrawMark[] = [stroke('chain-guide', ring(WARLOCK_CHAIN_R), 'guide')];
  // The seal is written first, then bound.
  const rand = seeded(13);
  const wax = ring(0.5, [0, 0], 72).map(([x, y], i, all): Pt => {
    if (i === all.length - 1) return all[0]!;
    const k = 1 + (rand() - 0.5) * 0.08 + Math.sin(i * 0.7) * 0.02;
    return [x * k, y * k];
  });
  wax[wax.length - 1] = wax[0]!;
  marks.push(stroke('wax', wax), stroke('signet', ring(0.38)), stroke('signet-inner', ring(0.32)));
  // A heptagram {7/3}, cut in one unbroken line, as an oath is.
  const star: Pt[] = [];
  for (let i = 0; i <= 7; i++) star.push(polar(0.3, ((i * 3) % 7) * (360 / 7) - 90));
  marks.push(stroke('oath', corners(star, 8)));
  for (let k = 0; k < WARLOCK_LINKS; k++) marks.push(stroke(`link-${k}`, link(k, k % 2 === 0)));
  marks.push(dot('seal', [0, 0], 0.06));
  return { marks, focus: [0, 0] };
}

/* ------------------------------------------------------------ Necromancer */

export const NECRO_FOLD = 8;
export const NECRO_VERTEBRAE = 16;

/** One long bone, along the upward ray, from the skull outward. */
function bone(): { shaft: Pt[][]; knuckles: Pt[] } {
  const r0 = 0.34;
  const r1 = 0.82;
  const mid = (r0 + r1) / 2;
  const edge = (s: 1 | -1): Pt[] =>
    beziers(
      [
        [s * 0.026, -r0],
        [s * 0.016, -(r0 + mid) / 2],
        [s * 0.016, -(mid + r1) / 2],
        [s * 0.026, -r1],
      ],
      14,
    );
  return {
    shaft: [edge(1), edge(-1)],
    knuckles: [
      [-0.028, -r0 + 0.012],
      [0.028, -r0 + 0.012],
      [-0.028, -r1 - 0.012],
      [0.028, -r1 - 0.012],
    ],
  };
}

export function necromancerDrawing(): Drawing {
  const marks: DrawMark[] = [stroke('ring-guide', ring(0.94), 'guide')];
  // The skull at the centre, drawn first: everything else is laid about it.
  marks.push(
    stroke(
      'skull-cranium',
      beziers(
        [
          [-0.1, 0.17],
          [-0.2, 0.1],
          [-0.24, -0.2],
          [0, -0.24],
          [0.24, -0.2],
          [0.2, 0.1],
          [0.1, 0.17],
        ],
        18,
      ),
    ),
    stroke('skull-orbit-left', ring(0.055, [-0.085, -0.04], 24)),
    stroke('skull-orbit-right', ring(0.055, [0.085, -0.04], 24)),
    stroke(
      'skull-nose',
      corners(
        [
          [0, 0.03],
          [-0.025, 0.08],
          [0.025, 0.08],
          [0, 0.03],
        ],
        4,
      ),
    ),
    stroke('skull-teeth', line([-0.1, 0.17], [0.1, 0.17], 8)),
  );
  for (let t = -2; t <= 2; t++)
    marks.push(stroke(`skull-tooth-${t + 2}`, line([t * 0.04, 0.13], [t * 0.04, 0.2], 3)));
  const b = bone();
  for (let k = 0; k < NECRO_FOLD; k++) {
    const deg = (k * 360) / NECRO_FOLD;
    b.shaft.forEach((e, i) =>
      marks.push(
        stroke(
          `bone-${k}-shaft-${i}`,
          e.map((p) => rotate(p, deg)),
        ),
      ),
    );
    b.knuckles.forEach((c, i) =>
      marks.push(stroke(`bone-${k}-knuckle-${i}`, ring(0.03, rotate(c, deg), 24))),
    );
  }
  for (let k = 0; k < NECRO_VERTEBRAE; k++) {
    const c = polar(0.94, (k * 360) / NECRO_VERTEBRAE - 90 + 360 / NECRO_VERTEBRAE / 2);
    marks.push(stroke(`vertebra-${k}`, ring(0.04, c, 24)));
    marks.push(dot(`vertebra-${k}-canal`, c, 0.012));
  }
  return { marks, focus: [0, 0] };
}

/* ------------------------------------------------------------------- Bard */

/** The mode the plate is struck in: n and m half-waves across it. */
export const BARD_MODE = { n: 3, m: 7 } as const;
export const BARD_PLATE = 0.78;

/** The plate's vibration at a point; its nodal lines are where this is zero. */
export function chladni([x, y]: Pt, { n, m } = BARD_MODE): number {
  const u = (x + BARD_PLATE) / (2 * BARD_PLATE);
  const v = (y + BARD_PLATE) / (2 * BARD_PLATE);
  return (
    Math.cos(n * Math.PI * u) * Math.cos(m * Math.PI * v) -
    Math.cos(m * Math.PI * u) * Math.cos(n * Math.PI * v)
  );
}

/** Marching squares over the plate: the zero-crossings of `f`, joined into lines. */
export function nodalLines(f: (p: Pt) => number, half: number, cells = 48): Pt[][] {
  const h = (2 * half) / cells;
  const P = (i: number, j: number): Pt => [-half + i * h, -half + j * h];
  const val: number[][] = [];
  for (let i = 0; i <= cells; i++) {
    val[i] = [];
    for (let j = 0; j <= cells; j++) {
      const z = f(P(i, j));
      val[i]![j] = Math.abs(z) < 1e-9 ? 1e-9 : z;
    }
  }
  const cross = (i0: number, j0: number, i1: number, j1: number): Pt => {
    const a = val[i0]![j0]!;
    const b = val[i1]![j1]!;
    const t = a / (a - b);
    const [x0, y0] = P(i0, j0);
    const [x1, y1] = P(i1, j1);
    return [x0 + (x1 - x0) * t, y0 + (y1 - y0) * t];
  };
  const segs: [Pt, Pt][] = [];
  for (let i = 0; i < cells; i++)
    for (let j = 0; j < cells; j++) {
      const s = [val[i]![j]!, val[i + 1]![j]!, val[i + 1]![j + 1]!, val[i]![j + 1]!].map(
        (z) => z > 0,
      );
      const edges: Pt[] = [];
      const e: [number, number, number, number][] = [
        [i, j, i + 1, j],
        [i + 1, j, i + 1, j + 1],
        [i + 1, j + 1, i, j + 1],
        [i, j + 1, i, j],
      ];
      e.forEach(([a, b, c, d], k) => {
        if (s[k] !== s[(k + 1) % 4]) edges.push(cross(a, b, c, d));
      });
      if (edges.length === 2) segs.push([edges[0]!, edges[1]!]);
      else if (edges.length === 4) {
        const centre = (val[i]![j]! + val[i + 1]![j]! + val[i + 1]![j + 1]! + val[i]![j + 1]!) / 4;
        if (centre > 0 === s[0]) segs.push([edges[0]!, edges[1]!], [edges[2]!, edges[3]!]);
        else segs.push([edges[0]!, edges[3]!], [edges[1]!, edges[2]!]);
      }
    }
  const key = ([x, y]: Pt) => `${x.toFixed(6)},${y.toFixed(6)}`;
  const at = new Map<string, number[]>();
  segs.forEach(([a, b], k) => {
    for (const p of [a, b]) at.set(key(p), [...(at.get(key(p)) ?? []), k]);
  });
  const used = new Set<number>();
  const lines: Pt[][] = [];
  const walk = (pts: Pt[]) => {
    for (;;) {
      const end = pts.at(-1)!;
      const next = (at.get(key(end)) ?? []).find((k) => !used.has(k));
      if (next === undefined) return;
      used.add(next);
      const [a, b] = segs[next]!;
      pts.push(key(a) === key(end) ? b : a);
    }
  };
  segs.forEach(([a, b], k) => {
    if (used.has(k)) return;
    used.add(k);
    const fwd: Pt[] = [a, b];
    walk(fwd);
    const back: Pt[] = [fwd[0]!];
    walk(back);
    lines.push([...back.slice(1).reverse(), ...fwd]);
  });
  return lines;
}

export function bardDrawing(): Drawing {
  const s = BARD_PLATE;
  const marks: DrawMark[] = [];
  for (let k = 0; k < 5; k++) {
    const y = -0.92 + k * 0.035;
    marks.push(stroke(`stave-${k}`, line([-0.42, y], [0.42, y], 4), 'guide'));
  }
  marks.push(
    stroke(
      'plate',
      corners(
        [
          [-s, -s],
          [s, -s],
          [s, s],
          [-s, s],
          [-s, -s],
        ],
        12,
      ),
    ),
  );
  const mean = (pts: Pt[]) => pts.reduce((t, [x, y]) => t + Math.hypot(x, y), 0) / pts.length;
  nodalLines(chladni, s * 0.985)
    .filter((l) => l.length > 3)
    .sort((a, b) => mean(a) - mean(b))
    .forEach((l, i) => marks.push(stroke(`node-${i}`, l)));
  marks.push(dot('clamp', [0, 0], 0.035));
  return { marks, focus: [0, 0] };
}
