/**
 * The sigils of the Threshold (R-ID-SOR-03, R-ID-ALC-03).
 *
 * - Sorcerer: a Lichtenberg figure, the branching scar that a discharge leaves in what it passes
 *   through. It grows from the wound at the centre outward; every branch leaves from a point on
 *   the branch before it and only ever runs further out. It is seeded, so it is the same figure
 *   every time, as a scar is.
 * - Alchemist: an apparatus diagram (furnace, cucurbit, still-head, beak and receiver) set inside
 *   the seven planetary metals, which are drawn in the order of the Work, from lead to gold.
 */
import { metalStrokes } from '../ornaments';
import {
  arc,
  beziers,
  corners,
  dot,
  line,
  polar,
  ring,
  seeded,
  stroke,
  type Drawing,
  type DrawMark,
  type Pt,
} from './kit';

/* --------------------------------------------------------------- Sorcerer */

export const SORCERER_ARMS = 5;
/** No step turns more than this from straight outward. */
export const SORCERER_MAX_SWERVE = 55;
export const SORCERER_REACH = 0.96;

interface Branch {
  id: string;
  pts: Pt[];
  depth: number;
}

export function sorcererDrawing(): Drawing {
  const rand = seeded(1879);
  const branches: Branch[] = [];
  const grow = (id: string, from: Pt, heading: number, len: number, depth: number) => {
    const pts: Pt[] = [from];
    const steps = Math.max(3, Math.round(len / 0.035));
    let h = heading;
    for (let s = 0; s < steps; s++) {
      const [x, y] = pts.at(-1)!;
      const out = (Math.atan2(y, x) * 180) / Math.PI;
      h += rand() * 50 - 25;
      let off = ((h - out + 540) % 360) - 180;
      off = Math.max(-SORCERER_MAX_SWERVE, Math.min(SORCERER_MAX_SWERVE, off));
      h = out + off;
      const [dx, dy] = polar(len / steps, h);
      const next: Pt = [x + dx, y + dy];
      if (Math.hypot(...next) > SORCERER_REACH) break;
      pts.push(next);
    }
    if (pts.length < 2) return;
    const branch = { id, pts, depth };
    branches.push(branch);
    if (depth >= 3) return;
    let child = 0;
    for (let i = 2; i < pts.length - 1; i++) {
      if (rand() > 0.2 - depth * 0.05) continue;
      const side = rand() < 0.5 ? -1 : 1;
      const [x, y] = pts[i]!;
      const out = (Math.atan2(y, x) * 180) / Math.PI;
      const rest = 1 - Math.hypot(x, y) / SORCERER_REACH;
      grow(
        `${id}.${child++}`,
        pts[i]!,
        out + side * (25 + rand() * 25),
        len * 0.55 * (0.5 + rest),
        depth + 1,
      );
    }
  };
  for (let k = 0; k < SORCERER_ARMS; k++) {
    const a = (k * 360) / SORCERER_ARMS - 90 + rand() * 30 - 15;
    grow(`arm-${k}`, polar(0.05, a), a, 0.9, 0);
  }
  const marks: DrawMark[] = [stroke('reach', ring(SORCERER_REACH), 'guide')];
  // The discharge goes out all at once, trunk by trunk, then the finer branches.
  branches
    .sort((a, b) => a.depth - b.depth)
    .forEach((b) => marks.push(stroke(`bolt-${b.id}`, b.pts)));
  // The cost: one drop of blood at the place it came from.
  marks.push(dot('wound', [0, 0], 0.05));
  return { marks, focus: [0, 0] };
}

/* -------------------------------------------------------------- Alchemist */

/** The seven metals in the order of the Work, from the basest to gold. */
export const WORK_ORDER = [
  'saturnus',
  'iupiter',
  'mars',
  'venus',
  'mercurius',
  'luna',
  'sol',
] as const;
export const METAL_RING = 0.84;

/** Where a metal's sign stands: evenly round the ring, lead at the top, clockwise. */
export const metalAt = (i: number): Pt => polar(METAL_RING, (i * 360) / WORK_ORDER.length - 90);

export function alchemistDrawing(): Drawing {
  const marks: DrawMark[] = [stroke('circle-of-metals', ring(METAL_RING), 'guide')];
  // The furnace, the cucurbit on it, the still-head, its beak and the receiver, drawn a little
  // small so the ring of metals stands clear of them.
  const k = 0.82;
  const S = (pts: Pt[]): Pt[] => pts.map(([x, y]) => [x * k, y * k]);
  const part = (id: string, pts: Pt[]) => marks.push(stroke(id, S(pts)));
  part(
    'furnace',
    corners(
      [
        [-0.48, 0.22],
        [-0.44, 0.62],
        [0.04, 0.62],
        [0.08, 0.22],
      ],
      8,
    ),
  );
  part(
    'fire-door',
    beziers(
      [
        [-0.3, 0.62],
        [-0.3, 0.47],
        [-0.1, 0.47],
        [-0.1, 0.62],
      ],
      10,
    ),
  );
  for (let f = 0; f < 3; f++) {
    const x = -0.25 + f * 0.05;
    part(
      `flame-${f}`,
      beziers(
        [
          [x, 0.61],
          [x - 0.025, 0.57],
          [x + 0.025, 0.55],
          [x, 0.51],
        ],
        8,
      ),
    );
  }
  const body: Pt = [-0.2, 0.12];
  const belly = ring(0.2, body, 96);
  // The cucurbit's round belly, open for fifteen degrees either side of its neck.
  part('cucurbit', belly.slice(4, belly.length - 4));
  const shoulder = (deg: number): Pt => {
    const [x, y] = polar(0.2, deg);
    return [body[0] + x, body[1] + y];
  };
  const top = -0.3;
  part('neck-left', line(shoulder(-105), [body[0] - 0.045, top], 8));
  part('neck-right', line(shoulder(-75), [body[0] + 0.045, top], 8));
  // The still-head, a helmet over the neck with a gutter round its rim.
  part(
    'head-rim',
    beziers(
      [
        [body[0] + 0.045, top],
        [-0.11, top - 0.01],
        [-0.07, top - 0.02],
        [-0.04, top - 0.04],
      ],
      8,
    ),
  );
  const spout: Pt = [-0.02, -0.4];
  part(
    'still-head',
    beziers(
      [
        [body[0] - 0.045, top],
        [-0.31, top],
        [-0.36, top],
        [-0.36, -0.4],
        [-0.36, -0.58],
        [-0.06, -0.6],
        spout,
      ],
      16,
    ),
  );
  part('beak', beziers([spout, [0.12, -0.3], [0.26, -0.12], [0.33, 0.08]], 16));
  const receiver: Pt = [0.42, 0.26];
  const rad = (deg: number) => (deg * Math.PI) / 180;
  // The receiver, open at its neck where the beak goes in.
  part('receiver', arc(receiver[0], receiver[1], 0.14, rad(-105), rad(225), 88));
  const lip = (deg: number): Pt => {
    const [x, y] = polar(0.14, deg);
    return [receiver[0] + x, receiver[1] + y];
  };
  const neck = polar(0.08, -120);
  for (const [side, deg] of [
    ['left', -135],
    ['right', -105],
  ] as const) {
    const from = lip(deg);
    part(`receiver-neck-${side}`, line(from, [from[0] + neck[0], from[1] + neck[1]], 6));
  }
  marks.push(dot('drop', S([[receiver[0], receiver[1] + 0.06]])[0]!, 0.022));
  // The metals, from lead to gold.
  WORK_ORDER.forEach((metal, i) => {
    const c = metalAt(i);
    const s = 0.017;
    metalStrokes(metal).forEach((pts, j) =>
      marks.push(
        stroke(
          `metal-${metal}-${j}`,
          pts.map(([x, y]): Pt => [c[0] + x * s, c[1] + y * s]),
        ),
      ),
    );
  });
  return { marks, focus: metalAt(WORK_ORDER.length - 1) };
}
