import type { ArchetypeId } from '~/data/palettes';
import type { Drawing } from './kit';
import {
  bardDrawing,
  enchantressDrawing,
  necromancerDrawing,
  warlockDrawing,
  witchDrawing,
} from './mantle';
import { clericDrawing, druidDrawing, paladinDrawing, shamanDrawing } from './sky';
import { alchemistDrawing, sorcererDrawing } from './threshold';

export type { Drawing, DrawMark, Dot, Stroke } from './kit';

/** Each archetype's own method of drawing its sigil; the Wizard's is a construction instead. */
export const DRAWINGS: Partial<Record<ArchetypeId, () => Drawing>> = {
  cleric: clericDrawing,
  paladin: paladinDrawing,
  shaman: shamanDrawing,
  druid: druidDrawing,
  witch: witchDrawing,
  enchantress: enchantressDrawing,
  warlock: warlockDrawing,
  necromancer: necromancerDrawing,
  bard: bardDrawing,
  sorcerer: sorcererDrawing,
  alchemist: alchemistDrawing,
};
