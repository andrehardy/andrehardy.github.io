/**
 * Drawn sigils (R-ID-*-03). The Wizard's sigil is a compass construction (lib/construction);
 * the other eleven are each drawn by their own method (rays turned about a centre, ordinaries
 * laid on a shield, seeds set at the golden angle, nodal lines of a struck plate), but all are
 * set down the same way: an ordered list of marks on a unit field centred on the origin, y down,
 * so the plate can draw them in the order they were made and a test can check the method.
 */
import { arc, cubic, line, seeded, type Pt } from '../ink';

export type { Pt };

export interface Stroke {
  kind: 'stroke';
  id: string;
  /** A guide is a faint line the drawing was set out on; a cut is engraved. */
  role: 'guide' | 'cut';
  pts: Pt[];
}

export interface Dot {
  kind: 'dot';
  id: string;
  at: Pt;
  r: number;
}

export type DrawMark = Stroke | Dot;

export interface Drawing {
  marks: DrawMark[];
  /** Where the eye comes to rest: the drawing's last point, or its centre. */
  focus: Pt;
}

export const stroke = (id: string, pts: Pt[], role: Stroke['role'] = 'cut'): Stroke => ({
  kind: 'stroke',
  id,
  role,
  pts,
});

export const dot = (id: string, at: Pt, r: number): Dot => ({ kind: 'dot', id, at, r });

export const polar = (r: number, deg: number): Pt => {
  const a = (deg * Math.PI) / 180;
  return [r * Math.cos(a), r * Math.sin(a)];
};

/** A full circle, sampled from the top, clockwise. */
export const ring = (r: number, c: Pt = [0, 0], n = 96): Pt[] =>
  arc(c[0], c[1], r, -Math.PI / 2, (3 * Math.PI) / 2, n);

export const rotate = ([x, y]: Pt, deg: number): Pt => {
  const a = (deg * Math.PI) / 180;
  const c = Math.cos(a);
  const s = Math.sin(a);
  return [x * c - y * s, x * s + y * c];
};

export const mirror = ([x, y]: Pt): Pt => [-x, y];

/** A path through corners, each straight run sampled so the pen can vary along it. */
export function corners(pts: Pt[], n = 10): Pt[] {
  const out: Pt[] = [pts[0]!];
  for (let i = 1; i < pts.length; i++) out.push(...line(pts[i - 1]!, pts[i]!, n).slice(1));
  return out;
}

/** A chain of cubic Beziers given as [p0, c1, c2, p1, c1, c2, p2, ...]. */
export function beziers(ctrl: Pt[], n = 24): Pt[] {
  const out: Pt[] = [ctrl[0]!];
  for (let i = 0; i + 3 < ctrl.length; i += 3)
    out.push(...cubic(ctrl[i]!, ctrl[i + 1]!, ctrl[i + 2]!, ctrl[i + 3]!, n).slice(1));
  return out;
}

export { arc, cubic, line, seeded };
