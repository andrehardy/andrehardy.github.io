/**
 * Folio numbers in book order. The Preface is front matter, folioed in roman; the body runs
 * from the Axis through the twelve folios (highest on the axis first), the Codex, the Trials,
 * the Ledger and the Bestiary.
 */
import { getCollection } from 'astro:content';
import { roman } from './almanac';

let order: Promise<string[]> | undefined;

/** Every body page's path (relative to the base), in folio order. */
export function bodyOrder(): Promise<string[]> {
  order ??= (async () => {
    const archetypes = (await getCollection('archetypes')).sort(
      (a, b) => b.data.axis - a.data.axis || a.data.name.localeCompare(b.data.name),
    );
    const trials = (await getCollection('trials')).sort((a, b) => a.id.localeCompare(b.id));
    return [
      '',
      ...archetypes.map((a) => `archetypes/${a.id}/`),
      'codex/',
      'trials/',
      ...trials.map((t) => `trials/${t.id}/`),
      'ledger/',
      'bestiary/',
    ];
  })();
  return order;
}

/** The folio a page carries: roman for the front matter, figures for the body. */
export async function folioOf(path: string): Promise<string | undefined> {
  if (path === 'preface/') return roman(1);
  const i = (await bodyOrder()).indexOf(path);
  return i < 0 ? undefined : String(i + 1);
}
