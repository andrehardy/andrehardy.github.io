/**
 * Reading what a work calls its practitioner. A canon label "names" an archetype when it uses
 * the archetype's name, an alias, or a gendered form, in any plural or possessive. The Ledger
 * and the folios use this to tell a reclassification from a portrayal true to its label.
 */
import type { ArchetypeId } from '~/data/palettes';

/** Gendered forms a work may use for an archetype, beyond its name and aliases. */
export const FORMS: Partial<Record<ArchetypeId, string[]>> = {
  sorcerer: ['sorceress'],
  enchantress: ['enchanter'],
  cleric: ['priestess'],
};

export interface Label {
  id: ArchetypeId;
  word: string;
}

interface Named {
  id: string;
  data: { name: string; aliases: string[] };
}

/** Every word that names an archetype. */
export function labelsOf(archetypes: Named[]): Label[] {
  return archetypes.flatMap((a) =>
    [a.data.name, ...a.data.aliases, ...(FORMS[a.id as ArchetypeId] ?? [])].map((n) => ({
      id: a.id as ArchetypeId,
      word: n.toLowerCase(),
    })),
  );
}

/** The archetypes a canon label names, in any plural or possessive form. */
export function namedBy(label: string, labels: Label[]): Label[] {
  const text = label.toLowerCase();
  return labels.filter((l) => new RegExp(`\\b${l.word}(e?s)?(['\u2019]s?)?\\b`).test(text));
}

interface Filed {
  id: string;
  data: { canonLabel: string; verdict: string; year: number };
}

/**
 * Portrayals whose own work calls them by this archetype's name, but which the Registry files
 * under another: the folio lists them so a reader looking for a famous name finds where it went.
 */
export function filedElsewhere<T extends Filed>(
  portrayals: T[],
  id: ArchetypeId,
  labels: Label[],
): T[] {
  return portrayals
    .filter(
      (p) => p.data.verdict !== id && namedBy(p.data.canonLabel, labels).some((l) => l.id === id),
    )
    .sort((x, y) => x.data.year - y.data.year || x.id.localeCompare(y.id));
}
