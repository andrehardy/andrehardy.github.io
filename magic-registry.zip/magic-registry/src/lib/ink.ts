/**
 * Ink with body. Turns a centerline into a filled outline whose width varies like a pen
 * under changing pressure: it tapers in, swells slightly, and pools where the nib lifts.
 * Strokes are then revealed by animating a mask along the centerline, so they still
 * "draw themselves on" even though the visible shape is a filled form.
 */

export type Pt = [number, number];

/** Deterministic pseudo-random numbers, so every build engraves the same plate. */
export function seeded(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const r2 = (n: number) => Math.round(n * 100) / 100;

export function polylineD(points: Pt[], closed = false): string {
  if (!points.length) return '';
  const [first, ...rest] = points;
  return (
    `M${r2(first[0])} ${r2(first[1])}` +
    rest.map(([x, y]) => `L${r2(x)} ${r2(y)}`).join('') +
    (closed ? 'Z' : '')
  );
}

/** Samples an arc of a circle (angles in radians). */
export function arc(cx: number, cy: number, r: number, a0: number, a1: number, n = 48): Pt[] {
  const pts: Pt[] = [];
  for (let i = 0; i <= n; i++) {
    const a = a0 + ((a1 - a0) * i) / n;
    pts.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]);
  }
  return pts;
}

/** Samples a cubic Bezier curve. */
export function cubic(p0: Pt, p1: Pt, p2: Pt, p3: Pt, n = 32): Pt[] {
  const pts: Pt[] = [];
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const u = 1 - t;
    const x = u * u * u * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t * t * t * p3[0];
    const y = u * u * u * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t * t * t * p3[1];
    pts.push([x, y]);
  }
  return pts;
}

/** Straight segment, sampled so pressure can vary along it. */
export function line(a: Pt, b: Pt, n = 12): Pt[] {
  const pts: Pt[] = [];
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    pts.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]);
  }
  return pts;
}

export interface PenOptions {
  /** Nominal full width of the stroke. */
  width: number;
  /** Fraction of the length spent tapering in (0..0.5). */
  taperIn?: number;
  /** Fraction of the length spent tapering out (0..0.5). */
  taperOut?: number;
  /** How much the ink pools where the nib lifts (0 = none, 0.35 = a visible bead). */
  pool?: number;
  /** Amplitude of hand tremor in pressure (0..0.3). */
  tremor?: number;
  seed?: number;
}

/** Pressure along the stroke at parameter t in 0..1. Exposed for tests. */
export function pressure(
  t: number,
  o: Required<Omit<PenOptions, 'width' | 'seed'>>,
  wobble: number,
): number {
  const tin = o.taperIn > 0 ? Math.min(1, t / o.taperIn) : 1;
  const tout = o.taperOut > 0 ? Math.min(1, (1 - t) / o.taperOut) : 1;
  const ease = (x: number) => Math.sin((Math.PI / 2) * x);
  const body = 0.82 + 0.18 * Math.sin(Math.PI * t);
  const bead = o.pool * Math.exp(-(((1 - t) / 0.035) ** 2));
  return Math.max(
    0.06,
    ease(tin) * Math.max(ease(tout), bead > 0.02 ? 0.55 : 0) * body * (1 + wobble) + bead,
  );
}

/** Returns the SVG path data of the filled, pressure-varied outline of a centerline. */
export function penOutline(points: Pt[], opts: PenOptions): string {
  if (points.length < 2) return '';
  const o = {
    taperIn: opts.taperIn ?? 0.12,
    taperOut: opts.taperOut ?? 0.16,
    pool: opts.pool ?? 0.22,
    tremor: opts.tremor ?? 0.08,
  };
  const rand = seeded(opts.seed ?? 1);

  const lengths = [0];
  for (let i = 1; i < points.length; i++) {
    lengths.push(
      lengths[i - 1] + Math.hypot(points[i][0] - points[i - 1][0], points[i][1] - points[i - 1][1]),
    );
  }
  const total = lengths[lengths.length - 1] || 1;

  const left: Pt[] = [];
  const right: Pt[] = [];
  const dirs: Pt[] = [];
  const widths: number[] = [];
  let wobble = 0;
  for (let i = 0; i < points.length; i++) {
    const prev = points[Math.max(0, i - 1)];
    const next = points[Math.min(points.length - 1, i + 1)];
    let dx = next[0] - prev[0];
    let dy = next[1] - prev[1];
    const len = Math.hypot(dx, dy) || 1;
    dx /= len;
    dy /= len;
    wobble = wobble * 0.7 + (rand() - 0.5) * o.tremor;
    const w = (opts.width / 2) * pressure(lengths[i] / total, o, wobble);
    left.push([points[i][0] - dy * w, points[i][1] + dx * w]);
    right.push([points[i][0] + dy * w, points[i][1] - dx * w]);
    dirs.push([dx, dy]);
    widths.push(w);
  }
  const last = points.length - 1;
  // Where the nib lifts, the ink gathers into a rounded bead rather than a cut ribbon end.
  const endCap = penCap(points[last], dirs[last], widths[last], 1);
  const startCap = penCap(points[0], dirs[0], widths[0], -1);
  return polylineD([...left, ...endCap, ...right.reverse(), ...startCap], true);
}

/** A half-round cap from the left edge, around the stroke's end, to the right edge. */
function penCap(p: Pt, [dx, dy]: Pt, w: number, facing: 1 | -1, n = 10): Pt[] {
  const pts: Pt[] = [];
  // At the end the cap sweeps left edge to right edge through the forward direction;
  // at the start, right edge to left edge through the backward direction.
  const nx = facing === 1 ? -dy : dy;
  const ny = facing === 1 ? dx : -dx;
  for (let i = 1; i < n; i++) {
    const t = (Math.PI * i) / n;
    pts.push([
      p[0] + w * (Math.cos(t) * nx + Math.sin(t) * dx * facing),
      p[1] + w * (Math.cos(t) * ny + Math.sin(t) * dy * facing),
    ]);
  }
  return pts;
}

/**
 * A deckled edge for a sheet of handmade paper, as a CSS polygon.
 * The edge is where the pulp thinned against the mould's frame: a slow wander (the
 * deckle's swell) carrying fine, fibrous tearing. `rough` is the depth of the slow
 * wander in percent of the sheet; fibres add up to a third as much again.
 */
export function deckle(seed: number, rough = 1.6, steps = 90): string {
  const rand = seeded(seed);
  const phase = rand() * Math.PI * 2;
  const depth = (t: number) => {
    const swell = 0.5 + 0.5 * Math.sin(t * Math.PI * 2 * 3 + phase);
    const fibre = rand();
    return r2(rough * (0.35 + 0.45 * swell) + (rough / 3) * fibre * fibre);
  };
  const pts: string[] = [];
  const pct = (i: number) => r2((i / steps) * 100);
  for (let i = 0; i <= steps; i++) pts.push(`${pct(i)}% ${depth(i / steps)}%`);
  for (let i = 1; i <= steps; i++) pts.push(`${r2(100 - depth(i / steps))}% ${pct(i)}%`);
  for (let i = steps - 1; i >= 0; i--) pts.push(`${pct(i)}% ${r2(100 - depth(i / steps))}%`);
  for (let i = steps - 1; i >= 1; i--) pts.push(`${depth(i / steps)}% ${pct(i)}%`);
  return `polygon(${pts.join(',')})`;
}
