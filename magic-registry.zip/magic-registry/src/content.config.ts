import { defineCollection } from 'astro:content';
import { glob } from 'astro/loaders';
import {
  accessSchema,
  archetypeSchema,
  beingSchema,
  creatureSchema,
  glossarySchema,
  portrayalSchema,
  realmSchema,
  trialSchema,
} from './data/schemas';

const yaml = (folder: string) => glob({ pattern: '*.yaml', base: `./src/content/${folder}` });

export const collections = {
  realms: defineCollection({ loader: yaml('realms'), schema: realmSchema }),
  beings: defineCollection({ loader: yaml('beings'), schema: beingSchema }),
  access: defineCollection({ loader: yaml('access'), schema: accessSchema }),
  glossary: defineCollection({ loader: yaml('glossary'), schema: glossarySchema }),
  archetypes: defineCollection({
    loader: glob({ pattern: '*.md', base: './src/content/archetypes' }),
    schema: archetypeSchema,
  }),
  portrayals: defineCollection({ loader: yaml('portrayals'), schema: portrayalSchema }),
  trials: defineCollection({ loader: yaml('trials'), schema: trialSchema }),
  /** Reserved for the bestiary: a schema with no entries yet (D-18). */
  creatures: defineCollection({ loader: () => [], schema: creatureSchema }),
};
