/**
 * The registry's data model. Shared by the content collections (src/content.config.ts) and the
 * unit tests, which parse the content files directly against these schemas.
 *
 * Every reader-facing field carries both voices: the almanac (the default, engraved register)
 * and the cipher (the plain mechanical reading). Internal fields (`stage`, `status`) are never
 * rendered.
 */
import { z } from 'astro/zod';
import { ARCHETYPE_IDS, REALM_IDS } from './palettes';

export { ARCHETYPE_IDS, REALM_IDS };

export const BEING_IDS = ['baseline-human', 'tier3-gamma', 'tier3-alpha'] as const;

/** One access method per archetype (D-03). */
export const ACCESS_IDS = [
  'study',
  'decoction',
  'ingestion',
  'bloodline',
  'glamour',
  'covenant',
  'cultivation',
  'reanimation',
  'broadcast',
  'warding',
  'artifice',
  'resonance',
] as const;

export const GLOSSARY_IDS = [
  'vault',
  'mantle',
  'sealed-light',
  'threshold',
  'being',
  'source',
  'covenant',
  'keys-of-ingestion',
  'grid',
] as const;

export const MEDIA = ['myth', 'book', 'film', 'tv', 'game', 'anime', 'comic'] as const;
export const VERDICT_KINDS = ['true-to-label', 'misfiled', 'anomaly'] as const;
export const RANKS = ['exemplar', 'runner-up', 'notable'] as const;
export const PORTRAYAL_STATUS = ['confirmed', 'proposed'] as const;
export const RESULT_KINDS = ['moved', 'shattered', 'untouched', 'conditional', 'denied'] as const;
export const STAGES = ['seeded', 'written'] as const;

const kebab = z.string().regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, 'a kebab-case id');
const text = z.string().trim().min(1);

/** Abbreviations whose full stop does not end a sentence. */
const ABBREVIATIONS = /\b(Dr|Mr|Mrs|Ms|St|Mt|Vol|vs|cf|e\.g|i\.e|No(?=\.\s*\d))\./g;

/**
 * One sentence: it ends in a full stop, question or exclamation mark, and no sentence break
 * (terminal punctuation followed by a capital or a figure) occurs inside it.
 */
export const sentence = text.refine((s) => {
  const t = s.replace(ABBREVIATIONS, '$1');
  return (
    /[.!?]["'\u2019\u201d]?$/.test(t) &&
    !/[.!?]["'\u2019\u201d]?\s+["'\u2018\u201c(]?[A-Z0-9]/.test(t)
  );
}, 'a single sentence');

/** A passage in both voices. */
export const layered = z.object({ almanac: text, cipher: text }).strict();
/** A one-sentence thesis in both voices. */
export const thesis = z.object({ almanac: sentence, cipher: sentence }).strict();

export const realmSchema = z
  .object({
    almanacName: text,
    cipherName: text,
    /** Plain-language palette names; tests hold them equal to the design tokens. */
    palette: z.array(text).min(2),
    motif: text,
    description: layered,
  })
  .strict();

export const beingSchema = z
  .object({
    almanacName: text,
    cipherName: text,
    description: layered,
  })
  .strict();

export const accessSchema = z
  .object({
    almanacName: text,
    cipherName: text,
    description: layered,
  })
  .strict();

export const glossarySchema = z
  .object({
    term: text,
    cipherTerm: text,
    definition: layered,
  })
  .strict();

export const identitySchema = z
  .object({
    /** What the folio is made of. */
    material: text,
    /** Plain-language palette names; tests hold them equal to the design tokens. */
    palette: z.array(text).min(3),
    /** How the sigil and plates are constructed. */
    geometry: kebab,
    /** The motion signature. */
    motion: kebab,
    /** The folio layout template. */
    layout: kebab,
    /** The signature interaction. */
    interaction: kebab,
    /** The type accent, in words. */
    typeAccent: text,
    entrance: kebab,
    cursor: kebab,
    initial: kebab,
    sound: kebab,
  })
  .strict();

const counterpart = z
  .object({
    archetype: z.enum(ARCHETYPE_IDS),
    note: layered,
  })
  .strict();

const instrument = z
  .object({
    object: text,
    almanac: text,
    cipher: text,
  })
  .strict();

/** Fields every archetype has from the day it is seeded. */
const archetypeStructure = {
  name: text,
  aliases: z.array(text).default([]),
  realm: z.enum(REALM_IDS),
  /** +100 (the Sealed Light) down to -100 (the depths of the Mantle). */
  axis: z.number().int().min(-100).max(100),
  /** Why an axis value of 0 is not simply "neutral". */
  axisNote: z.enum(['oscillating', 'unbound']).optional(),
  beings: z.array(z.enum(BEING_IDS)).min(1),
  access: z.enum(ACCESS_IDS),
  /** The sigil's asset id (src/assets/sigils/<sigil>.svg from Phase 4). */
  sigil: kebab,
  identity: identitySchema,
};

/** Seeded: structure only. The prose arrives in Phase 5 (D-13). */
export const seededArchetypeSchema = z
  .object({ stage: z.literal('seeded'), ...archetypeStructure })
  .strict();

/** Written: the full entry. The Markdown body is the almanac prose. */
export const writtenArchetypeSchema = z
  .object({
    stage: z.literal('written'),
    ...archetypeStructure,
    /** A title in the almanac's manner, e.g. "Reckoner of Probable Things". */
    epithet: text,
    /** The plain, mechanical title. */
    cipherTitle: text,
    thesis,
    /** The pop-culture surface: what the costume looks like. */
    tropes: z.array(text).min(3),
    instruments: z.array(instrument).min(2),
    costs: z.array(layered).min(2),
    blindSpots: z.array(layered).min(1),
    counterparts: z.array(counterpart).min(1),
    /** The cipher reading of the whole entry; the almanac reading is the Markdown body. */
    cipher: text,
  })
  .strict();

export const archetypeSchema = z.discriminatedUnion('stage', [
  seededArchetypeSchema,
  writtenArchetypeSchema,
]);

const source = z
  .object({
    /** The work itself, as it would be cited. */
    title: text,
    /** Author, studio, network or publisher. */
    by: text,
    year: z.number().int(),
    /** Which part of the work: season, issue, chapter, scene. */
    detail: text.optional(),
  })
  .strict();

export const portrayalSchema = z
  .object({
    character: text,
    work: text,
    medium: z.enum(MEDIA),
    year: z.number().int().min(-3000).max(2100),
    creator: text,
    /** What the character's own work calls them. */
    canonLabel: text,
    verdict: z.enum(ARCHETYPE_IDS),
    verdictKind: z.enum(VERDICT_KINDS),
    rank: z.enum(RANKS),
    thesis,
    almanacReason: text,
    cipherReason: text,
    evidence: z.array(text).min(2),
    /** Proper names from the work (people, places, objects) that the entry's text may use. */
    names: z.array(text).default([]),
    sources: z.array(source).min(1),
    /** Internal: proposed verdicts are reviewed before they ship. Never rendered. */
    status: z.enum(PORTRAYAL_STATUS),
  })
  .strict();

const outcome = z
  .object({
    archetype: z.enum(ARCHETYPE_IDS),
    /** The headline, shared by both voices. */
    result: sentence,
    resultKind: z.enum(RESULT_KINDS),
    almanac: text,
    cipher: text,
  })
  .strict();

export const trialSchema = z
  .object({
    title: layered,
    thesis,
    premise: layered,
    outcomes: z.array(outcome).min(1),
  })
  .strict();

/** Reserved for the bestiary. No entries yet. */
export const creatureSchema = z
  .object({
    name: text,
    realm: z.enum(REALM_IDS),
    beings: z.array(z.enum(BEING_IDS)).min(1),
    description: layered,
  })
  .strict();

export type Archetype = z.infer<typeof archetypeSchema>;
export type WrittenArchetype = z.infer<typeof writtenArchetypeSchema>;
export type Portrayal = z.infer<typeof portrayalSchema>;
export type Trial = z.infer<typeof trialSchema>;
