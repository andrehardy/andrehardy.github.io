/**
 * Design-token source of truth for color, ink and physics.
 * Realms set the ground (atmosphere); archetypes set the voice (their own folio palette).
 * Every value here is checked by tests/unit/tokens.test.ts for contrast and distinctness.
 */
import { composite, contrast, labToHex, luminance, toLab } from '../lib/color';

export const ARCHETYPE_IDS = [
  'wizard',
  'witch',
  'shaman',
  'sorcerer',
  'enchantress',
  'warlock',
  'druid',
  'necromancer',
  'cleric',
  'paladin',
  'alchemist',
  'bard',
] as const;
export type ArchetypeId = (typeof ARCHETYPE_IDS)[number];

export const REALM_IDS = ['sealed', 'vault', 'threshold', 'mantle'] as const;
export type RealmId = (typeof REALM_IDS)[number];

export interface Palette {
  /** Page ground. */
  ground: string;
  /** A deeper or shadowed ground for plates, wells and margins. */
  well: string;
  /** Body text. */
  ink: string;
  /** Secondary text: marginalia, captions. */
  inkSoft: string;
  /** The signature color. Used for ornament, rules and large display type. */
  accent: string;
  /** A second voice in the palette, held to the same 3:1 floor as the accent. */
  accent2: string;
  /** Light source for this archetype's glow (must be a plausible source). */
  glow: string;
  /** Hairline rules and engraving. */
  rule: string;
  /** Rubrication: the red of key terms, legible as body text (4.5:1) on ground and well. */
  rubric: string;
  /** Plain-language names, in the order the plan gives them. */
  names: string[];
}

export const REALM_PALETTES: Record<RealmId, Palette> = {
  sealed: {
    ground: '#f4eedc',
    well: '#e9dfc4',
    ink: '#2a2218',
    inkSoft: '#5b4d39',
    accent: '#9a7420',
    accent2: '#96782d',
    glow: '#fff1c2',
    rule: '#b9a678',
    rubric: '#8e2a1e',
    names: ['pale vellum', 'aureate gold'],
  },
  vault: {
    ground: '#0b1026',
    well: '#070a1a',
    ink: '#e8e1cf',
    inkSoft: '#b4b6c9',
    accent: '#c9a24a',
    accent2: '#7d8fc4',
    glow: '#cfd8ef',
    rule: '#3a4470',
    rubric: '#d9604a',
    names: ['night-ink indigo', 'gold leaf', 'moonlight'],
  },
  threshold: {
    ground: '#14131a',
    well: '#0d0c10',
    ink: '#ebe3d2',
    inkSoft: '#b8ae9c',
    accent: '#c9a24a',
    accent2: '#975143',
    glow: '#e8c98a',
    rule: '#4a4140',
    rubric: '#d8603e',
    names: ['dusk duotone', 'gold above', 'ember below'],
  },
  mantle: {
    ground: '#1a1210',
    well: '#110b09',
    ink: '#e9dcc6',
    inkSoft: '#bfae95',
    accent: '#a8423a',
    accent2: '#5f9a86',
    glow: '#e8a24a',
    rule: '#4d3a2e',
    rubric: '#de7a4a',
    names: ['oxblood', 'loam', 'umber', 'verdigris', 'candlelight'],
  },
};

export const ARCHETYPE_PALETTES: Record<ArchetypeId, Palette> = {
  wizard: {
    ground: '#0f1630',
    well: '#0a0f22',
    ink: '#ece6d6',
    inkSoft: '#b7bbcf',
    accent: '#c19a4b',
    accent2: '#8ea2d6',
    glow: '#dfe6f7',
    rule: '#33406b',
    rubric: '#d85a40',
    names: ['midnight indigo', 'brass', 'chalk'],
  },
  witch: {
    ground: '#1b1315',
    well: '#120c0e',
    ink: '#e7dcc9',
    inkSoft: '#bcae9a',
    accent: '#9b6fc4',
    accent2: '#95505c',
    glow: '#d9893a',
    rule: '#4a3438',
    rubric: '#c4626c',
    names: ['oxblood', 'belladonna violet', 'soot', 'bone'],
  },
  shaman: {
    ground: '#261a12',
    well: '#1a110b',
    ink: '#efe0c4',
    inkSoft: '#c6b190',
    accent: '#c9703a',
    accent2: '#7d6a58',
    glow: '#3fe0d0',
    rule: '#56402e',
    rubric: '#ca6c5a',
    names: ['smoked hide', 'ochre', 'smoke', 'vision cyan'],
  },
  sorcerer: {
    ground: '#120c0a',
    well: '#0a0605',
    ink: '#f4e8d8',
    inkSoft: '#c9b4a0',
    accent: '#ff6a2a',
    accent2: '#c0182f',
    glow: '#fff1d6',
    rule: '#4a2a20',
    rubric: '#ff5c7a',
    names: ['white-hot core', 'ember', 'arterial red', 'char'],
  },
  enchantress: {
    ground: '#0b151b',
    well: '#060d12',
    ink: '#f2ece7',
    inkSoft: '#bfc7c6',
    accent: '#e3ab95',
    accent2: '#8fc5b8',
    glow: '#f5e6dc',
    rule: '#2c3f47',
    rubric: '#e07a80',
    names: ['pearl', 'rose-gold', 'sea-glass', 'abyssal blue-black'],
  },
  warlock: {
    ground: '#e6dac0',
    well: '#d8c9a8',
    ink: '#24242a',
    inkSoft: '#4f4c4c',
    accent: '#a3121c',
    accent2: '#7c6e19',
    glow: '#e3c65a',
    rule: '#8c826e',
    rubric: '#7f2f0e',
    names: ['contract parchment', 'iron grey', 'sulfur', 'signet crimson'],
  },
  druid: {
    ground: '#18200f',
    well: '#10160a',
    ink: '#e6ead3',
    inkSoft: '#b7bf9d',
    accent: '#8fb14a',
    accent2: '#8a6a44',
    glow: '#d9bb55',
    rule: '#3c4a2a',
    rubric: '#cc6b4a',
    names: ['moss', 'lichen', 'bark', 'spore-gold'],
  },
  necromancer: {
    ground: '#d8d2c2',
    well: '#c9c1ad',
    ink: '#1a1b19',
    inkSoft: '#45463f',
    accent: '#4f5b66',
    accent2: '#3e6b5c',
    glow: '#a9c8b8',
    rule: '#8f897a',
    rubric: '#7a1a1a',
    names: ['bone ivory', 'tarnished silver', 'cold verdigris', 'black'],
  },
  cleric: {
    ground: '#f7f2e4',
    well: '#ece3cb',
    ink: '#1c2744',
    inkSoft: '#46506b',
    accent: '#8a6512',
    accent2: '#1f4aa8',
    glow: '#fff6d2',
    rule: '#c9b98c',
    rubric: '#9a1f1f',
    names: ['white', 'aureate gold', 'lapis'],
  },
  paladin: {
    ground: '#dde2e8',
    well: '#cbd2db',
    ink: '#121d33',
    inkSoft: '#3d4a60',
    accent: '#1d4e9e',
    accent2: '#a51d27',
    glow: '#f3f6fa',
    rule: '#8d98a8',
    rubric: '#9a1820',
    names: ['argent', 'azure', 'gules', 'steel'],
  },
  alchemist: {
    ground: '#ebe2cb',
    well: '#ddd1b3',
    ink: '#29251f',
    inkSoft: '#544b3e',
    accent: '#0c8070',
    accent2: '#ac5e2a',
    glow: '#f2d76b',
    rule: '#a59777',
    rubric: '#9a2f14',
    names: ['verdigris', 'copper', 'mercury', 'sulfur'],
  },
  bard: {
    ground: '#2c0f16',
    well: '#1e0a0f',
    ink: '#f1e3c9',
    inkSoft: '#c7b18f',
    accent: '#d0607e',
    accent2: '#d2a54a',
    glow: '#f0c470',
    rule: '#5a3a26',
    rubric: '#e5704c',
    names: ['crimson velvet', 'walnut', 'gilt'],
  },
};

export const ARCHETYPE_REALM: Record<ArchetypeId, RealmId> = {
  cleric: 'sealed',
  paladin: 'vault',
  wizard: 'vault',
  shaman: 'vault',
  druid: 'vault',
  sorcerer: 'threshold',
  alchemist: 'threshold',
  bard: 'mantle',
  enchantress: 'mantle',
  witch: 'mantle',
  warlock: 'mantle',
  necromancer: 'mantle',
};

/**
 * The two physics. The Vault is celestial (long, frictionless, nothing lands hard);
 * the Mantle is geological (weighted, short travel, firm landings). The Threshold's
 * ambient chrome follows the sky above its horizon; its two practitioners carry
 * earthly weight: the Sorcerer's charge breaks and lands, the Alchemist's drops fall.
 */
export type Physics = 'vault' | 'mantle';

export const REALM_PHYSICS: Record<RealmId, Physics> = {
  sealed: 'vault',
  vault: 'vault',
  threshold: 'vault',
  mantle: 'mantle',
};

export const ARCHETYPE_PHYSICS: Record<ArchetypeId, Physics> = {
  ...(Object.fromEntries(
    Object.entries(ARCHETYPE_REALM).map(([id, realm]) => [id, REALM_PHYSICS[realm]]),
  ) as Record<ArchetypeId, Physics>),
  sorcerer: 'mantle',
  alchemist: 'mantle',
};

/** Ink by physics: the Mantle inks heavier and bleeds further into soaked paper. */
export const INK: Record<Physics, { weight: string; swell: string; bleed: string }> = {
  vault: { weight: '1px', swell: '0px', bleed: 'url(#ink-bleed)' },
  mantle: { weight: '1.5px', swell: '1.2px', bleed: 'url(#ink-bleed-heavy)' },
};

/**
 * Gold leaf. The base is an even, burnished field with no fixed bright band, so the moving
 * sheen (driven by --gx and --gy) is the only specular. On dark grounds the leaf is bright.
 * On light paper it is a true gold (not a brown), as bright as legibility allows: the generic
 * vellum leaf below, and for each light scope the brightest gold that still keeps 3:1, with the
 * sheen composited, on that scope's own ground and well (see giltFor).
 */
export interface Gilt {
  stops: string[];
  /** Sheen color and its peak opacity. */
  sheen: string;
  sheenAlpha: number;
}

export const GILT: Record<'light' | 'dark', Gilt> = {
  light: {
    stops: ['#8d6215', '#946d0a', '#906517', '#976f0e', '#8c6113', '#916a06'],
    sheen: '#f3d27a',
    sheenAlpha: 0.16,
  },
  dark: {
    stops: ['#bd9340', '#cba24e', '#c29944', '#d0a954', '#bb913e', '#c89f4b'],
    sheen: '#fff3d0',
    sheenAlpha: 0.5,
  },
};

/** The lowest contrast any point of a gilt field reaches on the given backgrounds. */
export function giltFloor(g: Gilt, backgrounds: string[]): number {
  let min = Infinity;
  for (const stop of g.stops)
    for (const c of [stop, composite(stop, g.sheen, g.sheenAlpha)])
      for (const bg of backgrounds) min = Math.min(min, contrast(c, bg));
  return min;
}

/**
 * The gold for one scope. Dark grounds take the bright leaf. Light grounds take the vellum
 * leaf, deepened in lightness only (hue and chroma kept) until it holds 3:1 on that ground
 * and its well; a darker bone or slate ground therefore gets an older, more tarnished gold.
 */
export function giltFor(p: Palette): Gilt {
  if (!isLight(p.ground)) return GILT.dark;
  const bgs = [p.ground, p.well];
  let g = GILT.light;
  for (let dL = 0; giltFloor(g, bgs) < 3.02 && dL < 30; dL += 0.5) {
    g = {
      ...GILT.light,
      stops: GILT.light.stops.map((s) => {
        const [L, a, b] = toLab(s);
        return labToHex(L - dL, a, b);
      }),
    };
  }
  return g;
}

export function giltBase(g: Gilt): string {
  const n = g.stops.length - 1;
  return `linear-gradient(118deg,${g.stops.map((s, i) => `${s} ${Math.round((i / n) * 100)}%`).join(',')})`;
}

export function giltSheen(g: Gilt): string {
  const n = parseInt(g.sheen.slice(1), 16);
  return `rgb(${(n >> 16) & 255} ${(n >> 8) & 255} ${n & 255} / ${g.sheenAlpha})`;
}

/** A ground is light when dark ink reads better on it than light ink. */
export function isLight(ground: string): boolean {
  return luminance(ground) > 0.18;
}

/** CSS custom properties for a palette, as a declaration list. */
export function paletteVars(p: Palette): string[] {
  return [
    `--ground:${p.ground}`,
    `--well:${p.well}`,
    `--ink:${p.ink}`,
    `--ink-soft:${p.inkSoft}`,
    `--accent:${p.accent}`,
    `--accent-2:${p.accent2}`,
    `--glow:${p.glow}`,
    `--rule:${p.rule}`,
    `--rubric:${p.rubric}`,
  ];
}

/** The realm's own palette, readable inside an archetype's folio as --realm-*. */
export function realmVars(p: Palette): string[] {
  return paletteVars(p).map((d) => d.replace(/^--/, '--realm-'));
}

/**
 * Everything a scope needs: colors, its realm, physics, ink, gilt and color scheme.
 * A light scope also publishes its tuned leaf as --scope-gilt-light-*, which a vellum sheet
 * (.paper) inside it prefers, because that sheet stands on the scope's ground. A dark scope
 * resets those to the generic leaf so a light scope further out cannot leak in.
 */
export function scopeVars(p: Palette, realm: Palette, physics: Physics): string {
  const light = isLight(p.ground);
  const ink = INK[physics];
  const gilt = giltFor(p);
  return [
    ...paletteVars(p),
    ...realmVars(realm),
    `color-scheme:${light ? 'light' : 'dark'}`,
    `--gilt-base:${giltBase(gilt)}`,
    `--gilt-sheen:${giltSheen(gilt)}`,
    `--scope-gilt-light-base:${light ? giltBase(gilt) : 'var(--gilt-light-base)'}`,
    `--scope-gilt-light-sheen:${light ? giltSheen(gilt) : 'var(--gilt-light-sheen)'}`,
    `--physics-ease:var(--${physics}-ease)`,
    `--physics-duration:var(--${physics}-duration)`,
    `--physics-duration-short:var(--${physics}-duration-short)`,
    `--ink-weight:${ink.weight}`,
    `--ink-swell:${ink.swell}`,
    `--ink-bleed:${ink.bleed}`,
  ].join(';');
}
