/**
 * The Enchantress's glamour and hand (R-ID-ENC-06, R-FLO-ENC-CUR). The plate lies under a veil
 * that parts only where the hand is. The line beneath the title changes whenever the reader
 * looks away, so it is never the same when they look back. The cursor is a pearl, and across
 * the hinge of the diptych its reflection follows, always a beat behind.
 */
import { cursorLayer, frames, isMouse, listen, onFolio } from '../effect';

onFolio(
  'enchantress',
  () => {
    const line = document.querySelector<HTMLElement>('[data-glamour]');
    if (!line) return;
    const faces = line.querySelectorAll('[data-face]').length;
    let glances = 0;
    const away = () => {
      line.dataset.glamour = String((Number(line.dataset.glamour) + 1) % faces);
      line.dataset.glances = String(++glances);
    };
    const offBlur = listen(window, 'blur', away);
    const offHide = listen(document, 'visibilitychange', () => {
      if (document.visibilityState === 'hidden') away();
    });
    const offLeave = listen(document.documentElement, 'mouseleave', away);
    return () => {
      offBlur();
      offHide();
      offLeave();
    };
  },
  { motion: false },
);

onFolio(
  'enchantress',
  () => {
    const host = document.querySelector<HTMLElement>('[data-veiled]');
    if (!host) return;
    host.toggleAttribute('data-live', true);
    let parted = 0;
    const offMove = listen(host, 'pointermove', (e) => {
      const r = host.getBoundingClientRect();
      host.style.setProperty('--mx', `${(((e.clientX - r.left) / r.width) * 100).toFixed(1)}%`);
      host.style.setProperty('--my', `${(((e.clientY - r.top) / r.height) * 100).toFixed(1)}%`);
      if (!host.hasAttribute('data-parted')) host.dataset.unveiled = String(++parted);
      host.toggleAttribute('data-parted', true);
    });
    const offLeave = listen(host, 'pointerleave', () => host.removeAttribute('data-parted'));
    return () => {
      offMove();
      offLeave();
      host.removeAttribute('data-live');
      host.removeAttribute('data-parted');
    };
  },
  { fine: true },
);

/** How much of the way the reflection closes on its pearl each frame: it always lags. */
const LAG = 0.09;

onFolio(
  'enchantress',
  () => {
    const { layer, remove } = cursorLayer('mirrored-pearl', false);
    const pearl = document.createElement('span');
    pearl.className = 'reflected-pearl';
    layer.append(pearl);
    let goal: [number, number] | null = null;
    let at: [number, number] | null = null;
    const offMove = listen(document, 'pointermove', (e) => {
      if (!isMouse(e)) return;
      goal = [window.innerWidth - e.clientX, e.clientY];
      at ??= [...goal];
    });
    const stop = frames(() => {
      if (!goal || !at) return;
      at = [at[0] + (goal[0] - at[0]) * LAG, at[1] + (goal[1] - at[1]) * LAG];
      pearl.style.translate = `${at[0].toFixed(1)}px ${at[1].toFixed(1)}px`;
      layer.dataset.reflecting = '';
    });
    return () => {
      offMove();
      stop();
      remove();
    };
  },
  { fine: true },
);
