/**
 * The Necromancer's strings and hand (R-ID-NEC-06, R-FLO-NEC-CUR). A string on the plate taken
 * by the hand bows toward it, and the bone it is tied to jerks round; let go, and it drops back.
 * The cursor is a puppeteer's crossbar, and from it two strings hang down to a hand that follows
 * a little late and a little stiffly, as a puppet's does.
 */
import { cursorLayer, frames, isMouse, listen, onFolio, svgEl } from '../effect';

/** How near, in plate units, the hand must come to a string to take it. */
const GRIP = 26;

const pair = (s: string) => s.split(' ').map(Number) as [number, number];

function toSegment(p: [number, number], a: [number, number], b: [number, number]): number {
  const [dx, dy] = [b[0] - a[0], b[1] - a[1]];
  const t = Math.max(
    0,
    Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / (dx * dx + dy * dy)),
  );
  return Math.hypot(p[0] - a[0] - dx * t, p[1] - a[1] - dy * t);
}

onFolio('necromancer', () => {
  const host = document.querySelector<HTMLElement>('[data-marionette]');
  const svg = host?.querySelector<SVGSVGElement>('svg.ossuary');
  if (!host || !svg) return;
  const strings = [...svg.querySelectorAll<SVGPathElement>('path.string')].map((el) => ({
    el,
    k: Number(el.dataset.string),
    bar: pair(el.dataset.bar!),
    tip: pair(el.dataset.tip!),
  }));
  const bones = (k: number) => svg.querySelectorAll(`[data-figure^="bone-${k}-"]`);
  host.toggleAttribute('data-live', true);
  let held: (typeof strings)[number] | null = null;
  let pulls = 0;
  const release = () => {
    if (!held) return;
    held.el.setAttribute('d', `M${held.bar.join(' ')}L${held.tip.join(' ')}`);
    held.el.classList.remove('taut');
    bones(held.k).forEach((b) => b.classList.remove('pulled'));
    held = null;
  };
  const offMove = listen(svg, 'pointermove', (e) => {
    const m = svg.getScreenCTM();
    if (!m) return;
    const q = new DOMPoint(e.clientX, e.clientY).matrixTransform(m.inverse());
    const p: [number, number] = [q.x, q.y];
    const near = strings
      .map((s) => ({ s, d: toSegment(p, s.bar, s.tip) }))
      .sort((x, y) => x.d - y.d)[0];
    if (!near || near.d > GRIP) return release();
    const s = near.s;
    if (held !== s) {
      release();
      held = s;
      s.el.classList.add('taut');
      bones(s.k).forEach((b) => b.classList.add('pulled'));
      host.dataset.pulls = String(++pulls);
    }
    s.el.setAttribute(
      'd',
      `M${s.bar.join(' ')}Q${p[0].toFixed(1)} ${p[1].toFixed(1)} ${s.tip.join(' ')}`,
    );
  });
  const offLeave = listen(svg, 'pointerleave', release);
  return () => {
    offMove();
    offLeave();
    release();
    host.removeAttribute('data-live');
  };
});

/** The puppet's hand closes on the crossbar by this much of the gap each frame: late, and stiff. */
const FOLLOW = 0.12;

onFolio(
  'necromancer',
  () => {
    const { layer, remove } = cursorLayer('puppet-crossbar');
    const left = svgEl('line', { class: 'puppet-string' });
    const right = svgEl('line', { class: 'puppet-string' });
    const hand = svgEl('circle', { class: 'puppet-hand', r: 3 });
    layer.append(left, right, hand);
    let bar: [number, number] | null = null;
    let at: [number, number] | null = null;
    let frame = 0;
    const off = listen(document, 'pointermove', (e) => {
      if (!isMouse(e)) return;
      bar = [e.clientX, e.clientY];
      at ??= [bar[0], bar[1] + 38];
    });
    const stop = frames(() => {
      if (!bar || !at) return;
      // It moves only on every third frame, so it jerks from pose to pose rather than gliding.
      if (++frame % 3) return;
      at = [at[0] + (bar[0] - at[0]) * FOLLOW * 3, at[1] + (bar[1] + 38 - at[1]) * FOLLOW * 3];
      for (const [line, dx] of [
        [left, -9],
        [right, 9],
      ] as const) {
        line.setAttribute('x1', String(bar[0] + dx));
        line.setAttribute('y1', String(bar[1]));
        line.setAttribute('x2', at[0].toFixed(1));
        line.setAttribute('y2', at[1].toFixed(1));
      }
      hand.setAttribute('cx', at[0].toFixed(1));
      hand.setAttribute('cy', at[1].toFixed(1));
      layer.dataset.hanging = '';
    });
    return () => {
      off();
      stop();
      remove();
    };
  },
  { fine: true },
);
