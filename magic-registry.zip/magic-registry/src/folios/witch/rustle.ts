/**
 * The Witch's board and hand (R-ID-WIT-06, R-FLO-WIT-CUR). A hand passing over a pinned
 * specimen makes it rustle on its pin. The raven in the corner keeps its eye on the hand
 * wherever it goes. The cursor is a seed; as it moves it sheds ash, and now and then a seed
 * falls with the ash.
 */
import { cursorLayer, isMouse, listen, onFolio, svgEl } from '../effect';

onFolio('witch', () => {
  const board = document.querySelector<HTMLElement>('[data-board]');
  if (!board) return;
  let rustles = 0;
  const offs = [...board.querySelectorAll<HTMLElement>('.specimen')].map((s) =>
    listen(s, 'pointerenter', () => {
      if (s.classList.contains('rustling')) return;
      s.classList.add('rustling');
      board.dataset.rustles = String(++rustles);
    }),
  );
  const offEnd = listen(board, 'animationend', (e) => {
    const t = e.target as HTMLElement;
    if (t.classList.contains('rustling') && e.animationName === 'witch-rustle')
      t.classList.remove('rustling');
  });
  return () => {
    offs.forEach((off) => off());
    offEnd();
    board.querySelectorAll('.rustling').forEach((s) => s.classList.remove('rustling'));
  };
});

/** How far the pupil may travel inside the eye, in the raven's own units. */
const LOOK = 2.6;

onFolio(
  'witch',
  () => {
    const raven = document.querySelector<SVGSVGElement>('[data-raven]');
    const pupil = raven?.querySelector<SVGCircleElement>('.raven-pupil');
    if (!raven || !pupil) return;
    raven.toggleAttribute('data-watching', true);
    const off = listen(document, 'pointermove', (e) => {
      if (!isMouse(e)) return;
      const eye = raven.querySelector('.raven-eye')!.getBoundingClientRect();
      const dx = e.clientX - (eye.left + eye.width / 2);
      const dy = e.clientY - (eye.top + eye.height / 2);
      const d = Math.hypot(dx, dy) || 1;
      const k = Math.min(1, d / 200) * LOOK;
      pupil.setAttribute(
        'transform',
        `translate(${((dx / d) * k).toFixed(2)} ${((dy / d) * k).toFixed(2)})`,
      );
    });
    return () => {
      off();
      pupil.removeAttribute('transform');
      raven.removeAttribute('data-watching');
    };
  },
  { fine: true },
);

const SEED = 'M0-4C2.6-1 2.6 2.4 0 4C-2.6 2.4-2.6-1 0-4Z';

onFolio(
  'witch',
  () => {
    const { layer, remove } = cursorLayer('ash-and-seed');
    let last: [number, number] | null = null;
    let shed = 0;
    const off = listen(document, 'pointermove', (e) => {
      if (!isMouse(e)) return;
      const p: [number, number] = [e.clientX, e.clientY];
      if (last && Math.hypot(p[0] - last[0], p[1] - last[1]) < 14) return;
      last = p;
      shed++;
      const seed = shed % 7 === 0;
      const fleck = seed
        ? svgEl('path', { class: 'seed', d: SEED })
        : svgEl('circle', { class: 'ash', r: (0.8 + Math.random() * 1.4).toFixed(1) });
      fleck.setAttribute('transform', `translate(${p[0].toFixed(1)} ${p[1].toFixed(1)})`);
      fleck.style.setProperty('--dx', `${((Math.random() - 0.5) * 18).toFixed(1)}px`);
      fleck.style.setProperty('--dy', `${(18 + Math.random() * 26).toFixed(1)}px`);
      fleck.addEventListener('animationend', () => fleck.remove());
      layer.append(fleck);
      layer.setAttribute('data-shed', String(shed));
      while (layer.childElementCount > 24) layer.firstElementChild?.remove();
    });
    return () => {
      off();
      remove();
    };
  },
  { fine: true },
);
