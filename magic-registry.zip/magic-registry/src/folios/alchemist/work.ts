/**
 * The Alchemist's Work and hand (R-ID-ALC-04, R-ID-ALC-06, R-FLO-ALC-CUR). As the reader goes
 * down the notebook, the Work passes through its four stages, and the notebook takes the colour
 * of each in turn. A hand laid on a metal's sign turns it to gold, and gold it stays. The cursor
 * is a droplet of quicksilver; the drops shaken from it turn yellow as they fall.
 */
import { cursorLayer, isMouse, listen, onFolio, svgEl } from '../effect';

const STAGES = 4;

onFolio(
  'alchemist',
  () => {
    const book = document.querySelector<HTMLElement>('[data-notebook]');
    if (!book) return;
    const stage = () => {
      const r = book.getBoundingClientRect();
      const read = (innerHeight * 0.6 - r.top) / Math.max(1, r.height);
      const s = Math.max(0, Math.min(STAGES - 1, Math.floor(read * STAGES)));
      if (book.dataset.stage !== String(s)) book.dataset.stage = String(s);
    };
    stage();
    const offScroll = listen(window, 'scroll', stage);
    const offResize = listen(window, 'resize', stage);
    let transmuted = 0;
    const offs = [...book.querySelectorAll<SVGSVGElement>('svg.metal')].map((m) =>
      listen(m.closest('h2') ?? m, 'pointerenter', () => {
        if (m.classList.contains('transmuted') || m.dataset.metal === 'sol') return;
        m.classList.add('transmuted');
        book.dataset.transmuted = String(++transmuted);
      }),
    );
    return () => {
      offScroll();
      offResize();
      offs.forEach((off) => off());
      book.querySelectorAll('.transmuted').forEach((m) => m.classList.remove('transmuted'));
    };
  },
  { motion: false },
);

const DROP = 'M0-5C3 0 4 2 4 3.4A4 4 0 0 1-4 3.4C-4 2-3 0 0-5Z';

onFolio(
  'alchemist',
  () => {
    const { layer, remove } = cursorLayer('transmuting-droplet');
    let travelled = 0;
    let last: [number, number] | null = null;
    let drops = 0;
    const off = listen(document, 'pointermove', (e) => {
      if (!isMouse(e)) return;
      const p: [number, number] = [e.clientX, e.clientY];
      if (last) travelled += Math.hypot(p[0] - last[0], p[1] - last[1]);
      last = p;
      if (travelled < 90) return;
      travelled = 0;
      const drop = svgEl('path', {
        class: 'falling-drop',
        d: DROP,
        transform: `translate(${p[0].toFixed(1)} ${(p[1] + 10).toFixed(1)}) scale(0.7)`,
      });
      drop.addEventListener('animationend', () => drop.remove());
      layer.append(drop);
      layer.setAttribute('data-drops', String(++drops));
      while (layer.childElementCount > 10) layer.firstElementChild?.remove();
    });
    return () => {
      off();
      remove();
    };
  },
  { fine: true },
);
