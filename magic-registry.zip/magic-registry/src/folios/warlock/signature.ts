/**
 * The Warlock's signature and hand (R-ID-WAR-06, R-FLO-WAR-CUR). The line at the foot of the
 * contract takes a signature in red ink, drawn by the pointer (a finger will do). Once enough
 * has been written the seal comes down on it, and it cannot be unsigned for as long as the leaf
 * is open. The cursor is a crimson nib, and it leaves a drop of ink behind now and then.
 */
import { cursorLayer, isMouse, listen, onFolio, svgEl } from '../effect';

/** How much must be written, in the field's own units, before the contract is binding. */
const BINDING = 160;

onFolio(
  'warlock',
  () => {
    const host = document.querySelector<HTMLElement>('[data-signature]');
    const field = host?.querySelector<SVGSVGElement>('svg.signature-field');
    const ink = field?.querySelector<SVGGElement>('g.ink');
    if (!host || !field || !ink) return;
    host.toggleAttribute('data-live', true);
    let pen: SVGPathElement | null = null;
    let last: [number, number] | null = null;
    let written = 0;
    const at = (e: PointerEvent): [number, number] | null => {
      const m = field.getScreenCTM();
      if (!m) return null;
      const p = new DOMPoint(e.clientX, e.clientY).matrixTransform(m.inverse());
      return [p.x, p.y];
    };
    const down = (e: PointerEvent) => {
      const p = at(e);
      if (!p) return;
      field.setPointerCapture(e.pointerId);
      last = p;
      pen = svgEl('path', { class: 'stroke', d: `M${p[0].toFixed(1)} ${p[1].toFixed(1)}` });
      ink.append(pen);
    };
    const move = (e: PointerEvent) => {
      if (!pen || !last) return;
      const p = at(e);
      if (!p) return;
      const step = Math.hypot(p[0] - last[0], p[1] - last[1]);
      if (step < 1.5) return;
      pen.setAttribute('d', `${pen.getAttribute('d')}L${p[0].toFixed(1)} ${p[1].toFixed(1)}`);
      last = p;
      written += step;
      host.dataset.written = String(Math.round(written));
      if (written >= BINDING && !host.hasAttribute('data-signed'))
        host.toggleAttribute('data-signed', true);
    };
    const up = () => {
      pen = null;
      last = null;
    };
    field.addEventListener('pointerdown', down);
    field.addEventListener('pointermove', move);
    field.addEventListener('pointerup', up);
    field.addEventListener('pointercancel', up);
    return () => {
      field.removeEventListener('pointerdown', down);
      field.removeEventListener('pointermove', move);
      field.removeEventListener('pointerup', up);
      field.removeEventListener('pointercancel', up);
      host.removeAttribute('data-live');
    };
  },
  { motion: false },
);

onFolio(
  'warlock',
  () => {
    const { layer, remove } = cursorLayer('crimson-nib');
    let travelled = 0;
    let last: [number, number] | null = null;
    let drops = 0;
    const off = listen(document, 'pointermove', (e) => {
      if (!isMouse(e)) return;
      const p: [number, number] = [e.clientX, e.clientY];
      if (last) travelled += Math.hypot(p[0] - last[0], p[1] - last[1]);
      last = p;
      if (travelled < 220) return;
      travelled = 0;
      const drop = svgEl('circle', {
        class: 'ink-drop',
        cx: (p[0] - 7).toFixed(1),
        cy: (p[1] + 9).toFixed(1),
        r: (1.6 + Math.random() * 1.2).toFixed(1),
      });
      drop.addEventListener('animationend', () => drop.remove());
      layer.append(drop);
      layer.setAttribute('data-drops', String(++drops));
      while (layer.childElementCount > 8) layer.firstElementChild?.remove();
    });
    return () => {
      off();
      remove();
    };
  },
  { fine: true },
);
