/**
 * The Paladin's shield (R-ID-PAL-04, R-ID-PAL-06, R-FLO-PAL-CUR). While the plate is in view,
 * steel motes come in from its edge and, on reaching the shield, turn aside by an angle no
 * honest ricochet would take, striking a spark. A press on the plate launches one from that
 * point at the shield, and it turns the same way. The cursor is a steel mote of its own: where
 * it crosses onto the shield, it is turned, and sparks.
 */
import { shieldOutline } from '~/lib/drawings/sky';
import type { Pt } from '~/lib/ink';
import { cursorLayer, frames, isMouse, listen, onFolio, svgEl } from '../effect';

const C = 300;
const R = 260;
const SHIELD: Pt[] = shieldOutline().map(([x, y]) => [C + x * R, C + y * R]);

function inside([x, y]: Pt, poly: Pt[] = SHIELD): boolean {
  let hit = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i]!;
    const [xj, yj] = poly[j]!;
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) hit = !hit;
  }
  return hit;
}

/** Four short strokes struck outward from a point. */
function spark(parent: Element, [x, y]: Pt, size: number): void {
  const d = [0, 1, 2, 3]
    .map((k) => {
      const a = (k * Math.PI) / 2 + Math.PI / 4;
      return `M${(x + Math.cos(a) * size * 0.3).toFixed(1)} ${(y + Math.sin(a) * size * 0.3).toFixed(1)}l${(Math.cos(a) * size).toFixed(1)} ${(Math.sin(a) * size).toFixed(1)}`;
    })
    .join('');
  const s = svgEl('path', { class: 'spark', d });
  s.addEventListener('animationend', () => s.remove());
  parent.append(s);
}

interface Mote {
  el: SVGCircleElement;
  p: Pt;
  v: Pt;
  turned: boolean;
  launched: boolean;
  age: number;
}

onFolio('paladin', () => {
  const host = document.querySelector<HTMLElement>('[data-shield]');
  const svg = host?.querySelector<SVGSVGElement>('svg.arms');
  const layer = svg?.querySelector<SVGGElement>('[data-motes]');
  if (!host || !svg || !layer) return;
  host.toggleAttribute('data-live', true);
  host.dataset.deflections = '0';
  host.dataset.ricochets = '0';
  const motes: Mote[] = [];
  let deflections = 0;
  let ricochets = 0;
  let seen = false;
  let next = 0.6;
  const watch = new IntersectionObserver(([e]) => (seen = !!e?.isIntersecting));
  watch.observe(svg);

  const add = (p: Pt, v: Pt, launched: boolean) => {
    const el = svgEl('circle', { class: 'mote', r: launched ? 6 : 4.5, cx: p[0], cy: p[1] });
    layer.append(el);
    motes.push({ el, p, v, turned: false, launched, age: 0 });
    while (motes.length > 8) motes.shift()!.el.remove();
  };

  const turn = (m: Mote) => {
    m.turned = true;
    // A true ricochet would leave near the mirror angle; these leave by one it should not take.
    const side = Math.random() < 0.5 ? -1 : 1;
    const a = side * (2.0 + Math.random() * 0.8);
    const [vx, vy] = m.v;
    m.v = [
      (vx * Math.cos(a) - vy * Math.sin(a)) * 1.15,
      (vx * Math.sin(a) + vy * Math.cos(a)) * 1.15,
    ];
    spark(layer, m.p, 16);
    host.dataset.deflections = String(++deflections);
    if (m.launched) host.dataset.ricochets = String(++ricochets);
  };

  let last = 0;
  const stop = frames((t) => {
    const dt = last ? Math.min(0.05, (t - last) / 1000) : 0;
    last = t;
    if (seen && document.visibilityState === 'visible') {
      next -= dt;
      if (next <= 0) {
        next = 1.4 + Math.random() * 1.4;
        const a = Math.random() * Math.PI * 2;
        const p: Pt = [C + Math.cos(a) * 292, C + Math.sin(a) * 292];
        const aim: Pt = [
          C + (Math.random() - 0.5) * 160 - p[0],
          C + (Math.random() - 0.5) * 160 - p[1],
        ];
        const n = Math.hypot(...aim);
        add(p, [(aim[0] / n) * 150, (aim[1] / n) * 150], false);
      }
    }
    for (let i = motes.length - 1; i >= 0; i--) {
      const m = motes[i]!;
      m.age += dt;
      m.p = [m.p[0] + m.v[0] * dt, m.p[1] + m.v[1] * dt];
      if (!m.turned && inside(m.p)) turn(m);
      const outward = (m.p[0] - C) * m.v[0] + (m.p[1] - C) * m.v[1] > 0;
      const far = outward && Math.hypot(m.p[0] - C, m.p[1] - C) > 330;
      if (far || m.age > 6) {
        m.el.remove();
        motes.splice(i, 1);
        continue;
      }
      m.el.setAttribute('cx', m.p[0].toFixed(1));
      m.el.setAttribute('cy', m.p[1].toFixed(1));
    }
  });

  const toPlate = (e: PointerEvent): Pt => {
    const m = svg.getScreenCTM();
    if (!m) return [C, C];
    const p = new DOMPoint(e.clientX, e.clientY).matrixTransform(m.inverse());
    return [p.x, p.y];
  };
  const offDown = listen(svg, 'pointerdown', (e) => {
    const p = toPlate(e as PointerEvent);
    const aim: Pt = [C - p[0], C - p[1]];
    const n = Math.hypot(...aim) || 1;
    if (inside(p)) {
      const m: Mote = {
        el: svgEl('circle', { class: 'mote', r: 6, cx: p[0], cy: p[1] }),
        p,
        v: [(-aim[0] / n) * 380, (-aim[1] / n) * 380],
        turned: false,
        launched: true,
        age: 0,
      };
      layer.append(m.el);
      motes.push(m);
      turn(m);
      return;
    }
    add(p, [(aim[0] / n) * 380, (aim[1] / n) * 380], true);
  });

  return () => {
    stop();
    offDown();
    watch.disconnect();
    for (const m of motes) m.el.remove();
    host.removeAttribute('data-live');
  };
});

onFolio(
  'paladin',
  () => {
    const svg = document.querySelector<SVGSVGElement>('[data-shield] svg.arms');
    const { layer, remove } = cursorLayer('steel-mote');
    let was = false;
    let sparks = 0;
    const off = listen(document, 'pointermove', (e) => {
      if (!isMouse(e) || !svg) return;
      const m = svg.getScreenCTM();
      if (!m) return;
      const p = new DOMPoint(e.clientX, e.clientY).matrixTransform(m.inverse());
      const now = inside([p.x, p.y]);
      if (now && !was) {
        spark(layer, [e.clientX, e.clientY], 9);
        layer.setAttribute('data-sparks', String(++sparks));
      }
      was = now;
    });
    return () => {
      off();
      remove();
    };
  },
  { fine: true },
);
