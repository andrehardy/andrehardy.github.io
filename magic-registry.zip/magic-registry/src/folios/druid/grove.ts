/**
 * The Druid's grove (R-ID-DRU-04, R-ID-DRU-06, R-FLO-DRU-CUR). The leaf takes the reader's own
 * season, not the season it was printed in. On the plate, each tendril leans its tip toward a
 * hand that comes near, never further than it can grow, and curls back when the hand goes. The
 * cursor is a spore: shaken loose as the hand moves, it drifts down and sprouts where it lands.
 */
import { cursorLayer, frames, isMouse, listen, onFolio, svgEl } from '../effect';
import { seasonOf } from './season';

onFolio(
  'druid',
  () => {
    const season = seasonOf(new Date());
    for (const el of document.querySelectorAll<HTMLElement>('[data-season]'))
      el.dataset.season = season;
  },
  { motion: false },
);

const REACH = 120;
const NOTICE = 230;

onFolio('druid', () => {
  const host = document.querySelector<HTMLElement>('[data-grove-plate]');
  const svg = host?.querySelector<SVGSVGElement>('svg.seed-head');
  if (!host || !svg) return;
  const tendrils = [...svg.querySelectorAll<SVGPathElement>('path.tendril')].map((el) => {
    const base = el.dataset.base!.split(' ').map(Number) as [number, number];
    const rest = el.dataset.rest!.split(' ').map(Number) as [number, number];
    return { el, base, rest, tip: [...rest] as [number, number] };
  });
  host.toggleAttribute('data-live', true);
  let hand: [number, number] | null = null;
  const offMove = listen(svg, 'pointermove', (e) => {
    const m = svg.getScreenCTM();
    if (!m) return;
    const p = new DOMPoint(e.clientX, e.clientY).matrixTransform(m.inverse());
    hand = [p.x, p.y];
  });
  const offLeave = listen(svg, 'pointerleave', () => (hand = null));
  let settled = false;
  const stop = frames(() => {
    if (!hand && settled) return;
    let reaching = 0;
    let moving = false;
    for (const t of tendrils) {
      let goal = t.rest;
      if (hand) {
        const dx = hand[0] - t.base[0];
        const dy = hand[1] - t.base[1];
        const d = Math.hypot(dx, dy);
        if (d < NOTICE) {
          const k = Math.min(1, REACH / Math.max(d, 1));
          goal = [t.base[0] + dx * k, t.base[1] + dy * k];
          reaching++;
        }
      }
      const nx = t.tip[0] + (goal[0] - t.tip[0]) * 0.08;
      const ny = t.tip[1] + (goal[1] - t.tip[1]) * 0.08;
      if (Math.abs(nx - t.tip[0]) + Math.abs(ny - t.tip[1]) > 0.05) moving = true;
      t.tip = [nx, ny];
      // The tendril bows toward the centre as it grows, so it reaches like a living thing.
      const cx = (t.base[0] + t.tip[0]) / 2 + (300 - (t.base[0] + t.tip[0]) / 2) * 0.35;
      const cy = (t.base[1] + t.tip[1]) / 2 + (300 - (t.base[1] + t.tip[1]) / 2) * 0.35;
      t.el.setAttribute(
        'd',
        `M${t.base[0].toFixed(1)} ${t.base[1].toFixed(1)}Q${cx.toFixed(1)} ${cy.toFixed(1)} ${t.tip[0].toFixed(1)} ${t.tip[1].toFixed(1)}`,
      );
      t.el.classList.toggle('reaching', goal !== t.rest);
    }
    host.dataset.reaching = String(reaching);
    if (!moving && !hand) {
      if (!settled) host.dataset.settled = '';
      settled = true;
    } else {
      settled = false;
      delete host.dataset.settled;
    }
  });
  return () => {
    offMove();
    offLeave();
    stop();
    host.removeAttribute('data-live');
  };
});

const LEAVES = 'M0 0V-7M0-4C-4-6-6-9-6-11C-3-11-1-8 0-5M0-5C1-8 3-11 6-11C6-9 4-6 0-4';

onFolio(
  'druid',
  () => {
    const { layer, remove } = cursorLayer('sprouting-spores');
    let last: [number, number] | null = null;
    let at = 0;
    let shed = 0;
    const off = listen(document, 'pointermove', (e) => {
      if (!isMouse(e)) return;
      const now = performance.now();
      const p: [number, number] = [e.clientX, e.clientY];
      if (last && (now - at < 140 || Math.hypot(p[0] - last[0], p[1] - last[1]) < 36)) return;
      last = p;
      at = now;
      const dx = (Math.random() - 0.5) * 30;
      const dy = 40 + Math.random() * 40;
      const spore = svgEl('circle', { class: 'spore', cx: p[0], cy: p[1], r: 2.2 });
      spore.style.setProperty('--dx', `${dx.toFixed(1)}px`);
      spore.style.setProperty('--dy', `${dy.toFixed(1)}px`);
      spore.addEventListener('animationend', () => {
        spore.remove();
        const sprout = svgEl('path', {
          class: 'sprout',
          d: LEAVES,
          pathLength: 1,
          'stroke-dasharray': 1,
          transform: `translate(${(p[0] + dx).toFixed(1)} ${(p[1] + dy).toFixed(1)})`,
        });
        sprout.addEventListener('animationend', () => sprout.remove());
        layer.append(sprout);
      });
      layer.append(spore);
      layer.setAttribute('data-shed', String(++shed));
      while (layer.childElementCount > 16) layer.firstElementChild?.remove();
    });
    return () => {
      off();
      remove();
    };
  },
  { fine: true },
);
