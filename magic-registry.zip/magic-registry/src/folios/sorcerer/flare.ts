/**
 * The Sorcerer's charge and hand (R-ID-SOR-06, R-FLO-SOR-CUR). Held on the plate, the hand
 * gathers a charge: a ring closes in on the wound at the centre. Let go once it has gathered,
 * and the charge flares out along every branch of the scar, and where the hand was the sheet is
 * burned, and stays burned for as long as the leaf is open: nothing is spent without a mark.
 * The cursor is an ember that throws off sparks as it moves.
 */
import { cursorLayer, isMouse, listen, onFolio, svgEl } from '../effect';

/** How long the hand must be held, in milliseconds, before letting go makes a flare. */
const GATHER = 350;

onFolio('sorcerer', () => {
  const host = document.querySelector<HTMLElement>('[data-charged]');
  const svg = host?.querySelector<SVGSVGElement>('svg.scar');
  const burns = svg?.querySelector<SVGGElement>('g.burns');
  if (!host || !svg || !burns) return;
  host.toggleAttribute('data-live', true);
  let since = 0;
  let flares = 0;
  const at = (e: PointerEvent): [number, number] | null => {
    const m = svg.getScreenCTM();
    if (!m) return null;
    const p = new DOMPoint(e.clientX, e.clientY).matrixTransform(m.inverse());
    return [p.x, p.y];
  };
  const down = (e: PointerEvent) => {
    since = performance.now();
    host.toggleAttribute('data-gathering', true);
    svg.setPointerCapture(e.pointerId);
  };
  const up = (e: PointerEvent) => {
    if (!since) return;
    const held = performance.now() - since;
    since = 0;
    host.removeAttribute('data-gathering');
    if (held < GATHER) return;
    const p = at(e);
    host.classList.remove('flaring');
    void host.getBoundingClientRect();
    host.classList.add('flaring');
    host.dataset.flares = String(++flares);
    if (p)
      burns.append(
        svgEl('circle', {
          class: 'burn',
          cx: p[0].toFixed(1),
          cy: p[1].toFixed(1),
          r: (16 + Math.random() * 10).toFixed(1),
        }),
      );
    host.dataset.scars = String(burns.childElementCount);
  };
  const cancel = () => {
    since = 0;
    host.removeAttribute('data-gathering');
  };
  const offEnd = listen(host, 'animationend', (e) => {
    if (e.animationName === 'sorcerer-flare') host.classList.remove('flaring');
  });
  svg.addEventListener('pointerdown', down);
  svg.addEventListener('pointerup', up);
  svg.addEventListener('pointercancel', cancel);
  return () => {
    svg.removeEventListener('pointerdown', down);
    svg.removeEventListener('pointerup', up);
    svg.removeEventListener('pointercancel', cancel);
    offEnd();
    burns.replaceChildren();
    host.classList.remove('flaring');
    host.removeAttribute('data-gathering');
    host.removeAttribute('data-live');
  };
});

onFolio(
  'sorcerer',
  () => {
    const { layer, remove } = cursorLayer('crackling-ember');
    let last: [number, number] | null = null;
    let sparks = 0;
    const off = listen(document, 'pointermove', (e) => {
      if (!isMouse(e)) return;
      const p: [number, number] = [e.clientX, e.clientY];
      if (last && Math.hypot(p[0] - last[0], p[1] - last[1]) < 22) return;
      last = p;
      // A spark: three short jagged strokes thrown off from where the ember is.
      let d = `M${p[0].toFixed(1)} ${p[1].toFixed(1)}`;
      let [x, y] = p;
      const a = Math.random() * Math.PI * 2;
      for (let i = 0; i < 3; i++) {
        const turn = a + (Math.random() - 0.5) * 1.4;
        x += Math.cos(turn) * (4 + Math.random() * 5);
        y += Math.sin(turn) * (4 + Math.random() * 5);
        d += `L${x.toFixed(1)} ${y.toFixed(1)}`;
      }
      const spark = svgEl('path', { class: 'spark', d });
      spark.addEventListener('animationend', () => spark.remove());
      layer.append(spark);
      layer.setAttribute('data-sparks', String(++sparks));
      while (layer.childElementCount > 14) layer.firstElementChild?.remove();
    });
    return () => {
      off();
      remove();
    };
  },
  { fine: true },
);
