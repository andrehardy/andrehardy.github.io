/**
 * The Ephemeris: the Wizard's plate (R-PH4-02, R-ID-WIZ-01, R-ID-WIZ-04). A brass astrolabe on
 * a ruled ground: the limb with its scale of degrees, two orbits with their wanderers, the sigil
 * at the heart, and the threads of probability that leave the sky's edge and converge on one
 * point, where the sigil's construction ends. Shared by the plate and its tests.
 */
import { seeded } from '~/lib/ink';
import { SIGILS, placer } from '~/lib/sigils';
import type { Pt, Thread } from './thread';

export { NUDGE_LIMIT, along, nudgeFrom, nudged, threadD, type Thread } from './thread';

export const SIZE = 640;
export const C = SIZE / 2;
export const CENTRE: Pt = [C, C];
export const LIMB = { outer: 286, inner: 266 };
export const ORBITS = [206, 236];
export const SIGIL_R = 150;
export const RULE_STEP = 32;

const spec = SIGILS.wizard!;
const construction = spec.build();
/** Where every thread ends: the sigil's own focus, upright on the plate. */
export const FOCUS: Pt = placer(spec, C, C, SIGIL_R)(construction.points.get(spec.focus)!);

const rad = (deg: number) => (deg * Math.PI) / 180;
export const polar = (deg: number, r: number): Pt => [
  C + r * Math.cos(rad(deg)),
  C + r * Math.sin(rad(deg)),
];

/** The scale of degrees on the limb: every five, longer every fifteen, longest every thirty. */
export function ticks(): { a: Pt; b: Pt; deg: number; weight: 'minor' | 'mid' | 'major' }[] {
  const out = [];
  for (let deg = 0; deg < 360; deg += 5) {
    const weight = deg % 30 === 0 ? 'major' : deg % 15 === 0 ? 'mid' : 'minor';
    const len = weight === 'major' ? 20 : weight === 'mid' ? 13 : 8;
    out.push({ a: polar(deg - 90, LIMB.inner), b: polar(deg - 90, LIMB.inner + len), deg, weight });
  }
  return out as ReturnType<typeof ticks>;
}

/** Figures for every thirty degrees, read clockwise from the top, as on a limb. */
export function numerals(): { at: Pt; text: string }[] {
  const out = [];
  for (let deg = 0; deg < 360; deg += 30)
    out.push({ at: polar(deg - 90, LIMB.outer + 17), text: String(deg) });
  return out;
}

/** The two wanderers on the orbits (fixed for now; the orrery turns them in Phase 7). */
export const WANDERERS: Pt[] = [polar(212, ORBITS[0]!), polar(318, ORBITS[1]!)];

/** Eight threads: two fans from the sky's edge, bowing round the sigil to the focus. */
export function threads(): Thread[] {
  const rand = seeded(75);
  const fans: [number[], -1 | 1][] = [
    [[-172, -157, -142, -127], -1],
    [[-53, -38, -23, -8], 1],
  ];
  return fans.flatMap(([angles, side]) =>
    angles.map((deg, k): Thread => {
      const j = rand() - 0.5;
      return {
        from: polar(deg, LIMB.inner - 4),
        c1: polar(deg + side * (40 + 6 * j), 232 - 8 * k),
        c2: [FOCUS[0] + side * (40 + 16 * k + 10 * j), FOCUS[1] - 70 - 12 * k],
        to: FOCUS,
      };
    }),
  );
}
