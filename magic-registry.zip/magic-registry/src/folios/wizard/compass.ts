/**
 * The Wizard's cursor (R-FLO-WIZ-CUR): on this folio a fine pointer becomes a pair of
 * compasses, and wherever it travels far enough, a faint construction arc is struck about the
 * place it last rested, as a geometer sweeps an arc to find the next point. The arcs fade as
 * the next are drawn; a few at most stand at once. Touch and reduced motion keep the page
 * plain.
 */

const STRIDE = 90;
const MAX_ARCS = 8;
const SPAN = (22 * Math.PI) / 180;
const NS = 'http://www.w3.org/2000/svg';

let teardown: (() => void) | undefined;

function start() {
  teardown?.();
  teardown = undefined;
  const body = document.body;
  if (body.dataset.archetype !== 'wizard') return;
  if (!matchMedia('(pointer: fine)').matches) return;
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  body.classList.add('compass-cursor');
  const trail = document.createElementNS(NS, 'svg');
  trail.classList.add('compass-trail');
  trail.setAttribute('aria-hidden', 'true');
  trail.setAttribute('focusable', 'false');
  body.append(trail);

  let anchor: [number, number] | undefined;
  const strike = (x: number, y: number) => {
    if (!anchor) {
      anchor = [x, y];
      return;
    }
    const r = Math.hypot(x - anchor[0], y - anchor[1]);
    if (r < STRIDE) return;
    const a = Math.atan2(y - anchor[1], x - anchor[0]);
    const at = (t: number) =>
      `${(anchor![0] + r * Math.cos(t)).toFixed(1)} ${(anchor![1] + r * Math.sin(t)).toFixed(1)}`;
    const arc = document.createElementNS(NS, 'path');
    arc.classList.add('construction-arc');
    arc.setAttribute('pathLength', '1');
    arc.setAttribute('d', `M${at(a - SPAN)}A${r.toFixed(1)} ${r.toFixed(1)} 0 0 1 ${at(a + SPAN)}`);
    arc.addEventListener('animationend', (e) => {
      if ((e as AnimationEvent).animationName === 'arc-fade') arc.remove();
    });
    trail.append(arc);
    while (trail.childElementCount > MAX_ARCS) trail.firstElementChild?.remove();
    anchor = [x, y];
  };

  const move = (e: PointerEvent) => {
    if (e.pointerType === 'mouse' || e.pointerType === 'pen') strike(e.clientX, e.clientY);
  };
  const forget = () => (anchor = undefined);
  document.addEventListener('pointermove', move, { passive: true });
  addEventListener('scroll', forget, { passive: true });

  teardown = () => {
    document.removeEventListener('pointermove', move);
    removeEventListener('scroll', forget);
    trail.remove();
    body.classList.remove('compass-cursor');
  };
}

document.addEventListener('astro:page-load', start);
document.addEventListener('astro:before-swap', () => {
  teardown?.();
  teardown = undefined;
});
