/**
 * How a thread returns when the hand lets it go: a critically damped glide, worked exactly for
 * any moment so the frames may fall where they like. A thread may carry its speed into a new
 * return, but never so much that it would cross its rest and come back: nothing here bounces.
 */
import type { Pt } from './thread';

/** The pull of a thread back to rest. */
export const STIFFNESS = 9;

/** Below this, in plate units and units a second, a thread is at rest. */
const SETTLED = 0.02;

/** A return under way: where it began relative to its rest, how fast, and when (ms). */
export interface Glide {
  x: Pt;
  v: Pt;
  t: number;
}

/**
 * The speed a thread may carry into a new return: anything rushing toward rest faster than the
 * return itself would is checked, so the path never crosses its rest and comes back.
 */
export function held(x0: number, v0: number): number {
  const floor = -STIFFNESS * x0;
  return x0 > 0 ? Math.max(v0, floor) : x0 < 0 ? Math.min(v0, floor) : v0;
}

/** Starts a return from an offset and a speed, checking the speed as above. */
export function launch(x: Pt, v: Pt, t: number): Glide {
  return { x: [x[0], x[1]], v: [held(x[0], v[0]), held(x[1], v[1])], t };
}

/** Where a return stands at a moment (ms): its offset from rest, its speed, and whether it moves. */
export function glideAt(g: Glide, now: number): { x: Pt; v: Pt; moving: boolean } {
  const t = Math.max(0, (now - g.t) / 1000);
  const decay = Math.exp(-STIFFNESS * t);
  const x: Pt = [0, 0];
  const v: Pt = [0, 0];
  let moving = false;
  for (const i of [0, 1] as const) {
    const lead = g.v[i] + STIFFNESS * g.x[i];
    x[i] = (g.x[i] + lead * t) * decay;
    v[i] = (g.v[i] - STIFFNESS * lead * t) * decay;
    if (Math.abs(x[i]) > SETTLED || Math.abs(v[i]) > SETTLED) moving = true;
  }
  return moving ? { x, v, moving } : { x: [0, 0], v: [0, 0], moving };
}
