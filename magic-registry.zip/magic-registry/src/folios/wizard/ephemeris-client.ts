/**
 * The Ephemeris, alive (R-ID-WIZ-06): a hand passing over a thread of probability pushes it
 * aside, and it eases back when the hand goes, with no overshoot; each touch lets a grain fall
 * along the thread to the focus, where a ring sounds on arrival. While the plate is in view a
 * grain falls of its own accord now and then. Under reduced motion the plate stays still.
 */
import { glideAt, launch, type Glide } from './glide';
import { along, nudgeFrom, nudged, threadD, type Pt, type Thread } from './thread';

const FALL_MS = 2600;
const IDLE_MS = 7500;
const MAX_GRAINS = 6;

interface Strand {
  index: number;
  thread: Thread;
  path: SVGPathElement;
  /** The thread's reach for the hand; it stays where the thread rests, so a still hand stays in. */
  hit: SVGPathElement;
  /** The nudge now, and how fast it is changing. */
  n: Pt;
  v: Pt;
  target: Pt;
  /** Where the motion toward the target began: offset from it, speed, and the moment. */
  from: Glide;
}

/** Moves a strand along its return to the moment given; reports whether it still moves. */
function glide(s: Strand, now: number): boolean {
  const g = glideAt(s.from, now);
  s.n = [s.target[0] + g.x[0], s.target[1] + g.x[1]];
  s.v = g.v;
  return g.moving;
}

let teardown: (() => void) | undefined;

function start() {
  teardown?.();
  teardown = undefined;
  const svg = document.querySelector<SVGSVGElement>('svg.ephemeris');
  if (!svg || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const layer = svg.querySelector<SVGGElement>('.threads');
  const ring = svg.querySelector<SVGCircleElement>('.arrival');
  const resting = svg.querySelector<SVGCircleElement>('.grain.resting');
  if (!layer || !ring || !resting) return;

  const box = svg.viewBox.baseVal;
  const centre: Pt = [box.x + box.width / 2, box.y + box.height / 2];
  const strands: Strand[] = [...svg.querySelectorAll<SVGPathElement>('path.thread')].map((path) => {
    const index = Number(path.dataset.thread);
    return {
      index,
      thread: JSON.parse(path.dataset.geom!) as Thread,
      path,
      hit: svg.querySelector<SVGPathElement>(`path.thread-hit[data-thread="${index}"]`)!,
      n: [0, 0],
      v: [0, 0],
      target: [0, 0],
      from: { x: [0, 0], v: [0, 0], t: 0 },
    };
  });
  const frames = new Set<number>();
  let settling = 0;

  const settle = () => {
    frames.delete(settling);
    const now = performance.now();
    let moving = false;
    for (const s of strands) {
      if (glide(s, now)) moving = true;
      s.path.setAttribute('d', threadD(nudged(s.thread, s.n)));
    }
    settling = moving ? requestAnimationFrame(settle) : 0;
    if (settling) frames.add(settling);
  };
  /** Sets a strand moving toward a new rest, from wherever and however fast it now is. */
  const aim = (s: Strand, target: Pt) => {
    glide(s, performance.now());
    s.target = target;
    const x: Pt = [s.n[0] - target[0], s.n[1] - target[1]];
    s.from = launch(x, s.v, performance.now());
    if (settling) return;
    settling = requestAnimationFrame(settle);
    frames.add(settling);
  };

  const sound = () => {
    ring.classList.remove('ringing');
    void ring.getBoundingClientRect();
    ring.classList.add('ringing');
    svg.dataset.arrivals = String(Number(svg.dataset.arrivals ?? 0) + 1);
  };

  const fall = (s: Strand) => {
    if (layer.querySelectorAll('.grain.falling').length >= MAX_GRAINS) return;
    const grain = resting.cloneNode() as SVGCircleElement;
    grain.classList.replace('resting', 'falling');
    grain.removeAttribute('style');
    grain.dataset.thread = String(s.index);
    layer.insertBefore(grain, ring);
    const t0 = performance.now();
    const drop = (now: number) => {
      frames.delete(id);
      const t = Math.min(1, (now - t0) / FALL_MS);
      const p = along(nudged(s.thread, s.n), (1 - Math.cos(Math.PI * t)) / 2);
      grain.setAttribute('cx', p[0].toFixed(2));
      grain.setAttribute('cy', p[1].toFixed(2));
      if (t < 1) {
        id = requestAnimationFrame(drop);
        frames.add(id);
      } else {
        grain.remove();
        sound();
      }
    };
    let id = requestAnimationFrame(drop);
    frames.add(id);
  };

  const toPlate = (event: PointerEvent): Pt => {
    const m = svg.getScreenCTM();
    if (!m) return centre;
    const p = new DOMPoint(event.clientX, event.clientY).matrixTransform(m.inverse());
    return [p.x, p.y];
  };

  const listeners: [SVGPathElement, string, (e: Event) => void][] = [];
  for (const s of strands) {
    const enter = (e: Event) => {
      aim(s, nudgeFrom(s.thread, toPlate(e as PointerEvent), centre));
      s.path.classList.add('nudged');
      fall(s);
    };
    const leave = () => {
      aim(s, [0, 0]);
      s.path.classList.remove('nudged');
    };
    s.hit.addEventListener('pointerenter', enter);
    s.hit.addEventListener('pointerleave', leave);
    listeners.push([s.hit, 'pointerenter', enter], [s.hit, 'pointerleave', leave]);
  }

  let seen = false;
  const watch = new IntersectionObserver(([entry]) => (seen = !!entry?.isIntersecting));
  watch.observe(svg);
  let turn = 0;
  const idle = setInterval(() => {
    if (!seen || document.visibilityState !== 'visible') return;
    fall(strands[turn++ % strands.length]!);
  }, IDLE_MS);

  svg.dataset.live = '';
  teardown = () => {
    clearInterval(idle);
    watch.disconnect();
    frames.forEach((id) => cancelAnimationFrame(id));
    frames.clear();
    for (const [el, type, fn] of listeners) el.removeEventListener(type, fn);
    delete svg.dataset.live;
  };
}

document.addEventListener('astro:page-load', start);
document.addEventListener('astro:before-swap', () => {
  teardown?.();
  teardown = undefined;
});
