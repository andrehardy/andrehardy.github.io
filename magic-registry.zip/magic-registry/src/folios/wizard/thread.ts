/**
 * The threads of probability on the Wizard's plate, as curves: how one is drawn, where a point
 * lies along it, and how far a passing hand pulls it. Kept apart from the plate's construction
 * so the page's script carries only this.
 */

export type Pt = [number, number];

export interface Thread {
  from: Pt;
  c1: Pt;
  c2: Pt;
  to: Pt;
}

const r2 = (n: number) => Math.round(n * 100) / 100;

/** A thread with its middle pulled by a nudge (both inner handles move together). */
export function nudged(t: Thread, n: Pt = [0, 0]): Thread {
  return {
    from: t.from,
    c1: [t.c1[0] + n[0], t.c1[1] + n[1]],
    c2: [t.c2[0] + n[0] * 0.8, t.c2[1] + n[1] * 0.8],
    to: t.to,
  };
}

export function threadD(t: Thread): string {
  const p = (q: Pt) => `${r2(q[0])} ${r2(q[1])}`;
  return `M${p(t.from)}C${p(t.c1)} ${p(t.c2)} ${p(t.to)}`;
}

/** The point a fraction s of the way along a thread (by its curve parameter). */
export function along(t: Thread, s: number): Pt {
  const u = 1 - s;
  const f = (i: 0 | 1) =>
    u * u * u * t.from[i] + 3 * u * u * s * t.c1[i] + 3 * u * s * s * t.c2[i] + s * s * s * t.to[i];
  return [f(0), f(1)];
}

/** How far a hovering hand may pull a thread, in plate units. */
export const NUDGE_LIMIT = 30;

/**
 * The nudge a passing hand gives a thread: the thread gives way, pushed from the hand by the
 * full limit. A hand right on the thread pushes it outward, away from the plate's centre.
 */
export function nudgeFrom(t: Thread, hand: Pt, centre: Pt): Pt {
  let near = t.from;
  for (let i = 0; i <= 40; i++) {
    const p = along(t, i / 40);
    if (
      Math.hypot(p[0] - hand[0], p[1] - hand[1]) < Math.hypot(near[0] - hand[0], near[1] - hand[1])
    )
      near = p;
  }
  let v: Pt = [near[0] - hand[0], near[1] - hand[1]];
  if (Math.hypot(v[0], v[1]) < 2) v = [near[0] - centre[0], near[1] - centre[1]];
  const len = Math.hypot(v[0], v[1]) || 1;
  return [(v[0] / len) * NUDGE_LIMIT, (v[1] / len) * NUDGE_LIMIT];
}
