/**
 * The Bard's strings and hand (R-ID-BAR-06, R-FLO-BAR-CUR). A hand drawn across a string plucks
 * it: the string swings in its first mode and dies away, and the plate's figure rings with it.
 * Nothing sounds unless the reader has turned the registry's sound on (this folio's switch is
 * one of its switches); then each string sounds its own note, softly. The cursor trails a
 * waveform that swells with the speed of the hand and settles when it stops.
 */
import { audio, strike } from '~/lib/sound';
import { cursorLayer, frames, isMouse, listen, onFolio, reducedMotion, svgEl } from '../effect';

/** How long a plucked string rings, in seconds, and how far it swings at first, in its units. */
const RING = 1.6;
const SWING = 9;

/** A plucked string's own note, through the registry's sound, if the reader has turned it on. */
function pluck(hz: number) {
  const live = audio();
  if (live)
    strike(live.ctx, live.out, { source: 'triangle', hz, attack: 0.01, decay: RING, gain: 0.12 });
}

onFolio(
  'bard',
  () => {
    const host = document.querySelector<HTMLElement>('[data-strung]');
    const svg = host?.querySelector<SVGSVGElement>('svg.strings');
    const plate = document.querySelector<SVGSVGElement>('[data-chladni]');
    if (!host || !svg) return;
    const strings = [...svg.querySelectorAll<SVGPathElement>('path.string')].map((el) => ({
      el,
      y: Number(el.dataset.y),
      hz: Number(el.dataset.hz),
      at: 400,
      struck: -1,
    }));

    host.toggleAttribute('data-live', true);
    let plucks = 0;
    let lastY: number | null = null;
    const toLocal = (e: PointerEvent) => {
      const m = svg.getScreenCTM();
      if (!m) return null;
      return new DOMPoint(e.clientX, e.clientY).matrixTransform(m.inverse());
    };
    const still = reducedMotion();
    const strike = (s: (typeof strings)[number], x: number) => {
      host.dataset.plucks = String(++plucks);
      pluck(s.hz);
      if (still) return;
      s.at = Math.max(40, Math.min(760, x));
      s.struck = performance.now();
      if (plate) {
        plate.classList.remove('ringing');
        void plate.getBoundingClientRect();
        plate.classList.add('ringing');
      }
    };
    const offMove = listen(svg, 'pointermove', (e) => {
      const p = toLocal(e);
      if (!p) return;
      if (lastY !== null)
        for (const s of strings) if ((lastY - s.y) * (p.y - s.y) < 0) strike(s, p.x);
      lastY = p.y;
    });
    const offLeave = listen(svg, 'pointerleave', () => (lastY = null));
    // A tap plucks the nearest string: a touch drag across the strings is the page's scroll.
    const gap = Math.abs((strings[1]?.y ?? 0) - (strings[0]?.y ?? 0)) / 2;
    const offDown = listen(svg, 'pointerdown', (e) => {
      if (isMouse(e)) return;
      const p = toLocal(e);
      if (!p) return;
      const near = strings.reduce((a, b) => (Math.abs(b.y - p.y) < Math.abs(a.y - p.y) ? b : a));
      if (Math.abs(near.y - p.y) <= gap) strike(near, p.x);
    });
    const stop = still
      ? () => undefined
      : frames((now) => {
          for (const s of strings) {
            if (s.struck < 0) continue;
            const t = (now - s.struck) / 1000;
            if (t > RING) {
              s.el.setAttribute('d', `M18 ${s.y}L782 ${s.y}`);
              s.struck = -1;
              continue;
            }
            // The first mode, swinging at the struck point and dying away: a plucked string's shape.
            const amp = SWING * Math.exp(-3 * t) * Math.cos(t * 2 * Math.PI * 7);
            s.el.setAttribute(
              'd',
              `M18 ${s.y}Q${s.at.toFixed(1)} ${(s.y + amp * 2).toFixed(1)} 782 ${s.y}`,
            );
          }
        });
    return () => {
      offMove();
      offLeave();
      offDown();
      stop();
      for (const s of strings) s.el.setAttribute('d', `M18 ${s.y}L782 ${s.y}`);
      plate?.classList.remove('ringing');
      host.removeAttribute('data-live');
    };
  },
  { motion: false },
);

/** The trail's length in points, and how quickly the swell dies when the hand stops. */
const TRAIL = 28;
const DAMP = 0.9;

onFolio(
  'bard',
  () => {
    const { layer, remove } = cursorLayer('resonant-waveform');
    const wave = svgEl('polyline', { class: 'waveform' });
    layer.append(wave);
    const pts: [number, number][] = [];
    let swell = 0;
    let last: [number, number] | null = null;
    const off = listen(document, 'pointermove', (e) => {
      if (!isMouse(e)) return;
      const p: [number, number] = [e.clientX, e.clientY];
      if (last) swell = Math.min(10, swell + Math.hypot(p[0] - last[0], p[1] - last[1]) * 0.08);
      last = p;
      pts.push(p);
      while (pts.length > TRAIL) pts.shift();
    });
    const stop = frames((now) => {
      swell *= DAMP;
      if (pts.length < 2) return;
      const shown = pts.map(([x, y], i) => {
        const fade = i / pts.length;
        const off = Math.sin(i * 1.3 - now / 60) * swell * fade;
        return `${x.toFixed(1)},${(y + 14 + off).toFixed(1)}`;
      });
      wave.setAttribute('points', shown.join(' '));
      layer.dataset.swell = swell.toFixed(1);
    });
    return () => {
      off();
      stop();
      remove();
    };
  },
  { fine: true },
);
