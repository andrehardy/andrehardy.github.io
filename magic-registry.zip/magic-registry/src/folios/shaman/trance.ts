/**
 * The Shaman's trance and hand (R-ID-SHA-06, R-FLO-SHA-CUR). A hand held still on the leaf lets
 * the trance come: after a moment the forms behind the eyes rise over the page in the vision's
 * cyan, deeper the longer the hand stays, and a movement breaks it. The cursor is an ochre hand;
 * on each beat of the drum it leaves its print where it is, and the print fades by the next.
 */
import { cursorLayer, frames, isMouse, listen, onFolio, svgEl } from '../effect';

/** The drum's tempo, matched to the skin's pulse in shaman.css. */
const BEAT = 1300;
const STILL_AFTER = 700;
const DEEPEN = 7000;

const HAND = 'M0 7a6.5 6.5 0 1 0 0.01 0ZM-8-6h3v10h-3ZM-4-9h3v12h-3ZM0-9h3v12h-3ZM4-6h3v10h-3Z';

onFolio(
  'shaman',
  () => {
    const { layer, remove } = cursorLayer('ochre-handprint');
    const veil = document.createElement('div');
    veil.className = 'trance-veil';
    veil.setAttribute('aria-hidden', 'true');
    document.body.append(veil);

    let x = -1;
    let y = -1;
    let moved = 0;
    let lastMove = performance.now();
    let depth = 0;
    let prints = 0;
    const offMove = listen(document, 'pointermove', (e) => {
      if (!isMouse(e)) return;
      if (Math.hypot(e.clientX - x, e.clientY - y) > 4) {
        lastMove = performance.now();
        moved = lastMove;
      }
      x = e.clientX;
      y = e.clientY;
    });
    const offLeave = listen(document, 'pointerout', (e) => {
      if (!e.relatedTarget) x = -1;
    });

    let last = 0;
    let drawn = '';
    const stop = frames((t) => {
      const dt = last ? Math.min(0.5, (t - last) / 1000) : 0;
      last = t;
      const held = t - lastMove - STILL_AFTER;
      const still = x >= 0 && held > 0 && document.visibilityState === 'visible';
      depth = still ? Math.min(1, held / DEEPEN) : Math.max(0, depth - dt * 2.5);
      const shown = `${depth.toFixed(2)} ${x} ${y}`;
      if (shown === drawn) return;
      drawn = shown;
      veil.style.setProperty('--depth', depth.toFixed(2));
      veil.style.setProperty('--tx', `${x}px`);
      veil.style.setProperty('--ty', `${y}px`);
      veil.dataset.depth = String(Math.round(depth * 10));
    });

    const beat = setInterval(() => {
      if (x < 0 || performance.now() - moved > BEAT * 2) return;
      const print = svgEl('path', {
        class: 'handprint',
        d: HAND,
        transform: `translate(${x} ${y}) rotate(${(Math.random() * 30 - 15).toFixed(1)})`,
      });
      print.addEventListener('animationend', () => print.remove());
      layer.append(print);
      layer.setAttribute('data-prints', String(++prints));
      while (layer.childElementCount > 4) layer.firstElementChild?.remove();
    }, BEAT);

    return () => {
      offMove();
      offLeave();
      stop();
      clearInterval(beat);
      veil.remove();
      remove();
    };
  },
  { fine: true },
);
