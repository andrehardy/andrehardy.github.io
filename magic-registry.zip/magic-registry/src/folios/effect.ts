/**
 * The life of a folio's living parts: its cursor and its interaction start when that folio's
 * leaf is shown and are taken down before the next leaf is swapped in, so nothing of one folio
 * survives into another. A cursor belongs to a fine pointer; nothing moves under reduced motion.
 */
import type { ArchetypeId } from '~/data/palettes';

type Teardown = () => void;

export interface Needs {
  /** Only for a mouse or pen (a cursor, a hover). */
  fine?: boolean;
  /** Only where motion is allowed. Default true. */
  motion?: boolean;
}

export const finePointer = () => matchMedia('(pointer: fine)').matches;
export const reducedMotion = () => matchMedia('(prefers-reduced-motion: reduce)').matches;
export const isMouse = (e: PointerEvent) => e.pointerType === 'mouse' || e.pointerType === 'pen';

export function onFolio(id: ArchetypeId, setup: () => Teardown | void, needs: Needs = {}): void {
  let teardown: Teardown | undefined;
  const stop = () => {
    teardown?.();
    teardown = undefined;
  };
  document.addEventListener('astro:page-load', () => {
    stop();
    if (document.body.dataset.archetype !== id) return;
    if (needs.fine && !finePointer()) return;
    if ((needs.motion ?? true) && reducedMotion()) return;
    teardown = setup() ?? undefined;
  });
  document.addEventListener('astro:before-swap', stop);
}

/**
 * A folio's cursor: the body takes `cursor-<name>` (its stylesheet sets the drawn pointer), and
 * a layer fixed over the viewport carries the cursor's trail. Returns the layer and its teardown.
 */
export function cursorLayer(
  name: string,
  svg = true,
): { layer: HTMLElement | SVGSVGElement; remove: Teardown } {
  const body = document.body;
  body.classList.add(`cursor-${name}`);
  const layer = svg
    ? document.createElementNS('http://www.w3.org/2000/svg', 'svg')
    : document.createElement('div');
  layer.classList.add('cursor-trail');
  layer.setAttribute('data-cursor', name);
  layer.setAttribute('aria-hidden', 'true');
  if (svg) layer.setAttribute('focusable', 'false');
  body.append(layer);
  return {
    layer,
    remove: () => {
      layer.remove();
      body.classList.remove(`cursor-${name}`);
    },
  };
}

/** Listens, and returns the unlistening. */
export function listen<K extends keyof DocumentEventMap>(
  target: Document | Window | HTMLElement | SVGElement,
  type: K,
  fn: (e: DocumentEventMap[K]) => void,
): Teardown {
  const opts = { passive: true };
  target.addEventListener(type, fn as EventListener, opts);
  return () => target.removeEventListener(type, fn as EventListener);
}

/** Runs fn each frame while `alive()` holds, and stops when torn down. */
export function frames(fn: (t: number) => boolean | void): Teardown {
  let id = 0;
  let on = true;
  const tick = (t: number) => {
    if (!on) return;
    if (fn(t) === false) return;
    id = requestAnimationFrame(tick);
  };
  id = requestAnimationFrame(tick);
  return () => {
    on = false;
    cancelAnimationFrame(id);
  };
}

export const NS = 'http://www.w3.org/2000/svg';

export function svgEl<K extends keyof SVGElementTagNameMap>(
  tag: K,
  attrs: Record<string, string | number>,
): SVGElementTagNameMap[K] {
  const el = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, String(v));
  return el;
}
