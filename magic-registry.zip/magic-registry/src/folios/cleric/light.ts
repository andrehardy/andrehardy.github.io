/**
 * The Cleric's light. Its cursor is a soft halo that pools light where it rests (R-FLO-CLE-CUR);
 * over the plate, that light burns away the grime laid on the rose (R-ID-CLE-06). The grime is
 * a sooted film of specks and smears, the same on every visit; each pass of the light clears a
 * soft round of it, and the plate keeps count. A tap clears a round on a touch screen too.
 */
import { seeded } from '~/lib/ink';
import { cursorLayer, frames, isMouse, listen, onFolio } from '../effect';

onFolio(
  'cleric',
  () => {
    const { layer, remove } = cursorLayer('soft-halo', false);
    const pool = document.createElement('div');
    pool.className = 'halo-pool';
    layer.append(pool);
    let x = -999;
    let y = -999;
    let px = x;
    let py = y;
    const off = listen(document, 'pointermove', (e) => {
      if (!isMouse(e)) return;
      x = e.clientX;
      y = e.clientY;
      if (px < -900) [px, py] = [x, y];
    });
    // The light follows the hand a little behind it, as a lamp swings on its chain.
    const stop = frames(() => {
      px += (x - px) * 0.18;
      py += (y - py) * 0.18;
      pool.style.transform = `translate(${px.toFixed(1)}px, ${py.toFixed(1)}px)`;
    });
    return () => {
      off();
      stop();
      remove();
    };
  },
  { fine: true },
);

onFolio(
  'cleric',
  () => {
    const host = document.querySelector<HTMLElement>('[data-rose]');
    const canvas = host?.querySelector<HTMLCanvasElement>('canvas[data-grime]');
    const ctx = canvas?.getContext('2d');
    if (!host || !canvas || !ctx) return;
    const ink = getComputedStyle(document.body).getPropertyValue('--ink-soft').trim() || '#46506b';
    let scale = 1;
    const lay = () => {
      const box = canvas.getBoundingClientRect();
      const dpr = Math.min(2, devicePixelRatio || 1);
      canvas.width = Math.round(box.width * dpr);
      canvas.height = Math.round(box.height * dpr);
      scale = canvas.width / Math.max(1, box.width);
      const w = canvas.width;
      const h = canvas.height;
      const rand = seeded(41);
      ctx.globalCompositeOperation = 'source-over';
      ctx.clearRect(0, 0, w, h);
      ctx.fillStyle = ink;
      ctx.globalAlpha = 0.2;
      ctx.beginPath();
      ctx.arc(w / 2, h / 2, w * 0.49, 0, Math.PI * 2);
      ctx.fill();
      for (let i = 0; i < 26; i++) {
        ctx.globalAlpha = 0.06 + rand() * 0.08;
        ctx.beginPath();
        ctx.ellipse(
          rand() * w,
          rand() * h,
          w * (0.05 + rand() * 0.12),
          h * (0.015 + rand() * 0.04),
          rand() * Math.PI,
          0,
          Math.PI * 2,
        );
        ctx.fill();
      }
      for (let i = 0; i < 1400; i++) {
        ctx.globalAlpha = 0.15 + rand() * 0.35;
        const r = (0.4 + rand() * 1.4) * dpr;
        ctx.fillRect(rand() * w, rand() * h, r, r);
      }
      ctx.globalAlpha = 1;
      host.dataset.cleansed = '0';
    };
    host.toggleAttribute('data-live', true);
    lay();
    let cleansed = 0;
    const burn = (e: PointerEvent) => {
      const box = canvas.getBoundingClientRect();
      const cx = (e.clientX - box.left) * scale;
      const cy = (e.clientY - box.top) * scale;
      const r = 46 * scale;
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
      g.addColorStop(0, 'rgba(0,0,0,0.9)');
      g.addColorStop(0.55, 'rgba(0,0,0,0.45)');
      g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.globalCompositeOperation = 'destination-out';
      ctx.fillStyle = g;
      ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
      ctx.globalCompositeOperation = 'source-over';
      host.dataset.cleansed = String(++cleansed);
    };
    const offMove = listen(
      canvas,
      'pointermove',
      (e) => isMouse(e as PointerEvent) && burn(e as PointerEvent),
    );
    const offDown = listen(canvas, 'pointerdown', (e) => burn(e as PointerEvent));
    let width = canvas.getBoundingClientRect().width;
    const resize = new ResizeObserver(() => {
      const w = canvas.getBoundingClientRect().width;
      if (Math.abs(w - width) < 1) return;
      width = w;
      cleansed = 0;
      lay();
    });
    resize.observe(canvas);
    return () => {
      offMove();
      offDown();
      resize.disconnect();
      host.removeAttribute('data-live');
    };
  },
  { motion: false },
);
