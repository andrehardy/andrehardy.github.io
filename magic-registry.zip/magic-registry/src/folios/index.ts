/**
 * The folios that have their own composition (R-PH4-09). Each archetype's folio is built as
 * its own component, with its own layout, plate and stylesheet; an archetype not listed here
 * still shows its plate on the bench.
 */
import type { ArchetypeId } from '~/data/palettes';
import AlchemistFolio from './AlchemistFolio.astro';
import BardFolio from './BardFolio.astro';
import ClericFolio from './ClericFolio.astro';
import DruidFolio from './DruidFolio.astro';
import EnchantressFolio from './EnchantressFolio.astro';
import NecromancerFolio from './NecromancerFolio.astro';
import PaladinFolio from './PaladinFolio.astro';
import ShamanFolio from './ShamanFolio.astro';
import SorcererFolio from './SorcererFolio.astro';
import WarlockFolio from './WarlockFolio.astro';
import WitchFolio from './WitchFolio.astro';
import WizardFolio from './WizardFolio.astro';

export const FOLIOS: Partial<Record<ArchetypeId, typeof WizardFolio>> = {
  wizard: WizardFolio,
  cleric: ClericFolio,
  paladin: PaladinFolio,
  shaman: ShamanFolio,
  druid: DruidFolio,
  witch: WitchFolio,
  enchantress: EnchantressFolio,
  warlock: WarlockFolio,
  necromancer: NecromancerFolio,
  bard: BardFolio,
  sorcerer: SorcererFolio,
  alchemist: AlchemistFolio,
};
