/**
 * The life of the descent's moving parts. Like a folio's, they start when the home leaf is
 * shown and are taken down before the next is swapped in. Each runs only while it can be
 * seen: on screen, in a tab the reader is looking at (R-CHOR-06). And each asks how much the
 * device can carry: a lighter tier draws less and less often (R-CHOR-07).
 */

export type Teardown = () => void;

export const reducedMotion = () => matchMedia('(prefers-reduced-motion: reduce)').matches;

export function onDescent(
  setup: (root: HTMLElement) => Teardown | void,
  { motion = true }: { motion?: boolean } = {},
): void {
  let teardown: Teardown | undefined;
  const stop = () => {
    teardown?.();
    teardown = undefined;
  };
  document.addEventListener('astro:page-load', () => {
    stop();
    const root = document.querySelector<HTMLElement>('[data-descent]');
    if (!root) return;
    if (motion && reducedMotion()) return;
    teardown = setup(root) ?? undefined;
  });
  document.addEventListener('astro:before-swap', stop);
}

/**
 * Runs `start` only while `el` is on screen and the page is visible, and stops it otherwise.
 * While it runs, `el` carries data-running, so the guard can be seen working.
 */
export function whileSeen(el: Element, start: () => Teardown, margin = '0px'): Teardown {
  let seen = false;
  let stopRun: Teardown | undefined;
  const update = () => {
    const want = seen && document.visibilityState === 'visible';
    if (want && !stopRun) {
      stopRun = start();
      el.toggleAttribute('data-running', true);
    } else if (!want && stopRun) {
      stopRun();
      stopRun = undefined;
      el.removeAttribute('data-running');
    }
  };
  const io = new IntersectionObserver(
    (entries) => {
      seen = entries.at(-1)?.isIntersecting ?? seen;
      update();
    },
    { rootMargin: margin },
  );
  io.observe(el);
  document.addEventListener('visibilitychange', update);
  return () => {
    io.disconnect();
    document.removeEventListener('visibilitychange', update);
    seen = false;
    update();
  };
}

export type Tier = 'full' | 'light';

export interface Device {
  cores?: number | undefined;
  /** Gigabytes, as navigator.deviceMemory reports it (rounded, and capped at 8). */
  memory?: number | undefined;
  saveData?: boolean | undefined;
}

/**
 * The lighter tier is for a device that says it is small (four cores or fewer, or four
 * gigabytes or less) or a reader who has asked to save data. Unknown means full.
 */
export function tierOf(d: Device): Tier {
  if (d.saveData) return 'light';
  if (d.cores !== undefined && d.cores <= 4) return 'light';
  if (d.memory !== undefined && d.memory <= 4) return 'light';
  return 'full';
}

export function deviceTier(): Tier {
  const nav = navigator as Navigator & {
    deviceMemory?: number;
    connection?: { saveData?: boolean };
  };
  let forced: string | null = null;
  try {
    forced = localStorage.getItem('mr-tier');
  } catch {
    // Storage refused: the device decides.
  }
  if (forced === 'light' || forced === 'full') return forced;
  return tierOf({
    cores: nav.hardwareConcurrency,
    memory: nav.deviceMemory,
    saveData: nav.connection?.saveData,
  });
}

/** Runs fn every frame, or at most `fps` times a second, until torn down. */
export function loop(fn: (t: number) => void, fps = 60): Teardown {
  let id = 0;
  let last = -Infinity;
  const gap = 1000 / fps - 2;
  const tick = (t: number) => {
    if (t - last >= gap) {
      last = t;
      fn(t);
    }
    id = requestAnimationFrame(tick);
  };
  id = requestAnimationFrame(tick);
  return () => cancelAnimationFrame(id);
}

export function listen<K extends keyof WindowEventMap>(
  target: Window | Document | HTMLElement,
  type: K,
  fn: (e: WindowEventMap[K]) => void,
): Teardown {
  target.addEventListener(type, fn as EventListener, { passive: true });
  return () => target.removeEventListener(type, fn as EventListener);
}
