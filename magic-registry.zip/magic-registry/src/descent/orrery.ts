/**
 * The orrery is set for tonight (R-SKY-04): each planet is put back to its mean longitude for
 * the reader's own date when the leaf opens. The build's date stands only where no script runs.
 * Setting the planets is not motion, so it is done under reduced motion too.
 */
import { onDescent } from './life';
import { PLANETS, meanLongitude } from '~/lib/sky';

onDescent(
  (root) => {
    const now = new Date();
    for (const orbit of root.querySelectorAll<SVGGElement>('[data-orrery] .orbit')) {
      const planet = PLANETS.find((p) => p.id === orbit.dataset.planet);
      if (planet)
        orbit.style.setProperty('--from', `${(-meanLongitude(planet, now)).toFixed(2)}deg`);
    }
  },
  { motion: false },
);
