/**
 * The firmament (R-SKY-01, R-SKY-03, R-DESC-02, R-MOT-01): the reader's own sky, tonight, from
 * the Yale Bright Star Catalogue, turned for their clock's longitude and their side of the
 * equator. Above the horizon the stars stand and the brightest scintillate; one figure at a
 * time traces itself in faintly and fades; now and then, never twice in a minute, a single
 * meteor falls. Below the horizon the same sky goes on, turned under, and its stars are drawn
 * as flecks of mica, garnet and verdigris in the rock. The canvas is held to the window while
 * the descent passes behind it, and draws only while it can be seen.
 */
import { COMPASS, SPAN, UNDERGROUND } from './firmament-geometry';
import {
  deviceTier,
  listen,
  loop,
  onDescent,
  reducedMotion,
  whileSeen,
  type Teardown,
} from './life';
import { horizontal, moonrise, nextMeteor, observerFrom, panorama, type Observer } from '~/lib/sky';

type Star = [ra: number, dec: number, mag: number, kelvin100: number];
interface Figure {
  id: string;
  rank: number;
  lines: [number, number][][];
}

const BASE = import.meta.env.BASE_URL.replace(/\/?$/, '/');
let catalogue: Promise<{ stars: Star[]; figures: Figure[] }> | undefined;
const load = () =>
  (catalogue ??= Promise.all([
    fetch(`${BASE}data/stars.json`).then((r) => r.json() as Promise<Star[]>),
    fetch(`${BASE}data/constellations.json`).then((r) => r.json() as Promise<Figure[]>),
  ]).then(([stars, figures]) => ({ stars, figures })));

const observer = (): Observer =>
  observerFrom(
    Intl.DateTimeFormat().resolvedOptions().timeZone ?? '',
    new Date().getTimezoneOffset(),
  );

/** How far the stars' plane lags the page, at the zenith; at the horizon it does not. */
const STAR_DEPTH = 0.15;
/** The figures traced: the principal ones, and only while they stand clear of the horizon. */
const TRACE_RANK = 1;
const TRACE_MIN_ALT = 10;
/** A meteor's flight, in milliseconds, and its length, in CSS pixels. */
const METEOR_FLIGHT = 900;
const METEOR_LENGTH = 150;

/** A star's tint from its temperature: ember red-orange, candle, white, then a cold blue-white. */
function tint(k100: number): [number, number, number] {
  if (k100 < 40) return [255, 196, 150];
  if (k100 < 55) return [255, 222, 180];
  if (k100 < 75) return [255, 244, 222];
  if (k100 < 100) return [246, 246, 255];
  return [214, 226, 255];
}
const MINERALS: [number, number, number][] = [
  [214, 178, 96],
  [150, 52, 52],
  [88, 150, 128],
];

interface Placed {
  alt: number;
  x: number;
  y: number;
  mag: number;
  rgb: [number, number, number];
  i: number;
}

/** Kept across visits to the home, so a reader who returns within the minute sees no early one. */
let lastMeteor: number | null = null;

onDescent(
  (root) => {
    const firmament = root.querySelector<HTMLElement>('[data-firmament]');
    const canvas = firmament?.querySelector<HTMLCanvasElement>('canvas[data-sky]');
    const horizon = firmament?.querySelector<HTMLElement>('[data-plane="horizon"]');
    const ctx = canvas?.getContext('2d');
    if (!firmament || !canvas || !horizon || !ctx) return;
    const at = observer();
    if (at.lat < 0)
      firmament
        .querySelectorAll<HTMLElement>('[data-compass]')
        .forEach((li, i) => (li.textContent = COMPASS.north[i] ?? li.textContent));
    const rise = root.querySelector<HTMLElement>('[data-moonrise]');
    if (rise) {
      const when = moonrise(new Date(), at);
      rise.textContent = when
        ? `The Moon rises next at ${when.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}, by the reader's own clock.`
        : 'The Moon does not rise again before this hour tomorrow.';
    }

    const still = reducedMotion();
    const light = deviceTier() === 'light';
    firmament.dataset.tier = light ? 'light' : 'full';
    let stars: Star[] = [];
    let figures: Figure[] = [];
    let placed: Placed[] = [];
    let reckoned = -Infinity;
    let width = 0;
    let height = 0;
    let dpr = 1;

    /** Where every star stands now; the sky turns a degree in four minutes, so once a minute. */
    const reckon = (now: number) => {
      const date = new Date(Date.now());
      placed = stars.map(([ra, dec, mag, k], i) => {
        const h = horizontal(ra, dec, at, date);
        const p = panorama(h, at, SPAN);
        return { alt: h.alt, x: p.x, y: p.y, mag, rgb: tint(k), i };
      });
      reckoned = now;
    };

    const size = () => {
      dpr = Math.min(light ? 1 : 2, devicePixelRatio || 1);
      width = canvas.clientWidth;
      height = canvas.clientHeight;
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
    };

    /** The page's measure of the sky: the root's top, the horizon's depth, the ground's. */
    const frame = () => {
      const r = firmament.getBoundingClientRect();
      const hz = (horizon.querySelector('svg') ?? horizon).getBoundingClientRect();
      const horizonY = hz.top + hz.height * (10 / 24) - r.top;
      return { top: r.top, horizonY, groundDepth: r.height - horizonY };
    };

    /** Where a placed star falls on the canvas, or null if it is off it. */
    const screen = (s: Placed, f: ReturnType<typeof frame>) => {
      if (s.x < -0.02 || s.x > 1.02) return null;
      let y: number;
      if (s.alt >= 0) {
        const lag = still ? 0 : -f.top * STAR_DEPTH * (s.alt / 90);
        y = f.top + s.y * f.horizonY + lag;
      } else {
        if (s.alt < -UNDERGROUND) return null;
        y = f.top + f.horizonY + (-s.alt / UNDERGROUND) * f.groundDepth;
      }
      if (y < -12 || y > height + 12) return null;
      return { x: s.x * width, y };
    };

    let tracing: { fig: Figure; start: number } | null = null;
    let lastTraced = -Infinity;
    const traceMs = () =>
      parseFloat(getComputedStyle(root).getPropertyValue('--descent-trace')) * 1000 || 9000;
    const pickFigure = (now: number) => {
      const visible = figures.filter(
        (f) =>
          f.rank <= TRACE_RANK &&
          f.lines.every((l) =>
            l.every(([ra, dec]) => {
              const h = horizontal(ra, dec, at, new Date());
              const p = panorama(h, at, SPAN);
              return h.alt > TRACE_MIN_ALT && p.x > 0.06 && p.x < 0.94;
            }),
          ),
      );
      const fig = visible[Math.floor(Math.random() * visible.length)];
      tracing = fig ? { fig, start: now } : null;
      firmament.dataset.tracing = fig?.id ?? '';
    };

    let meteorAt: number | null = null;
    let meteor: { x: number; y: number; dx: number; dy: number; start: number } | null = null;
    let meteors = 0;

    const draw = (now: number) => {
      if (!placed.length) return;
      if (now - reckoned > 60_000) reckon(now);
      const f = frame();
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, width, height);
      let shown = 0;
      for (const s of placed) {
        const p = screen(s, f);
        if (!p) continue;
        if (s.alt >= 0) {
          shown++;
          const r = Math.max(0.45, Math.min(3, 2.5 - 0.5 * s.mag));
          let a = Math.max(0.35, Math.min(1, 1.15 - s.mag * 0.16));
          if (!still && !light && s.mag < 2.6)
            a *= 0.82 + 0.18 * Math.sin(now / (380 + (s.i % 7) * 90) + s.i);
          const [cr, cg, cb] = s.rgb;
          ctx.fillStyle = `rgba(${cr},${cg},${cb},${a.toFixed(3)})`;
          ctx.beginPath();
          ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
          ctx.fill();
          if (s.mag < 1.3) {
            // The engraver's star: four fine rays.
            ctx.strokeStyle = `rgba(${cr},${cg},${cb},${(a * 0.6).toFixed(3)})`;
            ctx.lineWidth = 0.6;
            ctx.beginPath();
            ctx.moveTo(p.x - r * 3.4, p.y);
            ctx.lineTo(p.x + r * 3.4, p.y);
            ctx.moveTo(p.x, p.y - r * 3.4);
            ctx.lineTo(p.x, p.y + r * 3.4);
            ctx.stroke();
          }
        } else {
          // Turned under: a fleck of mineral, angular, dimming with depth.
          const depth = -s.alt / UNDERGROUND;
          const [mr, mg, mb] = MINERALS[s.i % MINERALS.length]!;
          const r = Math.max(0.6, Math.min(2.4, 2.2 - 0.4 * s.mag));
          ctx.fillStyle = `rgba(${mr},${mg},${mb},${(0.7 * (1 - depth)).toFixed(3)})`;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y - r);
          ctx.lineTo(p.x + r * 0.8, p.y);
          ctx.lineTo(p.x, p.y + r * 0.7);
          ctx.lineTo(p.x - r * 0.9, p.y);
          ctx.closePath();
          ctx.fill();
        }
      }
      firmament.dataset.stars = String(shown);
      if (still) return;

      // One figure at a time: traced in, held, faded, then a rest before the next.
      const T = traceMs();
      if (!tracing && now - lastTraced > T * 0.25) pickFigure(now);
      if (tracing) {
        const k = (now - tracing.start) / T;
        if (k >= 1) {
          tracing = null;
          lastTraced = now;
          firmament.dataset.tracing = '';
        } else {
          const drawn = Math.min(1, k / 0.4);
          const alpha = k < 0.7 ? 0.5 : 0.5 * (1 - (k - 0.7) / 0.3);
          const segs = tracing.fig.lines.flatMap((l) =>
            l.slice(1).map((b, i) => [l[i]!, b] as const),
          );
          const upto = drawn * segs.length;
          ctx.strokeStyle = `rgba(214,186,120,${alpha.toFixed(3)})`;
          ctx.lineWidth = 0.75;
          ctx.beginPath();
          const date = new Date();
          segs.forEach(([a, b], i) => {
            if (i >= upto) return;
            const pa = placeOf(a, date, f);
            const pb = placeOf(b, date, f);
            if (!pa || !pb) return;
            const part = Math.min(1, upto - i);
            ctx.moveTo(pa.x, pa.y);
            ctx.lineTo(pa.x + (pb.x - pa.x) * part, pa.y + (pb.y - pa.y) * part);
          });
          ctx.stroke();
        }
      }

      // A single meteor, never more than once a minute.
      const wall = Date.now();
      meteorAt ??= nextMeteor(lastMeteor, wall, Math.random());
      if (!meteor && wall >= meteorAt) {
        const dir = Math.random() < 0.5 ? -1 : 1;
        const ang = ((25 + Math.random() * 12) * Math.PI) / 180;
        meteor = {
          x: width * (0.2 + Math.random() * 0.6),
          y: f.top + f.horizonY * (0.1 + Math.random() * 0.35),
          dx: Math.cos(ang) * dir,
          dy: Math.sin(ang),
          start: now,
        };
        lastMeteor = wall;
        meteorAt = nextMeteor(lastMeteor, wall, Math.random());
        firmament.dataset.meteors = String(++meteors);
      }
      if (meteor) {
        const k = (now - meteor.start) / METEOR_FLIGHT;
        if (k >= 1) meteor = null;
        else {
          const head = {
            x: meteor.x + meteor.dx * METEOR_LENGTH * k * 1.6,
            y: meteor.y + meteor.dy * METEOR_LENGTH * k * 1.6,
          };
          const tail = {
            x: head.x - meteor.dx * METEOR_LENGTH * (1 - k * 0.6),
            y: head.y - meteor.dy * METEOR_LENGTH * (1 - k * 0.6),
          };
          const g = ctx.createLinearGradient(tail.x, tail.y, head.x, head.y);
          g.addColorStop(0, 'rgba(255,240,210,0)');
          g.addColorStop(1, `rgba(255,244,222,${(1 - k).toFixed(3)})`);
          ctx.strokeStyle = g;
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.moveTo(tail.x, tail.y);
          ctx.lineTo(head.x, head.y);
          ctx.stroke();
        }
      }
    };

    const placeOf = (
      [ra, dec]: readonly [number, number],
      date: Date,
      f: ReturnType<typeof frame>,
    ) => {
      const h = horizontal(ra, dec, at, date);
      const p = panorama(h, at, SPAN);
      return screen({ alt: h.alt, x: p.x, y: p.y, mag: 9, rgb: [0, 0, 0], i: 0 }, f);
    };

    let alive = true;
    let stopGuard: Teardown | undefined;
    void load().then((c) => {
      if (!alive) return;
      stars = c.stars;
      figures = c.figures;
      size();
      reckon(performance.now());
      stopGuard = whileSeen(
        firmament,
        () => {
          size();
          if (still) {
            // Nothing moves: the sky is redrawn only to keep it in place as the page goes by.
            let queued = 0;
            const redraw = () => {
              cancelAnimationFrame(queued);
              queued = requestAnimationFrame(() => draw(performance.now()));
            };
            redraw();
            const offs = [
              listen(window, 'scroll', redraw),
              listen(window, 'resize', () => (size(), redraw())),
            ];
            return () => {
              cancelAnimationFrame(queued);
              offs.forEach((o) => o());
            };
          }
          const offResize = listen(window, 'resize', size);
          const stop = loop(draw, light ? 30 : 60);
          return () => {
            stop();
            offResize();
          };
        },
        '80px 0px',
      );
    });
    return () => {
      alive = false;
      stopGuard?.();
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      delete firmament.dataset.stars;
      delete firmament.dataset.tracing;
      delete firmament.dataset.meteors;
    };
  },
  { motion: false },
);
