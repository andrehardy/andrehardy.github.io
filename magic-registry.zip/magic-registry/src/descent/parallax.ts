/**
 * The descent's depth (R-DESC-03, R-EARTH-02). Its engraved planes (the Sealed Light's rays,
 * the cloud bank, the strata, the roots) lie at their own depths and slide past one another as
 * the reader goes down; the gilded meridian inks itself in, down the axis, as far as the reader
 * has come. In the Mantle the beds have weight: a fast descent leaves them behind, and they
 * settle after it, the deepest last, with no rebound. The veins catch the light as they pass.
 * All of it is computed on scroll and stops when the page is still.
 */
import { listen, onDescent, type Teardown } from './life';

const clamp = (x: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, x));

/** How far a bed lags the page, per pixel of scroll in a frame; and how fast it settles. */
const LAG = [0.5, 0.42, 0.34, 0.27, 0.2];
const SETTLE = [0.16, 0.13, 0.11, 0.09, 0.075];
const FRAME = 1000 / 60;
const MAX_LAG = 16;

onDescent((root) => {
  const planes = [...root.querySelectorAll<HTMLElement | SVGElement>('[data-plane]')]
    .map((el) => ({ el, depth: parseFloat(getComputedStyle(el).getPropertyValue('--depth')) || 0 }))
    .filter((p) => p.depth !== 0 && p.el.tagName.toLowerCase() !== 'canvas');
  const beds = [...root.querySelectorAll<HTMLElement>('[data-stratum]')];
  const mantle = root.querySelector<HTMLElement>('[data-zone="mantle"]');
  const sheen = root.querySelector<SVGLinearGradientElement>('[data-vein-sheen]');
  const lag = beds.map(() => 0);

  let lastY = scrollY;
  let queued = 0;
  let idle = 0;
  let then = 0;

  const frame = (now: number) => {
    queued = 0;
    // Lag and settling are per sixtieth of a second, whatever the display's own rate.
    const k = then ? clamp((now - then) / FRAME, 0.25, 30) : 1;
    then = now;
    const vh = innerHeight;
    for (const { el, depth } of planes) {
      const zone = (el.parentElement ?? el).getBoundingClientRect();
      if (zone.bottom < -vh || zone.top > 2 * vh) continue;
      const off = (zone.top + zone.height / 2 - vh / 2) * depth;
      el.style.translate = `0 ${off.toFixed(1)}px`;
    }
    const r = root.getBoundingClientRect();
    root.style.setProperty('--inked', clamp((vh * 0.8 - r.top) / r.height, 0, 1).toFixed(4));

    const v = (scrollY - lastY) / k;
    lastY = scrollY;
    let moving = Math.abs(v) > 0.5;
    // Sub-pixel drift (WebKit reports it for a while after a fling) is not a descent.
    const drive = moving ? v : 0;
    beds.forEach((bed, i) => {
      const target = clamp(drive * LAG[i]!, -MAX_LAG, MAX_LAG);
      lag[i]! += (target - lag[i]!) * (1 - (1 - SETTLE[i]!) ** k);
      if (Math.abs(lag[i]!) < 0.05 && Math.abs(target) < 0.05) lag[i] = 0;
      else moving = true;
      bed.style.setProperty('--settle', `${lag[i]!.toFixed(2)}px`);
    });
    if (mantle && sheen) {
      const m = mantle.getBoundingClientRect();
      const k = clamp((vh - m.top) / (m.height + vh), 0, 1);
      sheen.setAttribute('gradientTransform', `translate(${((k - 0.5) * 1400).toFixed(0)} 0)`);
    }
    // Keep going while anything is still moving, then rest until the next scroll.
    if (moving) idle = 0;
    else idle++;
    if (idle < 3) queued = requestAnimationFrame(frame);
    else then = 0;
  };

  const wake = () => {
    idle = 0;
    if (!queued) queued = requestAnimationFrame(frame);
  };
  wake();
  const offs: Teardown[] = [listen(window, 'scroll', wake), listen(window, 'resize', wake)];
  return () => {
    cancelAnimationFrame(queued);
    offs.forEach((o) => o());
    for (const { el } of planes) el.style.translate = '';
    beds.forEach((b) => b.style.removeProperty('--settle'));
    root.style.removeProperty('--inked');
  };
});

/**
 * The Mantle's rewards (R-EARTH-03): a reader who stops in the deep rock and stays a while
 * sees something surface there, a fossil or a seam of ore, one for each such pause, until all
 * four are found. Nothing surfaces for a reader passing through. Finding is not motion, so a
 * reader who has asked for stillness finds them too.
 */
const LINGER = 4000;

onDescent(
  (root) => {
    const strata = root.querySelector<HTMLElement>('[data-strata]');
    if (!strata) return;
    const hidden = () => [...strata.querySelectorAll<SVGElement>('.inclusion:not(.surfaced)')];
    let found = 0;
    let timer = 0;
    let inView = false;
    const arm = () => {
      clearTimeout(timer);
      if (!inView || !hidden().length) return;
      timer = window.setTimeout(() => {
        const left = hidden();
        const pick = left[Math.floor(Math.random() * left.length)];
        if (!pick) return;
        pick.classList.add('surfaced');
        strata.dataset.surfaced = String(++found);
      }, LINGER);
    };
    const io = new IntersectionObserver(
      (entries) => {
        inView = entries.at(-1)?.isIntersecting ?? inView;
        arm();
      },
      { rootMargin: '-35% 0px' },
    );
    io.observe(strata);
    const off = listen(window, 'scroll', arm);
    return () => {
      clearTimeout(timer);
      io.disconnect();
      off();
      strata.querySelectorAll('.surfaced').forEach((el) => el.classList.remove('surfaced'));
      delete strata.dataset.surfaced;
    };
  },
  { motion: false },
);
