/**
 * The firmament's shared measures, read by the engraved planes at build and by the sky at
 * run time, so the compass under the horizon and the stars above it agree.
 */

/** Degrees of azimuth across the page: the half of the sky the reader faces. */
export const SPAN = 180;

/** The points of the compass under the horizon, left to right, facing south and facing north. */
export const COMPASS = {
  south: ['E', 'SE', 'S', 'SW', 'W'],
  north: ['W', 'NW', 'N', 'NE', 'E'],
} as const;

/** How far below the horizon the turned-under sky is drawn, in degrees, before it is lost. */
export const UNDERGROUND = 60;
