import { describe, expect, it } from 'vitest';
import { ARCHETYPE_IDS } from '~/data/palettes';
import { era, ledgerOrder, shown } from '~/lib/ledger';
import { tally } from '~/lib/trials';
import { portrayals } from './registry';

const confirmed = shown(portrayals);

describe('the research (R-RES-01..04)', () => {
  it('files at least four confirmed portrayals under every archetype, each cited', () => {
    for (const id of ARCHETYPE_IDS) {
      const mine = confirmed.filter((p) => p.data.verdict === id);
      expect(mine.length, id).toBeGreaterThanOrEqual(4);
      for (const p of mine) expect(p.data.sources.length, p.id).toBeGreaterThan(0);
    }
  });

  it('spans myth, books, film, television, games and anime, and seeks out the misfiled', () => {
    for (const medium of ['myth', 'book', 'film', 'tv', 'game', 'anime'])
      expect(
        confirmed.some((p) => p.data.medium === medium),
        medium,
      ).toBe(true);
    const misfiled = confirmed.filter((p) => p.data.verdictKind === 'misfiled');
    expect(misfiled.length).toBeGreaterThanOrEqual(6);
    expect(new Set(misfiled.map((p) => p.data.verdict)).size).toBeGreaterThanOrEqual(4);
  });

  it('never shows a proposed portrayal', () => {
    const sample = [
      { id: 'a', data: { status: 'confirmed' } },
      { id: 'b', data: { status: 'proposed' } },
    ];
    expect(shown(sample).map((p) => p.id)).toEqual(['a']);
  });

  it('cites no work twice under one archetype', () => {
    const seen = new Set<string>();
    for (const p of confirmed) {
      const key = `${p.data.verdict}/${p.data.character}/${p.data.work}`;
      expect(seen.has(key), key).toBe(false);
      seen.add(key);
    }
  });
});

describe('the Ledger and the Trials, as read', () => {
  it('writes a year as a reader expects it', () => {
    expect(era(1818)).toBe('1818');
    expect(era(8)).toBe('AD 8');
    expect(era(-700)).toBe('700 BC');
  });

  it('puts the misfiled first, then the anomalies, then the rest', () => {
    const p = (character: string, verdictKind: 'misfiled' | 'anomaly' | 'true-to-label') => ({
      data: { character, verdictKind },
    });
    const sorted = [p('Ann', 'true-to-label'), p('Bo', 'anomaly'), p('Cy', 'misfiled')].sort(
      ledgerOrder,
    );
    expect(sorted.map((x) => x.data.character)).toEqual(['Cy', 'Bo', 'Ann']);
  });

  it('counts a Trial in words, from the task done to the task refused', () => {
    expect(tally(['shattered', 'moved', 'denied', 'moved'])).toBe(
      'Two moved, one shattered, one refused',
    );
  });
});
