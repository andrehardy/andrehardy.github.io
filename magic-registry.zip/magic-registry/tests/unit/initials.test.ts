import { describe, expect, it } from 'vitest';
import {
  CONSTRUCTED,
  constructionCapital,
  firstLetter,
  guideD,
  timing,
} from '../../src/lib/initials';
import { written } from './registry';

describe('construction capitals (R-TYPE-01, R-FLO-WIZ-INI)', () => {
  it("is drawn for the first letter of the Wizard's almanac prose", () => {
    const wizard = written.find((a) => a.id === 'wizard')!;
    expect(wizard.data.identity.initial).toBe('construction-capital');
    const letter = firstLetter(wizard.body);
    expect(CONSTRUCTED).toContain(letter);
    expect(constructionCapital(letter.toLowerCase()).letter).toBe(letter);
  });

  it('refuses a letter that has not been drawn', () => {
    expect(() => constructionCapital('Q')).toThrow(/no construction capital/);
    expect(() => firstLetter('  ... 42')).toThrow();
  });

  it('builds each letter on the square, its circle and its diagonals, and keeps it in the square', () => {
    for (const letter of CONSTRUCTED) {
      const cap = constructionCapital(letter);
      const frame = cap.guides.slice(0, 7).map(guideD);
      expect(frame).toContain('M0 0L100 0');
      expect(frame).toContain('M0 0L100 100');
      expect(cap.guides.some((g) => g.kind === 'circle' && g.at.join() === '50,50,50')).toBe(true);
      const figures = (cap.d.match(/-?\d+(\.\d+)?/g) ?? []).map(Number);
      for (const n of figures) expect(n, letter).toBeGreaterThanOrEqual(0);
      for (const n of figures) expect(n, letter).toBeLessThanOrEqual(100);
    }
  });

  it("the T's stem is a ninth of the height, as the geometers set it", () => {
    const t = constructionCapital('T');
    const stems = t.guides.filter(
      (g) => g.kind === 'line' && g.at[0] === g.at[2] && g.at[0] !== 0 && g.at[0] !== 100,
    );
    expect(stems).toHaveLength(2);
    expect(Math.abs(stems[1]!.at[0]! - stems[0]!.at[0]!)).toBeCloseTo(100 / 9, 9);
  });

  it('is choreographed: the guides draw first, the gold is laid last, then the text may appear', () => {
    for (const letter of CONSTRUCTED) {
      const cap = constructionCapital(letter);
      const t = timing(cap);
      const lastGuideStarts = (cap.guides.length - 1) * t.gap;
      expect(t.gildAt).toBeGreaterThan(lastGuideStarts);
      expect(t.finished).toBeCloseTo(t.gildAt + t.gild, 9);
      expect(t.finished).toBeLessThan(3);
    }
  });

  it('draws a partial arc as one sweep and a whole circle as two', () => {
    expect(guideD({ kind: 'circle', at: [50, 50, 50] }).match(/A/g)).toHaveLength(2);
    expect(guideD({ kind: 'circle', at: [50, 50, 10], span: [0, 90] }).match(/A/g)).toHaveLength(1);
  });
});
