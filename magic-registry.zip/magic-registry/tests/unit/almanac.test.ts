import { describe, expect, it } from 'vitest';
import { SECTIONS, axisReading, roman, withBase } from '~/lib/almanac';

describe('book furniture', () => {
  it('joins paths onto the base with exactly one slash', () => {
    expect(withBase('/magic-registry', '')).toBe('/magic-registry/');
    expect(withBase('/magic-registry/', '/codex/')).toBe('/magic-registry/codex/');
    expect(withBase('/magic-registry', 'archetypes/wizard/')).toBe(
      '/magic-registry/archetypes/wizard/',
    );
  });

  it('sets lower-case roman numerals', () => {
    expect([1, 4, 9, 14, 19, 40, 1999].map(roman)).toEqual([
      'i',
      'iv',
      'ix',
      'xiv',
      'xix',
      'xl',
      'mcmxcix',
    ]);
    expect(() => roman(0)).toThrow();
  });

  it('reads the axis as altitude above the horizon and depth below it', () => {
    expect(axisReading(75)).toBe('Altitude 75');
    expect(axisReading(-90)).toBe('Depth 90');
    expect(axisReading(0)).toBe('On the horizon');
  });

  it('names six sections with unique paths, the Preface first', () => {
    expect(SECTIONS[0]!.id).toBe('preface');
    expect(new Set(SECTIONS.map((s) => s.path)).size).toBe(SECTIONS.length);
  });
});
