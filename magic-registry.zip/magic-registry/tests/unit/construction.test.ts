import { describe, expect, it } from 'vitest';
import { Construction, dist, intersections, lies, type Figure } from '../../src/lib/construction';
import { SIGILS, placer, wizardConstruction } from '../../src/lib/sigils';
import {
  CENTRE,
  FOCUS,
  NUDGE_LIMIT,
  along,
  nudgeFrom,
  nudged,
  threads,
} from '../../src/folios/wizard/ephemeris';

describe('compass and straightedge (R-PH4-01)', () => {
  it('a construction is given exactly two points, before anything is drawn', () => {
    const k = new Construction().given('O', [0, 0]).given('A', [1, 0]);
    expect(() => k.given('Z', [2, 0])).toThrow();
    const drawn = new Construction().given('O', [0, 0]);
    drawn.given('A', [1, 0]).circle('c', 'O', 'A', 'cut');
    expect(() => drawn.given('Z', [3, 3])).toThrow();
  });

  it('a figure needs known points, and a point exists only where two figures meet', () => {
    const k = new Construction().given('O', [0, 0]).given('A', [1, 0]);
    expect(() => k.line('l', 'O', 'X', 'guide')).toThrow(/not yet known/);
    expect(() => k.meet('X', 'nothing', 'else', [0, 0])).toThrow(/drawn first/);
    k.circle('c', 'O', 'A', 'cut').line('far', 'A', 'O', 'guide');
    expect(() => k.circle('c', 'A', 'O', 'cut')).toThrow(/twice/);
  });

  it('two figures that do not meet give no point', () => {
    const k = new Construction()
      .given('O', [0, 0])
      .given('A', [1, 0])
      .line('l', 'O', 'A', 'guide')
      .circle('unit', 'O', 'A', 'cut')
      .meet('B', 'l', 'unit', [-1, 0])
      .circle('about-b', 'B', 'A', 'guide')
      .meet('C', 'l', 'about-b', [-3, 0])
      .circle('about-a', 'A', 'O', 'cut')
      .circle('about-c', 'C', 'B', 'cut');
    expect(k.points.get('C')![0]).toBeCloseTo(-3, 12);
    expect(intersections(k.figures.get('about-a')!, k.figures.get('about-c')!, k.points)).toEqual(
      [],
    );
    expect(() => k.meet('X', 'about-a', 'about-c', [0, 0])).toThrow(/do not meet/);
  });
});

describe("the Wizard's sigil is a true construction", () => {
  const k = wizardConstruction();

  it('replays move by move: every figure uses only points already known, every point is a meeting', () => {
    const known = new Set<string>();
    let given = 0;
    for (const m of k.moves) {
      if (m.kind === 'given') {
        expect(++given).toBeLessThanOrEqual(2);
        known.add(m.point);
      } else if (m.kind === 'figure') {
        const f = m.figure;
        const needs = f.kind === 'line' ? f.through : [f.centre, f.through];
        for (const n of needs) expect(known.has(n), `${f.id} needs ${n}`).toBe(true);
      } else if (m.kind === 'meet') {
        const [f, g] = m.of.map((id) => k.figures.get(id)!) as [Figure, Figure];
        expect(lies(m.at, f, k.points), `${m.point} on ${f.id}`).toBe(true);
        expect(lies(m.at, g, k.points), `${m.point} on ${g.id}`).toBe(true);
        const found = intersections(f, g, k.points);
        expect(
          found.some((p) => dist(p, m.at) < 1e-9),
          m.point,
        ).toBe(true);
        known.add(m.point);
      } else {
        expect(known.has(m.point), `prick ${m.point}`).toBe(true);
      }
    }
    expect(given).toBe(2);
  });

  it('finds the six points of the circle and the true hexagram', () => {
    const six = ['A', 'P1', 'P2', 'B', 'P3', 'P4'].map((n) => k.points.get(n)!);
    for (const p of six) expect(Math.hypot(p[0], p[1])).toBeCloseTo(1, 12);
    const angles = six
      .map((p) => (Math.atan2(p[1], p[0]) * 180) / Math.PI)
      .map((a) => (a + 360) % 360);
    expect(angles.sort((a, b) => a - b).map((a) => Math.round(a))).toEqual([
      0, 60, 120, 180, 240, 300,
    ]);
    // The inner orbit through the triangles' crossing is the inscribed circle of a hexagram.
    expect(Math.hypot(...k.points.get('Q')!)).toBeCloseTo(1 / Math.sqrt(3), 12);
    expect(Math.hypot(...k.points.get('M')!)).toBeCloseTo(0.5, 12);
  });

  it('draws in order: guides and cuts interleave as built, and it ends by pricking its focus', () => {
    const marks = k.marks;
    expect(marks.length).toBe(k.figures.size + 2);
    expect(marks.at(-1)).toEqual({ kind: 'prick', point: SIGILS.wizard!.focus });
    expect(marks.filter((m) => m.kind !== 'prick' && m.role === 'cut').length).toBe(9);
  });
});

describe('the threads converge on the focus (R-ID-WIZ-04)', () => {
  const spec = SIGILS.wizard!;
  const focus = placer(spec, CENTRE[0], CENTRE[1], 150)(spec.build().points.get(spec.focus)!);

  it('the focus is the last point of the sigil, upright on the plate', () => {
    expect(FOCUS[0]).toBeCloseTo(focus[0], 9);
    expect(FOCUS[1]).toBeCloseTo(focus[1], 9);
  });

  it('every thread, nudged or not, ends exactly at the focus and starts at the sky edge', () => {
    const ts = threads();
    expect(ts).toHaveLength(8);
    for (const t of ts) {
      const nudges: [number, number][] = [
        [0, 0],
        [NUDGE_LIMIT, -NUDGE_LIMIT],
      ];
      for (const n of nudges) {
        const end = along(nudged(t, n), 1);
        expect(dist(end, FOCUS)).toBeLessThan(1e-9);
        expect(dist(along(nudged(t, n), 0), t.from)).toBeLessThan(1e-9);
      }
      expect(dist(t.from, CENTRE)).toBeGreaterThan(250);
    }
  });

  it('a hand pushes a thread away from itself, by the limit and no more', () => {
    for (const t of threads()) {
      const mid = along(t, 0.5);
      const hand: [number, number] = [mid[0] + 6, mid[1] + 6];
      const n = nudgeFrom(t, hand, CENTRE);
      expect(Math.hypot(...n)).toBeCloseTo(NUDGE_LIMIT, 9);
      const moved = along(nudged(t, n), 0.5);
      expect(dist(moved, hand)).toBeGreaterThan(dist(mid, hand));
    }
  });

  it('a hand right on a thread pushes it outward, away from the centre', () => {
    const t = threads()[0]!;
    const on = along(t, 0.4);
    const n = nudgeFrom(t, on, CENTRE);
    const out = [on[0] - CENTRE[0], on[1] - CENTRE[1]];
    expect(n[0] * out[0]! + n[1] * out[1]!).toBeGreaterThan(0);
  });
});
