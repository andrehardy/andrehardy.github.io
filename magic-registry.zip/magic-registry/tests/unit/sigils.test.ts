import { describe, expect, it } from 'vitest';
import { DRAWINGS, type DrawMark } from '../../src/lib/drawings';
import {
  BARD_PLATE,
  chladni,
  NECRO_FOLD,
  NECRO_VERTEBRAE,
  WARLOCK_CHAIN_R,
  WARLOCK_LINK_HALF,
  WARLOCK_LINKS,
  WITCH_LEAVES,
} from '../../src/lib/drawings/mantle';
import { CLERIC_FOLD, DRUID_SEEDS, GOLDEN_ANGLE, SHAMAN_RINGS } from '../../src/lib/drawings/sky';
import {
  metalAt,
  SORCERER_MAX_SWERVE,
  SORCERER_REACH,
  WORK_ORDER,
} from '../../src/lib/drawings/threshold';
import type { Pt } from '../../src/lib/ink';

const draw = (id: keyof typeof DRAWINGS) => DRAWINGS[id]!();
const pts = (m: DrawMark): Pt[] => (m.kind === 'dot' ? [m.at] : m.pts);
const near = (a: Pt, b: Pt, tol = 0.006) => Math.hypot(a[0] - b[0], a[1] - b[1]) < tol;

/** Whether some other mark of the drawing covers every point of `moved` (same kind). */
function covered(marks: DrawMark[], kind: DrawMark['kind'], moved: Pt[]): boolean {
  return marks.some((n) => n.kind === kind && moved.every((p) => pts(n).some((q) => near(p, q))));
}

const rot = ([x, y]: Pt, deg: number): Pt => {
  const a = (deg * Math.PI) / 180;
  return [x * Math.cos(a) - y * Math.sin(a), x * Math.sin(a) + y * Math.cos(a)];
};

describe('every drawn sigil is set out on its own field', () => {
  for (const id of Object.keys(DRAWINGS) as (keyof typeof DRAWINGS)[])
    it(`${id}: marks stay near the unit field, ids are unique, and it has a focus`, () => {
      const d = draw(id);
      expect(d.marks.length).toBeGreaterThan(5);
      expect(new Set(d.marks.map((m) => m.id)).size).toBe(d.marks.length);
      for (const m of d.marks)
        for (const [x, y] of pts(m)) expect(Math.hypot(x, y)).toBeLessThan(1.2);
      expect(d.focus).toHaveLength(2);
    });
});

describe("the Cleric's sigil is radial: the same at every twelfth of a turn (R-ID-CLE-03)", () => {
  it('every cut and every point is repeated a twelfth of a turn on', () => {
    const { marks } = draw('cleric');
    for (const m of marks.filter((x) => x.kind === 'dot' || x.role === 'cut'))
      expect(
        covered(
          marks,
          m.kind,
          pts(m).map((p) => rot(p, 360 / CLERIC_FOLD)),
        ),
        m.id,
      ).toBe(true);
  });
});

describe("the Paladin's sigil is heraldic: mirrored across the pale, straight-edged (R-ID-PAL-03)", () => {
  it('every mark has its twin across the pale', () => {
    const { marks } = draw('paladin');
    for (const m of marks)
      expect(
        covered(
          marks,
          m.kind,
          pts(m).map(([x, y]) => [-x, y] as Pt),
        ),
        m.id,
      ).toBe(true);
  });

  it('the ordinaries are straight lines with at most one bend; only the shield is curved', () => {
    const { marks } = draw('paladin');
    const ordinaries = marks.filter(
      (m) => m.kind === 'stroke' && m.role === 'cut' && !['shield', 'bordure'].includes(m.id),
    );
    expect(ordinaries.length).toBeGreaterThanOrEqual(3);
    for (const m of ordinaries) {
      const p = pts(m);
      let bends = 0;
      for (let i = 1; i < p.length - 1; i++) {
        const a = Math.atan2(p[i]![1] - p[i - 1]![1], p[i]![0] - p[i - 1]![0]);
        const b = Math.atan2(p[i + 1]![1] - p[i]![1], p[i + 1]![0] - p[i]![0]);
        if (Math.abs(a - b) > 1e-6) bends++;
      }
      expect(bends, m.id).toBeLessThanOrEqual(1);
    }
  });
});

describe("the Shaman's sigil is entoptic forms inside concentric drum rings (R-ID-SHA-03)", () => {
  const { marks } = draw('shaman');
  const byId = (id: string) => marks.find((m) => m.id === id)!;

  it('the rings share one centre', () => {
    SHAMAN_RINGS.forEach((r, i) => {
      for (const [x, y] of pts(byId(`ring-${i}`))) expect(Math.hypot(x, y)).toBeCloseTo(r, 6);
    });
  });

  it('the zigzag swings between two radii, point by point', () => {
    const radii = pts(byId('zigzag')).map(([x, y]) => +Math.hypot(x, y).toFixed(6));
    radii.forEach((r, i) => expect(r).toBeCloseTo(i % 2 ? 0.85 : 0.65, 6));
  });

  it('the spiral only ever widens', () => {
    const radii = pts(byId('spiral')).map(([x, y]) => Math.hypot(x, y));
    for (let i = 1; i < radii.length; i++) expect(radii[i]!).toBeGreaterThan(radii[i - 1]!);
  });

  it('carries a field of dots', () => {
    expect(marks.filter((m) => m.kind === 'dot').length).toBeGreaterThan(30);
  });
});

describe("the Druid's sigil is set at the golden angle (R-ID-DRU-03)", () => {
  const seeds = draw('druid').marks.filter((m) => m.id.startsWith('seed-'));

  it(`sets ${DRUID_SEEDS} seeds, each turned by the golden angle from the last`, () => {
    expect(seeds).toHaveLength(DRUID_SEEDS);
    expect(GOLDEN_ANGLE).toBeCloseTo(137.5078, 3);
    for (let i = 1; i < seeds.length; i++) {
      const [x0, y0] = pts(seeds[i - 1]!)[0]!;
      const [x1, y1] = pts(seeds[i]!)[0]!;
      const turn = (((Math.atan2(y1, x1) - Math.atan2(y0, x0)) * 180) / Math.PI + 720) % 360;
      expect(turn).toBeCloseTo(GOLDEN_ANGLE, 6);
    }
  });

  it('each seed sits further out as the square root of its count', () => {
    seeds.forEach((s, i) => {
      const [x, y] = pts(s)[0]!;
      const [x1, y1] = pts(seeds[0]!)[0]!;
      expect(Math.hypot(x, y) / Math.hypot(x1, y1)).toBeCloseTo(Math.sqrt(i + 1), 6);
    });
  });
});

const cuts = (marks: DrawMark[]) =>
  marks.filter(
    (m): m is Extract<DrawMark, { kind: 'stroke' }> => m.kind === 'stroke' && m.role === 'cut',
  );
const flipX = (p: Pt[]): Pt[] => p.map(([x, y]) => [-x, y] as Pt);
/** How far a stroke strays from the straight line between its ends. */
const bow = (p: Pt[]) => {
  const [a, b] = [p[0]!, p.at(-1)!];
  const len = Math.hypot(b[0] - a[0], b[1] - a[1]);
  if (len < 1e-9) return Math.max(...p.map(([x, y]) => Math.hypot(x - a[0], y - a[1])));
  return Math.max(
    ...p.map(([x, y]) => Math.abs((b[0] - a[0]) * (a[1] - y) - (a[0] - x) * (b[1] - a[1])) / len),
  );
};

describe("the Witch's sigil is a pressed specimen: drawn root first, and never symmetric (R-ID-WIT-03)", () => {
  const { marks } = draw('witch');
  it('roots, then the stem, then the leaves, the flower and the berry', () => {
    const first = (pre: string) => marks.findIndex((m) => m.id.startsWith(pre));
    expect(first('root-')).toBeLessThan(first('stem'));
    expect(first('stem')).toBeLessThan(first('leaf-'));
    expect(first('leaf-')).toBeLessThan(first('bell'));
    expect(first('bell')).toBeLessThan(first('berry'));
  });

  it('the leaves alternate up the stem, and no two are the same size', () => {
    const stem = marks.find((m) => m.id === 'stem')!;
    const sp = pts(stem);
    const sizes: number[] = [];
    const sides: number[] = [];
    WITCH_LEAVES.forEach((_, i) => {
      const leaf = pts(marks.find((m) => m.id === `leaf-${i}`)!);
      const base = leaf[0]!;
      const tip = leaf[Math.floor(leaf.length / 2)]!;
      const k = sp.reduce(
        (best, q, j) =>
          Math.hypot(q[0] - base[0], q[1] - base[1]) <
          Math.hypot(sp[best]![0] - base[0], sp[best]![1] - base[1])
            ? j
            : best,
        0,
      );
      const t = sp[Math.min(k + 1, sp.length - 1)]!;
      const s = sp[Math.max(k - 1, 0)]!;
      const side = Math.sign(
        (t[0] - s[0]) * (tip[1] - base[1]) - (t[1] - s[1]) * (tip[0] - base[0]),
      );
      sides.push(side);
      sizes.push(+Math.hypot(tip[0] - base[0], tip[1] - base[1]).toFixed(4));
    });
    sides.forEach((s, i) => expect(s, `leaf ${i}`).toBe(i % 2 === 0 ? sides[0] : -sides[0]!));
    expect(Math.abs(sides[0]!)).toBe(1);
    expect(new Set(sizes).size).toBe(WITCH_LEAVES.length);
  });

  it('almost nothing in it is answered across the middle', () => {
    const c = cuts(marks);
    const mirrored = c.filter((m) => covered(marks, 'stroke', flipX(m.pts)));
    expect(mirrored.length / c.length).toBeLessThan(0.1);
  });
});

describe("the Enchantress's sigil is mirrored curves, with no straight line in it (R-ID-ENC-03)", () => {
  const { marks } = draw('enchantress');
  it('every mark has its reflection across the middle', () => {
    for (const m of marks.filter((x) => x.kind === 'dot' || x.role === 'cut'))
      expect(covered(marks, m.kind, flipX(pts(m))), m.id).toBe(true);
  });

  it('every cut is curved', () => {
    for (const m of cuts(marks)) expect(bow(m.pts), m.id).toBeGreaterThan(0.03);
  });
});

describe("the Warlock's sigil is a seal bound by a closed chain of alternating links (R-ID-WAR-03)", () => {
  const { marks } = draw('warlock');
  const links = marks.filter((m) => m.id.startsWith('link-')).map(pts);
  const width = (p: Pt[]) => {
    const r = p.map(([x, y]) => Math.hypot(x, y));
    return Math.max(...r) - Math.min(...r);
  };

  it(`has ${WARLOCK_LINKS} links, an even number, so flat and edge alternate all the way round`, () => {
    expect(links).toHaveLength(WARLOCK_LINKS);
    expect(WARLOCK_LINKS % 2).toBe(0);
    links.forEach((l, i) => {
      const next = links[(i + 1) % links.length]!;
      if (i % 2 === 0) expect(width(l)).toBeGreaterThan(width(next) * 2);
      else expect(width(next)).toBeGreaterThan(width(l) * 2);
    });
  });

  it('each link passes through its neighbours, the last through the first', () => {
    const chord = 2 * WARLOCK_CHAIN_R * Math.sin(Math.PI / WARLOCK_LINKS);
    expect(2 * WARLOCK_LINK_HALF).toBeGreaterThan(chord);
    links.forEach((l, i) => {
      const next = links[(i + 1) % links.length]!;
      const reach = Math.min(
        ...l.flatMap((p) => next.map((q) => Math.hypot(p[0] - q[0], p[1] - q[1]))),
      );
      expect(reach, `link ${i}`).toBeLessThan(0.01);
    });
  });

  it('every link is a closed loop', () => {
    for (const l of links) {
      const [a, b] = [l[0]!, l.at(-1)!];
      expect(Math.hypot(a[0] - b[0], a[1] - b[1])).toBeLessThan(1e-6);
    }
  });
});

describe("the Necromancer's sigil is an ossuary rosette (R-ID-NEC-03)", () => {
  const { marks } = draw('necromancer');
  it(`the bones and vertebrae are the same at every ${NECRO_FOLD}th of a turn`, () => {
    for (const m of marks.filter((x) => /^(bone|vertebra)-/.test(x.id)))
      expect(
        covered(
          marks,
          m.kind,
          pts(m).map((p) => rot(p, 360 / NECRO_FOLD)),
        ),
        m.id,
      ).toBe(true);
  });

  it('every bone has its knuckles at both ends', () => {
    for (let k = 0; k < NECRO_FOLD; k++) {
      const shaft = pts(marks.find((m) => m.id === `bone-${k}-shaft-0`)!);
      const knuckles = marks.filter((m) => m.id.startsWith(`bone-${k}-knuckle-`)).map(pts);
      expect(knuckles).toHaveLength(4);
      for (const end of [shaft[0]!, shaft.at(-1)!])
        expect(
          knuckles.filter((kn) => kn.some((p) => Math.hypot(p[0] - end[0], p[1] - end[1]) < 0.05))
            .length,
        ).toBeGreaterThanOrEqual(1);
    }
  });

  it(`the skull is drawn first, and ${NECRO_VERTEBRAE} vertebrae ring the rosette`, () => {
    const firstCut = marks.findIndex((m) => m.kind === 'stroke' && m.role === 'cut');
    expect(marks[firstCut]!.id).toMatch(/^skull-/);
    expect(marks.filter((m) => /^vertebra-\d+$/.test(m.id))).toHaveLength(NECRO_VERTEBRAE);
  });
});

describe("the Bard's sigil is the nodal figure of a struck plate (R-ID-BAR-03)", () => {
  const { marks } = draw('bard');
  const nodes = marks.filter((m) => m.id.startsWith('node-'));

  it('every point of every nodal line lies where the plate is still', () => {
    expect(nodes.length).toBeGreaterThanOrEqual(6);
    for (const m of nodes)
      for (const p of pts(m)) expect(Math.abs(chladni(p)), m.id).toBeLessThan(0.06);
  });

  it('the lines stay on the plate, and are drawn from the clamp outward', () => {
    const mean = (p: Pt[]) => p.reduce((t, [x, y]) => t + Math.hypot(x, y), 0) / p.length;
    const order = nodes.map((m) => mean(pts(m)));
    for (let i = 1; i < order.length; i++) expect(order[i]!).toBeGreaterThanOrEqual(order[i - 1]!);
    for (const m of nodes)
      for (const [x, y] of pts(m))
        expect(Math.max(Math.abs(x), Math.abs(y))).toBeLessThanOrEqual(BARD_PLATE);
  });

  it('carries a stave of five lines', () => {
    expect(marks.filter((m) => m.id.startsWith('stave-'))).toHaveLength(5);
  });
});

describe("the Sorcerer's sigil is a Lichtenberg figure, grown outward from the wound (R-ID-SOR-03)", () => {
  const { marks } = draw('sorcerer');
  const bolts = marks.filter((m) => m.id.startsWith('bolt-'));

  it('is the same scar every time', () => {
    expect(JSON.stringify(draw('sorcerer'))).toBe(JSON.stringify(draw('sorcerer')));
  });

  it('branches: every bolt but the arms leaves from a point on a bolt drawn before it', () => {
    expect(bolts.filter((b) => b.id.includes('.')).length).toBeGreaterThan(10);
    bolts.forEach((b, i) => {
      if (!b.id.includes('.')) return;
      const start = pts(b)[0]!;
      const parents = bolts.slice(0, i).flatMap(pts);
      expect(
        parents.some((q) => near(q, start, 1e-9)),
        b.id,
      ).toBe(true);
    });
  });

  it('every step runs further out, never more than its swerve from straight out, and stops at its reach', () => {
    for (const b of bolts) {
      const p = pts(b);
      for (let i = 1; i < p.length; i++) {
        const [x0, y0] = p[i - 1]!;
        const [x1, y1] = p[i]!;
        expect(Math.hypot(x1, y1), b.id).toBeGreaterThan(Math.hypot(x0, y0));
        expect(Math.hypot(x1, y1)).toBeLessThanOrEqual(SORCERER_REACH);
        const out = Math.atan2(y0, x0);
        const step = Math.atan2(y1 - y0, x1 - x0);
        const off = Math.abs(((((step - out) * 180) / Math.PI + 540) % 360) - 180);
        expect(off).toBeLessThanOrEqual(SORCERER_MAX_SWERVE + 1e-6);
      }
    }
  });
});

describe("the Alchemist's sigil is an apparatus set in the seven metals, lead to gold (R-ID-ALC-03)", () => {
  const { marks, focus } = draw('alchemist');
  it('draws the apparatus first, then the metals in the order of the Work', () => {
    const firstMetal = marks.findIndex((m) => m.id.startsWith('metal-'));
    expect(marks.slice(0, firstMetal).map((m) => m.id)).toEqual(
      expect.arrayContaining(['furnace', 'cucurbit', 'still-head', 'beak', 'receiver']),
    );
    const seen = [...new Set(marks.slice(firstMetal).map((m) => m.id.split('-')[1]))];
    expect(seen).toEqual([...WORK_ORDER]);
    expect(near(focus, metalAt(WORK_ORDER.indexOf('sol')))).toBe(true);
  });

  it('each metal stands evenly round the ring, a seventh of a turn apart', () => {
    WORK_ORDER.forEach((metal, i) => {
      const all = marks.filter((m) => m.id.startsWith(`metal-${metal}-`)).flatMap(pts);
      const cx = all.reduce((t, p) => t + p[0], 0) / all.length;
      const cy = all.reduce((t, p) => t + p[1], 0) / all.length;
      const [ex, ey] = metalAt(i);
      expect(Math.hypot(cx - ex, cy - ey), metal).toBeLessThan(0.06);
    });
  });

  it('the beak leaves the still-head and ends in the receiver', () => {
    const beak = pts(marks.find((m) => m.id === 'beak')!);
    const head = pts(marks.find((m) => m.id === 'still-head')!);
    const recv = pts(marks.find((m) => m.id === 'receiver')!);
    expect(near(beak[0]!, head.at(-1)!, 1e-9)).toBe(true);
    const rc = recv.reduce<Pt>(
      (t, p) => [t[0] + p[0] / recv.length, t[1] + p[1] / recv.length],
      [0, 0],
    );
    const end = beak.at(-1)!;
    expect(Math.hypot(end[0] - rc[0], end[1] - rc[1])).toBeLessThan(0.2);
  });
});
