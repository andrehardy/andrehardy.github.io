import { describe, expect, it } from 'vitest';
import { deckle, line, penOutline, pressure, seeded } from '~/lib/ink';

describe('ink', () => {
  it('is deterministic for a given seed', () => {
    const a = seeded(42);
    const b = seeded(42);
    expect([a(), a(), a()]).toEqual([b(), b(), b()]);
  });

  it('tapers in, holds body, and pools where the nib lifts', () => {
    const o = { taperIn: 0.12, taperOut: 0.16, pool: 0.3, tremor: 0 };
    const start = pressure(0.01, o, 0);
    const middle = pressure(0.5, o, 0);
    const nearEnd = pressure(0.9, o, 0);
    const end = pressure(1, o, 0);
    expect(start).toBeLessThan(middle);
    expect(nearEnd).toBeLessThan(middle);
    expect(end).toBeGreaterThan(nearEnd);
  });

  it('produces a closed outline for a stroke', () => {
    const d = penOutline(line([0, 0], [100, 0], 20), { width: 6, seed: 3 });
    expect(d.startsWith('M')).toBe(true);
    expect(d.endsWith('Z')).toBe(true);
  });

  it('cuts a deckled edge as a CSS polygon', () => {
    expect(deckle(7)).toMatch(/^polygon\(/);
  });
});
