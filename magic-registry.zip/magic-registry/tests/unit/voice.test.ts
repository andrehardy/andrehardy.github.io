import { describe, expect, it } from 'vitest';
import {
  ALLOWED_EXAMPLES,
  BANNED_EXAMPLES,
  COMPUTING,
  coinages,
  lint,
  words,
  type Layer,
} from './voice-lint';
import { access, archetypes, beings, glossary, portrayals, realms, trials } from './registry';

/** Fields that hold ids, design data or citations rather than reader-facing prose. */
const SKIP = new Set([
  'identity',
  'sources',
  'sigil',
  'stage',
  'status',
  'realm',
  'access',
  'beings',
  'verdict',
  'verdictKind',
  'rank',
  'medium',
  'resultKind',
  'archetype',
  'axisNote',
  'palette',
  'names',
]);

interface Passage {
  where: string;
  layer: Layer;
  text: string;
}

/** Every reader-facing string, labelled with the voice it is written in. */
function passages(): Passage[] {
  const out: Passage[] = [];
  const walk = (v: unknown, where: string, layer: Layer) => {
    if (typeof v === 'string') out.push({ where, layer, text: v });
    else if (Array.isArray(v)) v.forEach((x, i) => walk(x, `${where}[${i}]`, layer));
    else if (v && typeof v === 'object')
      for (const [k, x] of Object.entries(v)) {
        if (SKIP.has(k)) continue;
        const next: Layer = /^cipher/.test(k) ? 'cipher' : /^almanac/.test(k) ? 'almanac' : layer;
        walk(x, `${where}.${k}`, next);
      }
  };
  for (const [name, entries] of Object.entries({
    realms,
    beings,
    access,
    glossary,
    archetypes,
    portrayals,
    trials,
  })) {
    for (const e of entries) {
      walk(e.data, `${name}/${e.id}`, 'shared');
      if (e.body) out.push({ where: `${name}/${e.id} (body)`, layer: 'almanac', text: e.body });
    }
  }
  return out;
}

/**
 * Capitalized words the cipher may use: glossary terms, registry names, and proper names taken
 * only from name fields (never from prose, so prose cannot license its own coinages).
 */
function allowedNames(): Set<string> {
  const myth = ['Merlin', 'Morgan', 'Fay', 'Camelot', 'Arthur'];
  return new Set([
    ...glossary.flatMap((g) => words(g.data.term, g.data.cipherTerm)),
    ...realms.flatMap((r) => words(r.data.almanacName, r.data.cipherName)),
    ...beings.flatMap((b) => words(b.data.almanacName, b.data.cipherName)),
    ...access.flatMap((a) => words(a.data.almanacName, a.data.cipherName)),
    ...archetypes.flatMap((a) => words(a.data.name, ...a.data.aliases)),
    ...portrayals.flatMap((p) =>
      words(
        p.data.character,
        p.data.work,
        p.data.creator,
        p.data.canonLabel,
        ...p.data.names,
        ...p.data.sources.flatMap((s) => [s.title, s.by]),
      ),
    ),
    ...myth,
    'Registry',
  ]);
}

/** Shared plain-fact fields are shown in cipher mode too, so they are held to the cipher rule. */
const coinageChecked = (p: Passage) =>
  p.layer === 'cipher' || /\.(evidence\[\d+\]|result)$/.test(p.where);

describe('the voice lint itself', () => {
  it('catches computing vocabulary, scaffolding and the second person in any voice', () => {
    expect(lint('The staff is an antenna for the API.', 'almanac')).not.toEqual([]);
    expect(lint('A EULA signed below.', 'cipher')).not.toEqual([]);
    expect(lint('Her mind is a router.', 'shared')).not.toEqual([]);
    expect(lint('Here is the answer.', 'cipher')).not.toEqual([]);
    expect(lint('Your staff is a lens.', 'almanac')).not.toEqual([]);
    expect(lint('We file him as a Wizard.', 'almanac')).not.toEqual([]);
    expect(lint('The Wizard reckons the hour.', 'almanac')).toEqual([]);
  });

  it('every banned pattern fires on its example, and plain English stays legal', () => {
    for (const re of COMPUTING)
      expect(
        BANNED_EXAMPLES.some((e) => re.test(e)),
        String(re),
      ).toBe(true);
    for (const e of BANNED_EXAMPLES) expect(lint(e, 'cipher'), e).not.toEqual([]);
    for (const e of ALLOWED_EXAMPLES) expect(lint(e, 'almanac'), e).toEqual([]);
  });

  it('title words and prose never become allowed names', () => {
    expect(words('The Magicians, season 1')).toEqual(['Magicians']);
    const allowed = allowedNames();
    for (const w of ['In', 'The', 'Admission', 'Errors', 'Spells', 'He'])
      expect(allowed.has(w), w).toBe(false);
  });

  it('keeps tier numbering out of the almanac but allows it in the cipher', () => {
    expect(lint('The First Tier governs probability.', 'almanac')).not.toEqual([]);
    expect(lint('The First Tier governs probability.', 'cipher')).toEqual([]);
  });

  it('flags a cipher coinage that is not a glossary term or a known name', () => {
    const allowed = new Set(['First', 'Tier', 'Wizard']);
    expect(coinages('The Wizard reads the First Tier.', allowed)).toEqual([]);
    expect(coinages('The Wizard pings the Orbital Array.', allowed)).toEqual(['Orbital', 'Array']);
    expect(coinages('Limits: Wizards tire. (Wizards rest.)', allowed)).toEqual([]);
  });
});

describe('reader-facing text keeps the registry voice', () => {
  const all = passages();

  it('finds text in both voices to check', () => {
    expect(all.filter((p) => p.layer === 'almanac').length).toBeGreaterThan(40);
    expect(all.filter((p) => p.layer === 'cipher').length).toBeGreaterThan(40);
  });

  it('stores every passage as clean running text: paragraph breaks only, no stray breaks or spaces', () => {
    const failures = all
      .filter((p) => !p.where.endsWith('(body)'))
      .filter((p) => p.text.split('\n\n').some((par) => /\n|^\s|\s$| {2}/.test(par)))
      .map((p) => p.where);
    expect(failures).toEqual([]);
  });

  it('a numbered plate or clause is not a speaker, but a speaker is still caught', () => {
    expect(lint('Plate I: The Rosette\nI\nOf the Parties', 'almanac')).toEqual([]);
    expect(lint('I think the Registry errs', 'almanac')).not.toEqual([]);
    expect(lint("I'm sure of it", 'almanac')).not.toEqual([]);
    expect(lint('I\u2019m sure of it', 'almanac')).not.toEqual([]);
    expect(lint('in my own view', 'almanac')).not.toEqual([]);
  });

  it('no computing vocabulary, chat scaffolding or second person; tiers only in the cipher', () => {
    const failures = all.flatMap((p) => lint(p.text, p.layer).map((f) => `${p.where}: ${f}`));
    expect(failures).toEqual([]);
  });

  it('every allowed name is cited in its own portrayal and is itself clean', () => {
    const failures: string[] = [];
    for (const p of portrayals) {
      const own = all
        .filter((x) => x.where.startsWith(`portrayals/${p.id}.`))
        .map((x) => x.text)
        .join('\n');
      for (const n of p.data.names) {
        if (!own.includes(n)) failures.push(`${p.id}: "${n}" is not in its text`);
        for (const f of lint(n, 'cipher')) failures.push(`${p.id}: "${n}" ${f}`);
      }
    }
    expect(failures).toEqual([]);
  });

  it('the cipher, and the plain facts shown with it, coin no terms of their own', () => {
    const allowed = allowedNames();
    const checked = all.filter(coinageChecked);
    expect(checked.some((p) => p.where.includes('.evidence['))).toBe(true);
    const failures = checked.flatMap((p) =>
      coinages(p.text, allowed).map((w) => `${p.where}: ${w}`),
    );
    expect(failures).toEqual([]);
  });
});
