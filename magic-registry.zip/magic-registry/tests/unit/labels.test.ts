import { describe, expect, it } from 'vitest';
import { filedElsewhere, labelsOf, namedBy } from '../../src/lib/labels';
import { archetypes, portrayals } from './registry';

const labels = labelsOf(archetypes);
const ids = (label: string) => namedBy(label, labels).map((l) => l.id);

describe('reading what a work calls its practitioner', () => {
  it('knows every archetype by its name, its aliases and its gendered forms', () => {
    expect(ids('the Siren of the rocks')).toEqual(['enchantress']);
    expect(ids('a Priest of the old rite')).toEqual(['cleric']);
    expect(ids('the Sorceress')).toEqual(['sorcerer']);
    expect(ids('an Enchanter')).toEqual(['enchantress']);
  });

  it("reads a reclassified hero's label: Strange is called a sorcerer", () => {
    const strange = portrayals.find((p) => p.id === 'stephen-strange')!;
    expect(ids(strange.data.canonLabel)).toEqual(['sorcerer']);
  });

  it('does not find a name inside another word', () => {
    expect(ids('Witchfinder General')).toEqual([]);
    expect(ids('Wizardry and Sorcery')).toEqual([]);
  });
});

describe('portrayals filed elsewhere (the "misfiled out" list on a folio)', () => {
  const p = (id: string, canonLabel: string, verdict: string, year: number) => ({
    id,
    data: { canonLabel, verdict, year },
  });
  const sample = [
    p('boy-wizard', 'the boy wizard', 'sorcerer', 1997),
    p('hedge-wizard', 'a hedge wizard', 'wizard', 1990),
    p('elder', 'the Wizard of the West', 'warlock', 1954),
    p('unnamed', 'Magician', 'sorcerer', 2001),
  ];

  it('lists those a work calls by the name but the Registry files elsewhere, oldest first', () => {
    expect(filedElsewhere(sample, 'wizard', labels).map((x) => x.id)).toEqual([
      'elder',
      'boy-wizard',
    ]);
  });

  it('never lists a portrayal filed here, nor one whose label names no archetype', () => {
    const out = filedElsewhere(sample, 'wizard', labels).map((x) => x.id);
    expect(out).not.toContain('hedge-wizard');
    expect(out).not.toContain('unnamed');
  });

  it('on the real registry, Doctor Strange appears under the Sorcerer as filed elsewhere', () => {
    expect(filedElsewhere(portrayals, 'sorcerer', labels).map((x) => x.id)).toContain(
      'stephen-strange',
    );
    expect(filedElsewhere(portrayals, 'wizard', labels).map((x) => x.id)).not.toContain(
      'stephen-strange',
    );
  });
});
