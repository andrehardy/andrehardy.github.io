import { describe, expect, it } from 'vitest';
import { existsSync } from 'node:fs';
import { listReleaseFiles } from '../../scripts/project-files.mjs';
import { CURRENT_PHASE } from '../phase';

/** Files the plan requires, keyed by the phase that introduces them. */
const REQUIRED: Record<number, string[]> = {
  0: [
    'README.md',
    '.gitignore',
    'package.json',
    'astro.config.mjs',
    'tsconfig.json',
    '.github/workflows/deploy.yml',
    'scripts/verify.mjs',
    'scripts/leak-test.mjs',
    'scripts/make-zip.mjs',
    'scripts/lighthouse.mjs',
  ],
  1: [
    'src/styles/tokens.css',
    'src/styles/type.css',
    'src/styles/textures.css',
    'src/styles/motion.css',
    'src/styles/global.css',
    'src/data/palettes.ts',
    'src/lib/color.ts',
    'src/lib/ink.ts',
    'src/components/Theme.astro',
    'src/components/PaperDefs.astro',
    'src/components/InkStroke.astro',
    'src/fonts/eb-garamond-regular.woff2',
    'src/fonts/eb-garamond-italic.woff2',
    'src/fonts/eb-garamond-medium.woff2',
    'src/fonts/EB-Garamond-OFL.txt',
    'src/dev/specimen.astro',
    'tests/e2e/design-system.spec.ts',
  ],
  2: [
    'src/content.config.ts',
    'src/data/schemas.ts',
    'src/content/archetypes/wizard.md',
    'tests/unit/schemas.test.ts',
    'tests/unit/integrity.test.ts',
    'tests/unit/identity.test.ts',
    'tests/unit/voice.test.ts',
  ],
  3: [
    'src/layouts/Almanac.astro',
    'src/layouts/Folio.astro',
    'src/components/Masthead.astro',
    'src/components/MoonRoundel.astro',
    'src/components/CipherToggle.astro',
    'src/components/Layered.astro',
    'src/components/PlaceholderPlate.astro',
    'src/lib/astronomy.ts',
    'src/lib/almanac.ts',
    'src/lib/folios.ts',
    'src/pages/404.astro',
    'src/pages/archetypes/[slug].astro',
    'src/pages/codex.astro',
    'src/pages/ledger.astro',
    'src/pages/bestiary.astro',
    'src/pages/preface.astro',
    'src/pages/trials/index.astro',
    'src/pages/trials/[slug].astro',
    'tests/unit/astronomy.test.ts',
    'tests/e2e/routes.spec.ts',
    'tests/e2e/cipher.spec.ts',
    'tests/e2e/keyboard.spec.ts',
    'tests/e2e/links.spec.ts',
    'tests/e2e/moon.spec.ts',
    'tests/e2e/voice.spec.ts',
  ],
  4: [
    'src/components/Sigil.astro',
    'src/components/Plate.astro',
    'src/components/RealmMark.astro',
    'src/components/VerdictSeal.astro',
    'src/components/PortrayalCard.astro',
    'src/components/TrialRow.astro',
    'src/components/Marginalia.astro',
    'src/components/Initial.astro',
    'src/components/CipherLens.astro',
    'src/lib/construction.ts',
    'src/lib/sigils.ts',
    'src/lib/initials.ts',
    'src/lib/reckoning.ts',
    'src/lib/folio-data.ts',
    'src/lib/labels.ts',
    'src/lib/seal.ts',
    'src/lib/on-view.ts',
    'src/folios/index.ts',
    'src/folios/WizardFolio.astro',
    'src/folios/wizard/Ephemeris.astro',
    'src/folios/wizard/ephemeris.ts',
    'src/folios/wizard/thread.ts',
    'src/folios/wizard/glide.ts',
    'src/folios/wizard/ephemeris-client.ts',
    'src/folios/wizard/compass.ts',
    'src/styles/archetypes/wizard.css',
    'tests/unit/construction.test.ts',
    'tests/unit/glide.test.ts',
    'tests/unit/reckoning.test.ts',
    'tests/unit/folios.test.ts',
    'tests/unit/initials.test.ts',
    'tests/unit/labels.test.ts',
    'tests/e2e/folio.spec.ts',
    'tests/e2e/lens.spec.ts',
    'tests/e2e/transition.spec.ts',
    'tests/e2e/visual.spec.ts',
  ],
};

describe('project structure', () => {
  for (const [phase, files] of Object.entries(REQUIRED)) {
    if (Number(phase) > CURRENT_PHASE) continue;
    it(`has every file required by phase ${phase}`, () => {
      const missing = files.filter((f) => !existsSync(f));
      expect(missing).toEqual([]);
    });
  }
});

describe('release zip contents', () => {
  it('includes the source and excludes rebuilt, private and machine-local files', async () => {
    const files = await listReleaseFiles();
    expect(files).toContain('package.json');
    expect(files).toContain('src/pages/index.astro');
    expect(files).toContain('.github/workflows/deploy.yml');
    const forbidden = files.filter(
      (f) =>
        /(^|\/)(node_modules|dist|\.proof|\.astro|\.git|test-results|playwright-report|\.lighthouseci)\//.test(
          f,
        ) || /(^|\/)(\.env(\..*)?|Thumbs\.db|\.DS_Store|magic-registry\.zip)$/.test(f),
    );
    expect(forbidden).toEqual([]);
  });
});
