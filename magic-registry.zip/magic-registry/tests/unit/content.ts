/**
 * Reads the content collections straight from src/content, the same files Astro's loaders read,
 * so the unit tests can check them without the Astro runtime.
 */
import { readFileSync, readdirSync } from 'node:fs';
import { basename, extname, join } from 'node:path';
import { parse } from 'yaml';

export interface Entry {
  id: string;
  file: string;
  data: unknown;
  /** Markdown body (archetypes only). */
  body: string;
}

const root = 'src/content';

export function readCollection(name: string): Entry[] {
  const dir = join(root, name);
  return readdirSync(dir)
    .filter((f) => ['.yaml', '.md'].includes(extname(f)))
    .sort()
    .map((f) => {
      const file = join(dir, f);
      const raw = readFileSync(file, 'utf8');
      const id = basename(f, extname(f));
      if (extname(f) === '.md') {
        const m = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/);
        if (!m) throw new Error(`${file}: no frontmatter`);
        return { id, file, data: parse(m[1]!) as unknown, body: m[2]!.trim() };
      }
      return { id, file, data: parse(raw) as unknown, body: '' };
    });
}

export const COLLECTIONS = [
  'realms',
  'beings',
  'access',
  'glossary',
  'archetypes',
  'portrayals',
  'trials',
] as const;
