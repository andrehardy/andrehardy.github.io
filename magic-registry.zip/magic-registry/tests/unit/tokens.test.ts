import { describe, expect, it } from 'vitest';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';
import {
  ARCHETYPE_IDS,
  ARCHETYPE_PALETTES,
  ARCHETYPE_PHYSICS,
  ARCHETYPE_REALM,
  GILT,
  INK,
  giltFloor,
  giltFor,
  REALM_IDS,
  REALM_PALETTES,
  REALM_PHYSICS,
  isLight,
  type Palette,
} from '~/data/palettes';
import { contrast, deltaE, toLab } from '~/lib/color';

const allPalettes: [string, Palette][] = [
  ...Object.entries(REALM_PALETTES),
  ...Object.entries(ARCHETYPE_PALETTES),
];

describe('palette tokens', () => {
  it('covers every realm and all twelve archetypes', () => {
    expect(Object.keys(REALM_PALETTES).sort()).toEqual([...REALM_IDS].sort());
    expect(Object.keys(ARCHETYPE_PALETTES).sort()).toEqual([...ARCHETYPE_IDS].sort());
    expect(Object.keys(ARCHETYPE_REALM).sort()).toEqual([...ARCHETYPE_IDS].sort());
    expect(Object.keys(ARCHETYPE_PHYSICS).sort()).toEqual([...ARCHETYPE_IDS].sort());
    expect(Object.keys(REALM_PHYSICS).sort()).toEqual([...REALM_IDS].sort());
  });

  for (const [id, p] of allPalettes) {
    it(`${id}: body, secondary and rubricated text meet WCAG on ground and well`, () => {
      for (const bg of [p.ground, p.well]) {
        expect(contrast(p.ink, bg)).toBeGreaterThanOrEqual(7);
        expect(contrast(p.inkSoft, bg)).toBeGreaterThanOrEqual(4.5);
        expect(contrast(p.rubric, bg)).toBeGreaterThanOrEqual(4.5);
      }
    });
    it(`${id}: both accents are legible as ornament and display type on ground and well`, () => {
      for (const bg of [p.ground, p.well]) {
        expect(contrast(p.accent, bg)).toBeGreaterThanOrEqual(3);
        expect(contrast(p.accent2, bg)).toBeGreaterThanOrEqual(3);
      }
    });
  }

  it('gives every archetype a clearly different ground-and-accent pairing', () => {
    const ids = [...ARCHETYPE_IDS];
    const tooClose: string[] = [];
    for (let i = 0; i < ids.length; i++) {
      for (let j = i + 1; j < ids.length; j++) {
        const a = ARCHETYPE_PALETTES[ids[i]];
        const b = ARCHETYPE_PALETTES[ids[j]];
        const accent = deltaE(a.accent, b.accent);
        const ground = deltaE(a.ground, b.ground);
        // Two folios may share a ground family only if their accents are far apart, and vice versa.
        if (accent < 20 || accent + ground < 35) {
          tooClose.push(
            `${ids[i]}/${ids[j]} accent=${accent.toFixed(1)} ground=${ground.toFixed(1)}`,
          );
        }
      }
    }
    expect(tooClose).toEqual([]);
  });

  it('rubricated terms stand apart from ornament: rubric and accent are different reds', () => {
    const close = allPalettes
      .map(([id, p]) => [id, deltaE(p.rubric, p.accent)] as const)
      .filter(([, d]) => d < 15)
      .map(([id, d]) => `${id} ${d.toFixed(1)}`);
    expect(close).toEqual([]);
  });

  it('never gives two archetypes on the same kind of ground near-identical grounds', () => {
    const ids = [...ARCHETYPE_IDS];
    const twins: string[] = [];
    for (let i = 0; i < ids.length; i++) {
      for (let j = i + 1; j < ids.length; j++) {
        const d = deltaE(ARCHETYPE_PALETTES[ids[i]].ground, ARCHETYPE_PALETTES[ids[j]].ground);
        if (d < 3) twins.push(`${ids[i]}/${ids[j]} ground=${d.toFixed(1)}`);
      }
    }
    expect(twins).toEqual([]);
  });
});

describe('gold leaf', () => {
  const aureate = new Set(['sealed', 'cleric']);

  it('every scope gets a gold that keeps 3:1 on its ground and well, with and without the sheen', () => {
    const failures: string[] = [];
    for (const [id, p] of allPalettes) {
      const bgs = [p.ground, p.well, ...(aureate.has(id) ? [p.glow] : [])];
      const floor = giltFloor(giltFor(p), bgs);
      if (floor < 3) failures.push(`${id}: ${floor.toFixed(2)}`);
    }
    expect(failures).toEqual([]);
  });

  it('the vellum leaf keeps 3:1 on vellum, in the aureate light too', () => {
    const vellum = allPalettes
      .filter(([id]) => aureate.has(id))
      .flatMap(([, p]) => [p.ground, p.glow]);
    expect(giltFloor(GILT.light, vellum)).toBeGreaterThanOrEqual(3);
  });

  it('gold on light paper stays gold, never brown: bright enough, and saturated', () => {
    // On vellum the leaf may not be darker than it needs to be (an upper contrast guard).
    for (const stop of GILT.light.stops) {
      expect(contrast(stop, REALM_PALETTES.sealed.ground)).toBeLessThanOrEqual(5);
      expect(toLab(stop)[0], `${stop} lightness`).toBeGreaterThanOrEqual(44);
    }
    // A scope deepens its gold only as far as its own ground and well demand: an old gold on
    // bone or slate, but always a gold (strongly yellow), never a brown. Lightness alone cannot
    // tell old gold from brown, so the deepening is capped against the vellum leaf, and the
    // hue and chroma of every stop must stay those of the vellum leaf.
    const hue = (a: number, b: number) => (Math.atan2(b, a) * 180) / Math.PI;
    for (const [id, p] of allPalettes) {
      const stops = giltFor(p).stops;
      for (const [i, stop] of stops.entries()) {
        const [L, a, b] = toLab(stop);
        expect(L, `${id} ${stop} lightness`).toBeGreaterThanOrEqual(isLight(p.ground) ? 30 : 60);
        expect(b, `${id} ${stop} yellowness`).toBeGreaterThanOrEqual(40);
        expect(Math.hypot(a, b), `${id} ${stop} chroma`).toBeGreaterThanOrEqual(42);
        if (!isLight(p.ground)) continue;
        const [L0, a0, b0] = toLab(GILT.light.stops[i]!);
        // The vellum leaf sits at L* 44 or above; 14 deeper meets the 30 floor, below which
        // gold reads as bronze whatever its hue.
        expect(L0 - L, `${id} ${stop} deepened`).toBeLessThanOrEqual(14);
        expect(Math.abs(hue(a, b) - hue(a0, b0)), `${id} ${stop} hue drift`).toBeLessThanOrEqual(4);
      }
    }
  });

  it('dark grounds take the bright leaf', () => {
    for (const [id, p] of allPalettes) {
      if (!isLight(p.ground)) expect(giltFor(p), id).toBe(GILT.dark);
    }
    expect(
      giltFloor(
        GILT.dark,
        allPalettes.filter(([, p]) => !isLight(p.ground)).flatMap(([, p]) => [p.ground, p.well]),
      ),
    ).toBeGreaterThanOrEqual(3);
  });

  it('has no fixed bright band: the sheen is the only specular', () => {
    for (const kind of ['light', 'dark'] as const) {
      const L = GILT[kind].stops.map((s) => toLab(s)[0]);
      expect(Math.max(...L) - Math.min(...L)).toBeLessThan(10);
    }
  });
});

describe('ink by physics', () => {
  it('the Mantle inks heavier and bleeds further than the Vault', () => {
    expect(parseFloat(INK.mantle.weight)).toBeGreaterThan(parseFloat(INK.vault.weight));
    expect(parseFloat(INK.mantle.swell)).toBeGreaterThan(parseFloat(INK.vault.swell));
    expect(INK.mantle.bleed).toContain('heavy');
  });

  it('every Mantle archetype carries Mantle physics', () => {
    for (const id of ARCHETYPE_IDS) {
      if (ARCHETYPE_REALM[id] === 'mantle') expect(ARCHETYPE_PHYSICS[id]).toBe('mantle');
      if (ARCHETYPE_REALM[id] === 'vault' || ARCHETYPE_REALM[id] === 'sealed')
        expect(ARCHETYPE_PHYSICS[id]).toBe('vault');
    }
  });
});

describe('motion tokens', () => {
  const css = readFileSync('src/styles/motion.css', 'utf8');
  const durations = (name: string) =>
    [...css.matchAll(new RegExp(`--${name}-[a-z-]*duration[a-z-]*:\\s*([\\d.]+)(ms|s)`, 'g'))].map(
      ([, v, unit]) => (unit === 'ms' ? Number(v) / 1000 : Number(v)),
    );
  const curves = (name: string) =>
    Object.fromEntries(
      [
        ...css.matchAll(new RegExp(`--(${name}-ease[a-z-]*):\\s*cubic-bezier\\(([^)]+)\\)`, 'g')),
      ].map(([, token, args]) => [token, args.split(',').map(Number)]),
    ) as Record<string, number[]>;
  /** Speed on arrival, relative to the average: 0 means it eases to a stop. */
  const endSlope = ([, , x2, y2]: number[]) => (1 - y2) / (1 - x2);

  it('Vault motion is celestial: long, between 1.2 and 3 seconds', () => {
    const d = durations('vault');
    expect(d.length).toBeGreaterThan(0);
    for (const s of d) {
      expect(s).toBeGreaterThanOrEqual(1.2);
      expect(s).toBeLessThanOrEqual(3);
    }
  });

  it('Vault motion never lands hard: every Vault curve arrives at zero speed', () => {
    const c = curves('vault');
    expect(Object.keys(c).length).toBeGreaterThan(0);
    for (const [token, args] of Object.entries(c)) expect(endSlope(args), token).toBe(0);
  });

  it('Mantle motion is geological: short travel (under 1.2 seconds)', () => {
    const d = durations('mantle');
    expect(d.length).toBeGreaterThan(0);
    for (const s of d) expect(s).toBeLessThan(1.2);
  });

  it('Mantle motion lands firmly: the landing curve arrives still moving', () => {
    const land = curves('mantle')['mantle-ease-land'];
    expect(land).toBeDefined();
    expect(endSlope(land)).toBeGreaterThanOrEqual(2);
    // Keyframes must spell the curves out (browsers ignore var() there); they must match the tokens.
    const literal = (token: string) => `cubic-bezier(${curves('mantle')[token].join(', ')})`;
    const settle = /@keyframes settle\s*\{([\s\S]*?)\n\}/.exec(css)?.[1] ?? '';
    const first = /0%\s*\{([^}]*)\}/.exec(settle)?.[1] ?? '';
    expect(first).toContain(`animation-timing-function: ${literal('mantle-ease-land')}`);
    expect(settle).toContain(`animation-timing-function: ${literal('mantle-ease-impact')}`);
  });

  it('ambient light keeps its own tokens, apart from either physics', () => {
    expect(css).toMatch(/--ambient-breath:/);
    expect(css).toMatch(/--ambient-ease:/);
  });

  it('reduced motion collapses every animation and transition, and every motion fills both', () => {
    const block = /@media \(prefers-reduced-motion: reduce\)\s*\{([\s\S]*?)\n\}/.exec(css)?.[1];
    expect(block).toBeDefined();
    expect(block).toMatch(/animation-duration:\s*0\.001ms !important/);
    expect(block).toMatch(/transition-duration:\s*0\.001ms !important/);
    expect(block).toMatch(/animation-iteration-count:\s*1 !important/);
    const fill = /([^{}]+)\{\s*animation-fill-mode:\s*both;/.exec(css)?.[1] ?? '';
    for (const cls of ['.ink-draw', '.settle', '.rise', '[data-anim]']) expect(fill).toContain(cls);
  });

  it('no stylesheet or component sets a raw duration: every timing comes from a token', () => {
    const files: string[] = [];
    const walk = (dir: string) => {
      for (const n of readdirSync(dir)) {
        const f = join(dir, n);
        if (statSync(f).isDirectory()) walk(f);
        else if (/\.(css|astro)$/.test(n)) files.push(f);
      }
    };
    walk('src');
    const offenders: string[] = [];
    for (const f of files) {
      const text = readFileSync(f, 'utf8');
      for (const m of text.matchAll(
        /(?:^|[;{\s])(animation|transition|animation-duration|transition-duration|animation-delay|transition-delay)\s*:([^;}]+)/g,
      )) {
        if (/\b\d*\.?\d+m?s\b/.test(m[2].replace(/var\([^)]*\)/g, ''))) {
          if (f.endsWith('motion.css') && m[2].includes('0.001ms !important')) continue;
          if (f.endsWith('motion.css') && /0s !important/.test(m[2])) continue;
          offenders.push(`${f}: ${m[0].trim()}`);
        }
      }
    }
    expect(offenders).toEqual([]);
  });
});

describe('typography tokens', () => {
  const css = readFileSync('src/styles/type.css', 'utf8');

  it('self-hosts every face and never calls a font CDN', () => {
    for (const face of [
      'cormorant-garamond',
      'im-fell-english',
      'im-fell-english-sc',
      'cinzel',
      'unifrakturmaguntia',
    ]) {
      expect(css).toContain(`@fontsource/${face}/`);
    }
    for (const file of ['eb-garamond-regular', 'eb-garamond-italic', 'eb-garamond-medium']) {
      expect(css).toContain(`url('../fonts/${file}.woff2')`);
    }
    expect(css).not.toMatch(/fonts\.(googleapis|gstatic)\.com/);
  });

  it('asks for book features (that they render is proven in e2e/design-system.spec.ts)', () => {
    expect(css).toMatch(/'onum' 1/);
    expect(css).toMatch(/'dlig' 1/);
    expect(css).toMatch(/IM Fell English SC/);
  });
});
