import { describe, expect, it } from 'vitest';
import { ARCHETYPE_PALETTES, type ArchetypeId, type Palette } from '../../src/data/palettes';
import { deltaE } from '../../src/lib/color';
import { archetypes } from './registry';

const FIELDS = [
  'material',
  'geometry',
  'motion',
  'layout',
  'interaction',
  'typeAccent',
  'entrance',
  'cursor',
  'initial',
  'sound',
] as const;

describe('twelve distinct identities', () => {
  for (const field of FIELDS) {
    it(`no two archetypes share a ${field}`, () => {
      const seen = new Map<string, string>();
      const clashes: string[] = [];
      for (const a of archetypes) {
        const v = a.data.identity[field].toLowerCase();
        if (seen.has(v)) clashes.push(`${seen.get(v)} and ${a.id}: ${v}`);
        seen.set(v, a.id);
      }
      expect(clashes).toEqual([]);
    });
  }

  it('the identity palette is the design-token palette, by name', () => {
    for (const a of archetypes)
      expect(a.data.identity.palette, a.id).toEqual(ARCHETYPE_PALETTES[a.id as ArchetypeId].names);
  });

  it('each palette carries the colors the plan names for it', () => {
    const plan: Record<ArchetypeId, string[]> = {
      wizard: ['midnight indigo', 'brass', 'chalk'],
      witch: ['oxblood', 'belladonna violet', 'soot', 'bone'],
      shaman: ['hide', 'ochre', 'smoke', 'cyan'],
      sorcerer: ['white-hot core', 'ember', 'arterial red', 'char'],
      enchantress: ['pearl', 'rose-gold', 'sea-glass', 'abyssal blue-black'],
      warlock: ['iron grey', 'sulfur', 'signet crimson'],
      druid: ['moss', 'lichen', 'bark', 'spore-gold'],
      necromancer: ['bone ivory', 'tarnish', 'cold verdigris', 'black'],
      cleric: ['white', 'aureate gold', 'lapis'],
      paladin: ['argent', 'azure', 'gules'],
      alchemist: ['verdigris', 'copper', 'mercury', 'sulfur'],
      bard: ['walnut', 'crimson', 'gilt'],
    };
    for (const a of archetypes) {
      const names = a.data.identity.palette.join(' | ');
      for (const color of plan[a.id as ArchetypeId]) expect(names, a.id).toContain(color);
    }
  });

  it('palettes sit a minimum color distance apart', () => {
    // Mean distance from each signature color to the nearest in the other palette, both ways.
    // 12 is about five just-noticeable differences averaged over a whole palette.
    const sig = (p: Palette) => [p.ground, p.well, p.accent, p.accent2, p.rubric];
    const near = (a: string[], b: string[]) =>
      a.reduce((s, x) => s + Math.min(...b.map((y) => deltaE(x, y))), 0) / a.length;
    const close: string[] = [];
    const ids = archetypes.map((a) => a.id as ArchetypeId);
    for (let i = 0; i < ids.length; i++)
      for (let j = i + 1; j < ids.length; j++) {
        const a = sig(ARCHETYPE_PALETTES[ids[i]!]);
        const b = sig(ARCHETYPE_PALETTES[ids[j]!]);
        const d = (near(a, b) + near(b, a)) / 2;
        if (d < 12) close.push(`${ids[i]}/${ids[j]} ${d.toFixed(1)}`);
      }
    expect(close).toEqual([]);
  });
});
