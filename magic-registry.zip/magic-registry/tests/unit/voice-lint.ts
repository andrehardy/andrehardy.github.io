/**
 * Voice lint for reader-facing text (R-VOICE-07, R-VOICE-09, R-PROC-07, D-17).
 * The almanac and the cipher are both plain natural philosophy: no computing vocabulary,
 * no chat scaffolding, no "you". Tier numbering belongs to the cipher alone, and in the cipher a
 * capitalized coinage must be a known term or name.
 */
export type Layer = 'almanac' | 'cipher' | 'shared';

export const COMPUTING = [
  /\bapis?\b/i,
  /\beulas?\b/i,
  /\brouters?\b/i,
  /\bdefrag/i,
  /\busb\b/i,
  /\bmonte carlo\b/i,
  /\bman[- ]in[- ]the[- ]middle\b/i,
  /\bfirmware\b/i,
  /\bsoftware\b/i,
  /\bhardware\b/i,
  /\bmainframes?\b/i,
  /\bservers?\b/i,
  /\b(down|up)load/i,
  /\bsandbox/i,
  /\b(sys)?admin(s)?\b/i,
  /sysadmin/i,
  /\broot access\b/i,
  /\bbandwidth\b/i,
  /\bbackdoors?\b/i,
  /\bfirewalls?\b/i,
  /\btelemetry\b/i,
  /\balgorithm/i,
  /\boperating systems?\b/i,
  /\bchassis\b/i,
  /\bcyber/i,
  /\bhack(s|ed|er|ers|ing)?\b/i,
  /\bexploit/i,
  /\bglitch/i,
  /\bdata\b/i,
  /\bcompute\b/i,
  /\bwi-?fi\b/i,
  /\blan\b/i,
  /\bprotocols?\b/i,
  /\bdrones?\b/i,
  /\buplink/i,
  /\bspoof/i,
  /\bmalware\b/i,
  /\bsource code\b/i,
  /\breboot/i,
  /\bsyntax\b/i,
  /\bcomputers?\b/i,
  /\bdigital\b/i,
  /\bonline\b/i,
  /\bupgrade/i,
  /\bterabytes?\b/i,
  /\bpixels?\b/i,
  /\bping(s|ed|ing)?\b/i,
  // "code" alone is left free for a code of honour; the computing senses are phrases.
  /\b(machine|binary|computer) code\b/i,
  /\bcoding\b/i,
  /\bcommand lines?\b/i,
  // "a patch of moss" is plain English; the verb is the computing sense.
  /\bpatch(ed|ing)\b/i,
  /\bprox(y|ies)\b/i,
  /\bwetware\b/i,
  /\bendpoints?\b/i,
  /\binstall(s|ed|ing|ation|ations)?\b/i,
  /\bbackups?\b/i,
  /\bsafe mode\b/i,
  /\bencrypt/i,
  /\b(anti)?virus(es)?\b/i,
  // "the crash of thunder" is plain English; the verbs are the computing sense.
  /\bcrash(ed|es|ing)\b/i,
  /\bsimulations?\b/i,
  /\bprocessing power\b/i,
  /\bbiometric/i,
  /\binterfac(e|es|ed|ing)\b/i,
  /\bparameters?\b/i,
  /\bend[- ]?users?\b/i,
  /\btoggles?\b/i,
];

const SCAFFOLD = [
  /\bgreat question\b/i,
  /\byou(?:'|\u2019)re right\b/i,
  /\bhere is\b/i,
  /\bhere(?:'|\u2019)s\b/i,
  /\blet(?:'|\u2019)s\b/i,
  /\bas an ai\b/i,
  /\bred pill\b/i,
  /\bbrilliant\b/i,
  /\babsolutely\b/i,
  /\bI(?:['\u2019][a-z]|\s+[a-z])/,
  /\b(me|my|myself)\b/i,
  /\b(we|our|ours|us)\b/i,
];

const SECOND_PERSON = /\b(you|your|yours|yourself|yourselves)\b/i;

const ALMANAC_ONLY = [/\btiers?\b/i, /\bnetworks?\b/i, /\bdna\b/i];

/** One example per banned pattern, so each pattern is shown to fire (tests/unit/voice.test.ts). */
export const BANNED_EXAMPLES = [
  'an API',
  'the EULA',
  'a router',
  'a defrag',
  'USB ports',
  'a Monte Carlo run',
  'a man-in-the-middle',
  'firmware',
  'software',
  'hardware',
  'the mainframe',
  'a server',
  'downloads',
  'the sandbox',
  'the SysAdmin',
  'an admin',
  'root access',
  'bandwidth',
  'a backdoor',
  'the firewall',
  'telemetry',
  'an algorithm',
  'the operating system',
  'a chassis',
  'cyberspace',
  'hacking',
  'an exploit',
  'a glitch',
  'the data',
  'to compute',
  'wifi',
  'a LAN',
  'a protocol',
  'a drone',
  'an uplink',
  'spoofing',
  'malware',
  'source code',
  'a reboot',
  'syntax',
  'a computer',
  'digital',
  'online',
  'an upgrade',
  'terabytes',
  'pixels',
  'pinged',
  'machine code',
  'coding',
  'command lines',
  'patched',
  'a proxy',
  'wetware',
  'an endpoint',
  'installed',
  'a backup',
  'safe mode',
  'encrypted',
  'a virus',
  'crashed',
  'a simulation',
  'processing power',
  'biometrics',
  'the interface',
  'a parameter',
  'the end-user',
  'a toggle',
];

/** Plain English that shares a word with the banned list and must stay legal. */
export const ALLOWED_EXAMPLES = [
  'a patch of moss',
  'a code of honour',
  'the crash of thunder',
  'she administers the dose',
];

export function lint(text: string, layer: Layer): string[] {
  const found: string[] = [];
  const check = (re: RegExp, why: string) => {
    const m = text.match(re);
    if (m) found.push(`${why}: "${m[0]}"`);
  };
  for (const re of COMPUTING) check(re, 'computing vocabulary');
  for (const re of SCAFFOLD) check(re, 'chat scaffolding');
  check(SECOND_PERSON, 'second person');
  if (layer !== 'cipher') for (const re of ALMANAC_ONLY) check(re, 'cipher-only term');
  return found;
}

/**
 * Capitalized words in the middle of a sentence that are not on the allowed list.
 * A word counts as allowed in the singular or with a plural or possessive ending.
 */
export function coinages(text: string, allowed: Set<string>): string[] {
  const out: string[] = [];
  for (const m of text.matchAll(/[A-Z][A-Za-z\u2019'-]*/g)) {
    // Opening quotes or brackets do not change whether a sentence is starting.
    const before = text
      .slice(0, m.index)
      .replace(/[("'\u2018\u201c]+$/, '')
      .trimEnd();
    if (before === '' || /[.!?:]["'\u2019\u201d)]?$/.test(before)) continue;
    const word = m[0].replace(/(['\u2019]s|s)$/, '');
    if (!allowed.has(m[0]) && !allowed.has(word)) out.push(m[0]);
  }
  return out;
}

/** Function words that are capitalized only inside titles, never names in their own right. */
const TITLE_WORDS = new Set(['The', 'A', 'An', 'Of', 'In', 'And', 'For', 'To', 'On', 'At', 'By']);

/** Splits proper names and terms into the capitalized words they contribute. */
export function words(...phrases: string[]): string[] {
  return phrases
    .flatMap((p) => p.match(/[A-Z][A-Za-z\u2019'-]*/g) ?? [])
    .filter((w) => !TITLE_WORDS.has(w));
}
