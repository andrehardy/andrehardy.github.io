import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import {
  ACCESS_IDS,
  ARCHETYPE_IDS,
  BEING_IDS,
  GLOSSARY_IDS,
  REALM_IDS,
  accessSchema,
  archetypeSchema,
  beingSchema,
  creatureSchema,
  glossarySchema,
  portrayalSchema,
  realmSchema,
  sentence,
  trialSchema,
} from '../../src/data/schemas';
import { REALM_PALETTES } from '../../src/data/palettes';
import { readCollection } from './content';

const SCHEMAS = {
  realms: realmSchema,
  beings: beingSchema,
  access: accessSchema,
  glossary: glossarySchema,
  archetypes: archetypeSchema,
  portrayals: portrayalSchema,
  trials: trialSchema,
} as const;

describe('every content file parses against its schema', () => {
  for (const [name, schema] of Object.entries(SCHEMAS)) {
    it(name, () => {
      const failures = readCollection(name).flatMap((e) => {
        const r = schema.safeParse(e.data);
        return r.success
          ? []
          : [
              `${e.file}: ${r.error.issues.map((i) => `${i.path.join('.')} ${i.message}`).join('; ')}`,
            ];
      });
      expect(failures).toEqual([]);
    });
  }
});

describe('collections hold exactly the planned entries', () => {
  const ids = (name: string) => readCollection(name).map((e) => e.id);
  it('realms', () => expect(ids('realms')).toEqual([...REALM_IDS].sort()));
  it('beings', () => expect(ids('beings')).toEqual([...BEING_IDS].sort()));
  it('access methods, the plan nine plus the three of D-03', () => {
    expect(ids('access')).toEqual([...ACCESS_IDS].sort());
    for (const planned of [
      'study',
      'ingestion',
      'cultivation',
      'bloodline',
      'covenant',
      'artifice',
      'resonance',
      'broadcast',
      'warding',
    ])
      expect(ACCESS_IDS).toContain(planned);
  });
  it('glossary', () => expect(ids('glossary')).toEqual([...GLOSSARY_IDS].sort()));
  it('archetypes: twelve, one definitive entry each', () =>
    expect(ids('archetypes')).toEqual([...ARCHETYPE_IDS].sort()));
  it('trials start with the glass and the seated stranger', () => {
    expect(ids('trials')).toContain('glass');
    expect(ids('trials')).toContain('seated-stranger');
  });
  it('realm palettes are the design tokens, by name', () => {
    for (const e of readCollection('realms')) {
      const realm = realmSchema.parse(e.data);
      expect(realm.palette, e.id).toEqual(
        REALM_PALETTES[e.id as keyof typeof REALM_PALETTES].names,
      );
    }
  });
});

describe('the schemas reject what the plan forbids', () => {
  const portrayal = () =>
    structuredClone(readCollection('portrayals')[0]!.data) as Record<string, unknown>;
  const wizard = () =>
    structuredClone(readCollection('archetypes').find((e) => e.id === 'wizard')!.data) as Record<
      string,
      unknown
    >;
  const trial = () => structuredClone(readCollection('trials')[0]!.data) as Record<string, unknown>;

  it('a valid fixture passes, so the rejections below are meaningful', () => {
    expect(portrayalSchema.safeParse(portrayal()).success).toBe(true);
    expect(archetypeSchema.safeParse(wizard()).success).toBe(true);
    expect(trialSchema.safeParse(trial()).success).toBe(true);
  });

  it.each([
    ['medium', 'podcast'],
    ['verdictKind', 'mislabelled'],
    ['rank', 'champion'],
    ['status', 'published'],
    ['verdict', 'archmage'],
  ])('portrayal %s = %s', (field, value) => {
    expect(portrayalSchema.safeParse({ ...portrayal(), [field]: value }).success).toBe(false);
  });

  it('a portrayal needs evidence and a source', () => {
    expect(portrayalSchema.safeParse({ ...portrayal(), evidence: ['one'] }).success).toBe(false);
    expect(portrayalSchema.safeParse({ ...portrayal(), sources: [] }).success).toBe(false);
  });

  it('an outcome with an unknown result kind', () => {
    const t = trial();
    (t.outcomes as Record<string, unknown>[])[0]!.resultKind = 'exploded';
    expect(trialSchema.safeParse(t).success).toBe(false);
  });

  it('a thesis must be one sentence, in both voices', () => {
    expect(sentence.safeParse('The Wizard reckons.').success).toBe(true);
    expect(sentence.safeParse('The Wizard reckons. The Witch brews.').success).toBe(false);
    expect(sentence.safeParse('The Wizard reckons').success).toBe(false);
    expect(sentence.safeParse('Dr. Strange and Mr. Norrell both study.').success).toBe(true);
    expect(sentence.safeParse('The Wizard reckons. 14 sums prove it.').success).toBe(false);
    expect(sentence.safeParse('The Wizard reckons. (The Witch brews.)').success).toBe(false);
    expect(sentence.safeParse('It hangs as No. 7 in the hall.').success).toBe(true);
    expect(sentence.safeParse('The sky says No. The Witch waits.').success).toBe(false);
    const w = wizard();
    w.thesis = { almanac: 'One. Two.', cipher: 'Three.' };
    expect(archetypeSchema.safeParse(w).success).toBe(false);
    const p = portrayal();
    p.thesis = { almanac: 'One.' };
    expect(portrayalSchema.safeParse(p).success).toBe(false);
  });

  it('a written archetype needs every prose field, in both voices', () => {
    for (const field of ['epithet', 'cipher', 'thesis', 'costs', 'blindSpots', 'counterparts']) {
      const w = wizard();
      delete w[field];
      expect(archetypeSchema.safeParse(w).success, field).toBe(false);
    }
    const w = wizard();
    (w.costs as Record<string, unknown>[])[0] = { almanac: 'Years.' };
    expect(archetypeSchema.safeParse(w).success).toBe(false);
  });

  it('a seeded archetype may not carry half-written prose', () => {
    const w = wizard();
    w.stage = 'seeded';
    expect(archetypeSchema.safeParse(w).success).toBe(false);
  });

  it('identity values are ids, and every identity field is required', () => {
    const w = wizard();
    (w.identity as Record<string, unknown>).layout = 'Ruled Grid';
    expect(archetypeSchema.safeParse(w).success).toBe(false);
    for (const field of [
      'material',
      'palette',
      'geometry',
      'motion',
      'layout',
      'interaction',
      'typeAccent',
      'entrance',
      'cursor',
      'initial',
      'sound',
    ]) {
      const x = wizard();
      delete (x.identity as Record<string, unknown>)[field];
      expect(archetypeSchema.safeParse(x).success, field).toBe(false);
    }
  });
});

describe('creatures', () => {
  it('is reserved: a stub schema and a collection with no entries', () => {
    const config = readFileSync('src/content.config.ts', 'utf8');
    expect(config).toMatch(/creatures:\s*defineCollection\(\{\s*loader:\s*\(\)\s*=>\s*\[\]/);
    expect(
      creatureSchema.safeParse({
        name: 'Basilisk',
        realm: 'mantle',
        beings: ['tier3-alpha'],
        description: { almanac: 'A gaze of stone.', cipher: 'A paralysing display.' },
      }).success,
    ).toBe(true);
    expect(creatureSchema.safeParse({ name: 'Basilisk' }).success).toBe(false);
  });
});
