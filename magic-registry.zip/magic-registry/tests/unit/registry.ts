/** The whole registry, parsed through the real schemas, for the integrity and voice tests. */
import {
  accessSchema,
  archetypeSchema,
  beingSchema,
  glossarySchema,
  portrayalSchema,
  realmSchema,
  trialSchema,
  type Archetype,
  type WrittenArchetype,
} from '../../src/data/schemas';
import { readCollection } from './content';
import type { z } from 'astro/zod';

function load<S extends z.ZodType>(name: string, schema: S) {
  return readCollection(name).map((e) => ({ id: e.id, body: e.body, data: schema.parse(e.data) }));
}

export const realms = load('realms', realmSchema);
export const beings = load('beings', beingSchema);
export const access = load('access', accessSchema);
export const glossary = load('glossary', glossarySchema);
export const archetypes = load('archetypes', archetypeSchema);
export const portrayals = load('portrayals', portrayalSchema);
export const trials = load('trials', trialSchema);

export const isWritten = (a: Archetype): a is WrittenArchetype => a.stage === 'written';
export const written = archetypes.filter((a) => isWritten(a.data)) as {
  id: string;
  body: string;
  data: WrittenArchetype;
}[];
