import { describe, expect, it } from 'vitest';
import { moonPhase } from '../../src/lib/astronomy';
import {
  EPOCH_NEW_MOON,
  MEAN_MONTH,
  RECKONING_LINES,
  figures,
  reckon,
} from '../../src/lib/reckoning';
import { lint } from './voice-lint';

describe("the Wizard's reckoning (R-PH4-06, D-24)", () => {
  it('counts from the new moon of 6 January 2000, 18:14 UT', () => {
    const r = reckon(new Date(Date.UTC(2000, 0, 6, 18, 14, 24)));
    expect(r.julianDay).toBeCloseTo(EPOCH_NEW_MOON, 3);
    expect(r.days).toBe(0);
    expect(r.lunations).toBe(0);
    expect(r.age).toBeLessThan(0.001);
  });

  it('the Julian day agrees with a known date (J2000.0 is 2451545.0)', () => {
    expect(reckon(new Date(Date.UTC(2000, 0, 1, 12))).julianDay).toBe(2_451_545);
  });

  it('one mean month on, a whole lunation has passed and the age begins again', () => {
    const later = new Date(Date.UTC(2000, 0, 6, 18, 14, 24) + MEAN_MONTH * 86_400_000 + 3_600_000);
    const r = reckon(later);
    expect(r.lunations).toBe(1);
    expect(r.age).toBeCloseTo(1 / 24, 3);
  });

  it('the age stays within a month, and agrees with the moon in the masthead to within two days', () => {
    for (let d = 0; d < 400; d += 7) {
      const date = new Date(Date.UTC(2026, 0, 1) + d * 86_400_000);
      const r = reckon(date);
      expect(r.age).toBeGreaterThanOrEqual(0);
      expect(r.age).toBeLessThan(MEAN_MONTH);
      // The mean month runs ahead of or behind the true moon by up to about 14 hours each way
      // from the epoch's drift and the true moon's unequal pace; two days is a generous bound.
      const trueAge = moonPhase(date).cycle * MEAN_MONTH;
      const gap = Math.abs(r.age - trueAge);
      expect(Math.min(gap, MEAN_MONTH - gap), date.toISOString()).toBeLessThan(2);
    }
  });

  it('sets the figures as the margin shows them: grouped, one decimal, never rounded up', () => {
    const r = reckon(new Date(Date.UTC(2026, 9, 7, 12)));
    const f = figures(r);
    expect(f['julian-day']).toBe('2,461,321.0');
    expect(f.days).toMatch(/^\d{1,3}(,\d{3})*$/);
    expect(Number(f.lunations)).toBe(r.lunations);
    expect(f.age).toMatch(/^\d{1,2}\.\d$/);
    expect(Number(f.age)).toBeLessThanOrEqual(r.age);
  });

  it('labels each line in both voices, in the registry voice', () => {
    expect(RECKONING_LINES.map((l) => l.key)).toEqual(['julian-day', 'days', 'lunations', 'age']);
    for (const l of RECKONING_LINES) {
      expect(lint(l.almanac, 'almanac'), l.almanac).toEqual([]);
      expect(lint(l.cipher, 'cipher'), l.cipher).toEqual([]);
    }
  });
});
