import { describe, expect, it } from 'vitest';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';

/** Every stylesheet and every component style block in the project. */
function styleSources(dir = 'src'): [string, string][] {
  const out: [string, string][] = [];
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    if (statSync(full).isDirectory()) out.push(...styleSources(full));
    else if (/\.(css|astro|tsx|ts)$/.test(name)) out.push([full, readFileSync(full, 'utf8')]);
  }
  return out;
}

/** Splits a comma list at the top level only (commas inside parentheses stay put). */
function topLevel(list: string): string[] {
  const parts: string[] = [];
  let depth = 0;
  let cur = '';
  for (const ch of list) {
    if (ch === '(') depth++;
    if (ch === ')') depth--;
    if (ch === ',' && depth === 0) {
      parts.push(cur.trim());
      cur = '';
    } else cur += ch;
  }
  if (cur.trim()) parts.push(cur.trim());
  return parts;
}

describe('nothing cheap (banned visual effects)', () => {
  const sources = styleSources();

  it('never overshoots: every cubic-bezier is literal and keeps y within 0..1', () => {
    const offenders: string[] = [];
    for (const [file, text] of sources) {
      for (const m of text.matchAll(/cubic-bezier\(([^)]*)\)/g)) {
        const args = m[1].split(',').map((s) => Number(s.trim()));
        const [x1, y1, x2, y2] = args;
        const bad =
          args.length !== 4 ||
          args.some(Number.isNaN) ||
          x1 < 0 ||
          x1 > 1 ||
          x2 < 0 ||
          x2 > 1 ||
          y1 < 0 ||
          y1 > 1 ||
          y2 < 0 ||
          y2 > 1;
        if (bad) offenders.push(`${file}: ${m[0]}`);
      }
    }
    expect(offenders).toEqual([]);
  });

  it('never overshoots through linear() easing either', () => {
    const offenders: string[] = [];
    for (const [file, text] of sources) {
      for (const m of text.matchAll(/\blinear\(([^)]*)\)/g)) {
        const outputs = topLevel(m[1]).map((p) => Number(p.split(/\s+/)[0]));
        if (outputs.some((v) => Number.isNaN(v) || v < 0 || v > 1)) {
          offenders.push(`${file}: ${m[0]}`);
        }
      }
    }
    expect(offenders).toEqual([]);
  });

  it('keyframes never swell past rest (no scale beyond 3%: a landing compresses, it does not bounce)', () => {
    const offenders: string[] = [];
    for (const [file, text] of sources) {
      for (const block of text.matchAll(/@keyframes\s+[\w-]+\s*\{([\s\S]*?)\n\}/g)) {
        for (const m of block[1].matchAll(/scale[XY]?\(([^)]*)\)/g)) {
          const values = m[1].split(',').map((s) => Number(s.trim()));
          if (values.some((v) => Number.isNaN(v) || v > 1.03)) offenders.push(`${file}: ${m[0]}`);
        }
      }
    }
    expect(offenders).toEqual([]);
  });

  it('spells out keyframe timing functions (browsers silently ignore var() there)', () => {
    const offenders: string[] = [];
    for (const [file, text] of sources) {
      for (const block of text.matchAll(/@keyframes\s+([\w-]+)\s*\{([\s\S]*?)\n\}/g)) {
        if (/animation-timing-function:\s*var\(/.test(block[2]))
          offenders.push(`${file}: ${block[1]}`);
      }
    }
    expect(offenders).toEqual([]);
  });

  it('uses no glassmorphism (backdrop blur)', () => {
    const offenders = sources.filter(([, t]) => /backdrop-filter/.test(t)).map(([f]) => f);
    expect(offenders).toEqual([]);
  });

  it('uses no spring physics or confetti libraries', () => {
    const offenders = sources
      .filter(([, t]) => /(react-spring|framer-motion|canvas-confetti|spring\()/.test(t))
      .map(([f]) => f);
    expect(offenders).toEqual([]);
  });

  it('never rounds an engraved edge into a pill or soft card (any radius property, anywhere)', () => {
    const offenders: string[] = [];
    for (const [file, text] of sources) {
      for (const m of text.matchAll(/border(?:-[a-z]+)*-radius\s*:\s*([^;"'}\n]+)/g)) {
        if (!/^(0|50%)$/.test(m[1].trim())) offenders.push(`${file}: ${m[0]}`);
      }
      for (const m of text.matchAll(/borderRadius\s*:\s*['"]?([^,'"}\n]+)/g)) {
        if (!/^(0|50%)$/.test(m[1].trim())) offenders.push(`${file}: ${m[0]}`);
      }
    }
    expect(offenders).toEqual([]);
  });

  it('glows only from a plausible light source: a haloed shadow must take its color from --glow', () => {
    const offenders: string[] = [];
    for (const [file, text] of sources) {
      for (const m of text.matchAll(/(text-shadow|box-shadow|drop-shadow)\s*[:(]\s*([^;]+)/g)) {
        for (const part of topLevel(m[2])) {
          if (/\binset\b/.test(part)) continue;
          // A halo is a shadow with no offset: the signature of a neon glow.
          const halo = /^0(?:px)?\s+0(?:px)?\s+([\d.]+)/.exec(part);
          if (halo && Number(halo[1]) > 0 && !part.includes('var(--glow)')) {
            offenders.push(`${file}: ${m[1]} ${part}`);
          }
        }
      }
    }
    expect(offenders).toEqual([]);
  });
});
