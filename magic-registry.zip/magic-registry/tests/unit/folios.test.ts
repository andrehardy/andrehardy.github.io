import { describe, expect, it } from 'vitest';
import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { ARCHETYPE_IDS } from '../../src/data/schemas';
import { written } from './registry';

/** The archetypes whose folio is composed (src/folios/index.ts), read from its source. */
const registry = readFileSync('src/folios/index.ts', 'utf8');
const composed = [...registry.matchAll(/^\s+([a-z]+): (\w+Folio),$/gm)].map((m) => ({
  id: m[1]!,
  component: m[2]!,
}));

/** A selector list split at its own commas, not those inside :is() or :not(). */
function topLevel(list: string): string[] {
  const out: string[] = [];
  let depth = 0;
  let start = 0;
  for (let i = 0; i < list.length; i++) {
    if (list[i] === '(') depth++;
    else if (list[i] === ')') depth--;
    else if (list[i] === ',' && depth === 0) {
      out.push(list.slice(start, i).trim());
      start = i + 1;
    }
  }
  out.push(list.slice(start).trim());
  return out;
}

/** A stylesheet's rules outside @keyframes: each selector list with its declarations. */
function rules(css: string): { selectors: string[]; body: string }[] {
  const text = css.replace(/\/\*[\s\S]*?\*\//g, '');
  const out: { selectors: string[]; body: string }[] = [];
  let i = 0;
  const walk = (end: number) => {
    while (i < end) {
      const open = text.indexOf('{', i);
      if (open < 0 || open >= end) return;
      const head = text.slice(i, open).trim();
      let depth = 1;
      let j = open + 1;
      while (depth && j < text.length) {
        if (text[j] === '{') depth++;
        else if (text[j] === '}') depth--;
        j++;
      }
      if (head.startsWith('@keyframes')) {
        i = j;
      } else if (head.startsWith('@')) {
        i = open + 1;
        walk(j - 1);
        i = j;
      } else {
        out.push({
          selectors: topLevel(head),
          body: text.slice(open + 1, j - 1),
        });
        i = j;
      }
    }
  };
  walk(text.length);
  return out;
}

describe('the folio registry (R-PH4-09)', () => {
  it('the Wizard is composed, as the golden folio', () => {
    expect(composed.map((c) => c.id)).toContain('wizard');
  });

  it('every composed folio is a written archetype with its own component and stylesheet', () => {
    const writtenIds = new Set(written.map((a) => a.id));
    for (const { id, component } of composed) {
      expect(ARCHETYPE_IDS as readonly string[]).toContain(id);
      expect(writtenIds.has(id), id).toBe(true);
      const file = `src/folios/${component}.astro`;
      expect(existsSync(file), file).toBe(true);
      expect(readFileSync(file, 'utf8')).toContain(`~/styles/archetypes/${id}.css`);
      expect(existsSync(`src/styles/archetypes/${id}.css`), id).toBe(true);
    }
  });

  it('no two folios share a component', () => {
    expect(new Set(composed.map((c) => c.component)).size).toBe(composed.length);
  });

  it("each archetype's stylesheet reaches only that archetype's leaves", () => {
    for (const file of readdirSync('src/styles/archetypes')) {
      const id = file.replace(/\.css$/, '');
      const scope = `[data-archetype='${id}']`;
      const css = readFileSync(`src/styles/archetypes/${file}`, 'utf8');
      const found = rules(css);
      expect(found.length, file).toBeGreaterThan(10);
      for (const r of found)
        for (const s of r.selectors) expect(s.startsWith(scope), `${file}: ${s}`).toBe(true);
    }
  });
});

describe('every composed folio is whole and its own (R-ROUTE-02, R-ID-02, R-PH6)', () => {
  const others = composed.filter((c) => c.id !== 'wizard');
  const identity = (id: string) => written.find((a) => a.id === id)!.data.identity;

  it('the Sky is composed: Cleric, Paladin, Shaman and Druid', () => {
    for (const id of ['cleric', 'paladin', 'shaman', 'druid'])
      expect(composed.map((c) => c.id)).toContain(id);
  });

  for (const { id, component } of others) {
    const folio = readFileSync(`src/folios/${component}.astro`, 'utf8');
    const css = readFileSync(`src/styles/archetypes/${id}.css`, 'utf8');

    it(`${id}: every section is set, the Account and the plate turn from its sigil`, () => {
      for (const section of [
        'thesis',
        'account',
        'instruments',
        'costs',
        'counterparts',
        'trials',
        'ledger',
      ])
        expect(folio, section).toMatch(new RegExp(`(data-section="${section}"|id: '${section}')`));
      expect(folio).toMatch(/<Account entry=\{entry\} \/>/);
      expect(folio).toContain(`turnsFrom="sigil-${id}"`);
      expect(folio).toMatch(new RegExp(`<Sigil\\s+archetype="${id}"`));
    });

    it(`${id}: carries its own cursor, drawn, named for its identity`, () => {
      const cursor = identity(id).cursor;
      expect(css).toMatch(
        new RegExp(`\\.cursor-${cursor}[\\s\\S]*cursor:\\s*url\\("data:image/svg\\+xml`),
      );
      const script = readdirSync(`src/folios/${id}`)
        .map((f) => readFileSync(`src/folios/${id}/${f}`, 'utf8'))
        .join('\n');
      expect(script).toContain(`cursorLayer('${cursor}'`);
    });

    it(`${id}: its Account is let in only after the initial, by its own reveal`, () => {
      const reveal = new RegExp(
        `\\[data-archetype='${id}'\\] \\.account-text \\{[^}]*animation:\\s*${id}-[a-z-]+[^}]*animation-delay:\\s*var\\(--after-initial`,
      );
      expect(css).toMatch(reveal);
    });

    it(`${id}: has its own illuminated initial`, () => {
      expect(identity(id).initial).not.toBe('construction-capital');
    });
  }
});

describe("the Sky's own type (R-ID-*-07)", () => {
  const css = (id: string) => rules(readFileSync(`src/styles/archetypes/${id}.css`, 'utf8'));

  it('the Cleric sets its headings as Cinzel uncials', () => {
    const found = css('cleric').filter((r) => /font-family:\s*var\(--font-seal\)/.test(r.body));
    const sel = found.flatMap((r) => r.selectors);
    expect(sel).toContain("[data-archetype='cleric'] .bay-title");
    expect(sel).toContain("[data-archetype='cleric'] .cleric-head h1");
  });

  it('the Paladin sets its mottoes in widely spaced capitals', () => {
    const motto = css('paladin').find((r) =>
      r.selectors.includes("[data-archetype='paladin'] .motto"),
    )!;
    expect(motto.body).toMatch(/text-transform:\s*uppercase/);
    expect(Number(/letter-spacing:\s*([\d.]+)em/.exec(motto.body)![1])).toBeGreaterThanOrEqual(
      0.25,
    );
  });

  it('the Shaman bends its titles along circles, letterspaced, in IM Fell roman', () => {
    const folio = readFileSync('src/folios/ShamanFolio.astro', 'utf8');
    expect(folio).toMatch(/<textPath/);
    const t = css('shaman').find((r) =>
      r.selectors.includes("[data-archetype='shaman'] .round-title text"),
    )!;
    expect(t.body).toMatch(/font-family:\s*var\(--font-margin\)/);
    expect(t.body).toMatch(/letter-spacing:\s*0\.2\d?em/);
  });

  it("the Druid's register keeps its historical ligatures", () => {
    const lig = css('druid').find((r) => /historical-ligatures/.test(r.body))!;
    expect(lig.selectors).toContain("[data-archetype='druid'] .grove");
    expect(lig.body).toMatch(/'hlig' 1/);
  });
});

describe("the Mantle's own type (R-ID-*-07)", () => {
  const css = (id: string) => rules(readFileSync(`src/styles/archetypes/${id}.css`, 'utf8'));
  const rule = (id: string, sel: string) =>
    css(id).find((r) => r.selectors.includes(`[data-archetype='${id}'] ${sel}`))!;

  it('the Mantle is composed: Witch, Enchantress, Warlock, Necromancer and Bard', () => {
    for (const id of ['witch', 'enchantress', 'warlock', 'necromancer', 'bard'])
      expect(composed.map((c) => c.id)).toContain(id);
  });

  it('the Witch labels her specimens in IM Fell italic', () => {
    const label = rule('witch', '.specimen-label');
    expect(label.body).toMatch(/font-family:\s*var\(--font-margin\)/);
    expect(label.body).toMatch(/font-style:\s*italic/);
  });

  it('the Enchantress sets her headings in light italic, mirrored across the hinge', () => {
    for (const sel of ['.leaf-title', '.leaf-reflection']) {
      const r = rule('enchantress', sel);
      expect(r.body).toMatch(/font-family:\s*var\(--font-display\)/);
      expect(r.body).toMatch(/font-style:\s*italic/);
      expect(r.body).toMatch(/font-weight:\s*300/);
    }
    expect(rule('enchantress', '.leaf-reflection').body).toMatch(/scale:\s*-1 1/);
  });

  it('the Warlock heads his clauses in blackletter', () => {
    expect(rule('warlock', '.clause-head').body).toMatch(
      /font-family:\s*var\(--font-blackletter\)/,
    );
  });

  it('the Necromancer numbers his callouts in IM Fell small capitals', () => {
    for (const sel of ['.callout-name', '.callout-no'])
      expect(rule('necromancer', sel).body).toMatch(/font-family:\s*var\(--font-smallcaps\)/);
  });

  it("the Bard sets his verses' heads in EB Garamond's swash italic, on a stave", () => {
    const head = rule('bard', '.verse-head');
    expect(head.body).toMatch(/font-family:\s*var\(--font-body\)/);
    expect(head.body).toMatch(/font-style:\s*italic/);
    expect(head.body).toMatch(/'swsh' 1/);
    expect(head.body).toMatch(/repeating-linear-gradient/);
  });
});

describe("the Threshold's own type (R-ID-*-07)", () => {
  const css = (id: string) => rules(readFileSync(`src/styles/archetypes/${id}.css`, 'utf8'));
  const rule = (id: string, sel: string) =>
    css(id).find((r) => r.selectors.includes(`[data-archetype='${id}'] ${sel}`))!;

  it('every archetype has its own composed folio', () => {
    expect(composed.map((c) => c.id).sort()).toEqual([...ARCHETYPE_IDS].sort());
  });

  it('the Sorcerer sets his heads in Cormorant bold, scorched, and off their line', () => {
    const head = rule('sorcerer', '.vessel-head');
    expect(head.body).toMatch(/font-family:\s*var\(--font-display\)/);
    expect(Number(/font-weight:\s*(\d+)/.exec(head.body)![1])).toBeGreaterThanOrEqual(600);
    expect(head.body).toMatch(/text-shadow:\s*0\.\d+em 0\.\d+em/);
    expect(head.body).toMatch(/rotate:\s*-?0\.\d+deg/);
  });

  it('the Alchemist heads each entry with its metal set inline, the failed attempt struck through', () => {
    const folio = readFileSync('src/folios/AlchemistFolio.astro', 'utf8');
    expect(folio).toMatch(/<s>\{e\.struck\}<\/s>/);
    expect(folio).toMatch(/<svg\s+class="metal"\s+data-metal=\{e\.metal\}/);
    expect(folio).toMatch(/WORK_ORDER\[i\]/);
    expect(rule('alchemist', '.attempt s').body).toMatch(/text-decoration-color/);
  });
});

describe('the Mantle moves by its own physics (R-ID-*-04)', () => {
  const sheet = (id: string) => readFileSync(`src/styles/archetypes/${id}.css`, 'utf8');
  it('the Necromancer never glides: every animation and transition of his is stepped', () => {
    const css = sheet('necromancer').replace(/\/\*[\s\S]*?\*\//g, '');
    const timings = [...css.matchAll(/(?:^|[;{\s])(animation|transition):([^;}]+)/g)].map(
      (m) => m[2]!,
    );
    const own = timings.filter((t) => !/cursor|account/.test(t));
    expect(own.length).toBeGreaterThan(3);
    for (const t of own) expect(t, t).toMatch(/steps\(/);
  });
});

describe("the Wizard's own type (R-ID-WIZ-05)", () => {
  const css = readFileSync('src/styles/archetypes/wizard.css', 'utf8');
  const found = rules(css);
  const declaring = (re: RegExp) =>
    found.filter((r) => re.test(r.body)).flatMap((r) => r.selectors);

  it('sets its figures tabular and lining, in the ledger and its margin', () => {
    const tabular = declaring(/font-variant-numeric:\s*lining-nums tabular-nums/);
    expect(tabular).toContain("[data-archetype='wizard'] .wizard-ledger");
    expect(tabular).toContain("[data-archetype='wizard'] .row-margin");
    expect(declaring(/'tnum' 1/).length).toBeGreaterThan(0);
  });

  it('sets its labels in small capitals', () => {
    const caps = declaring(/font-variant-caps:\s*small-caps/);
    expect(caps).toContain("[data-archetype='wizard'] .row-title");
    expect(caps).toContain("[data-archetype='wizard'] .row-sub");
  });

  it('carries its own cursor and its own entrance', () => {
    expect(css).toMatch(/\.compass-cursor[\s\S]*cursor:\s*url\("data:image\/svg\+xml/);
    expect(css).toMatch(/\.compass-sweep/);
    expect(css).toMatch(/\.construction-arc/);
  });

  it('every folio section is present in the composition (R-PH4-03)', () => {
    const folio = readFileSync('src/folios/WizardFolio.astro', 'utf8');
    for (const section of [
      'thesis',
      'account',
      'instruments',
      'costs',
      'counterparts',
      'trials',
      'ledger',
    ])
      expect(folio, section).toMatch(new RegExp(`data-section="${section}"`));
  });
});
