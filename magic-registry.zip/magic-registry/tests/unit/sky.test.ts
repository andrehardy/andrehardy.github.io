import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import {
  METEOR_GAP,
  MOONRISE_ALTITUDE,
  PLANETS,
  horizontal,
  meanLongitude,
  moonPlace,
  moonrise,
  nextMeteor,
  observerFrom,
  panorama,
  ringSeconds,
  siderealTime,
} from '../../src/lib/sky';

const near = (a: number, b: number, tol: number) => {
  const d = Math.abs(((a - b + 540) % 360) - 180);
  expect(d, `${a} vs ${b}`).toBeLessThanOrEqual(tol);
};

describe('the sky over the reader (R-SKY-01)', () => {
  it('keeps sidereal time as Meeus does (Example 12.a: 1987 April 10, 0h UT)', () => {
    near(siderealTime(new Date(Date.UTC(1987, 3, 10))), 197.693195, 0.001);
  });

  it('sets the pole star at the height of the observer’s latitude', () => {
    for (const lat of [10, 42, 60]) {
      const at = { lat, lon: -71 };
      for (const h of [0, 7, 15]) {
        const { alt } = horizontal(37.95, 89.26, at, new Date(Date.UTC(2026, 9, 7, h)));
        expect(Math.abs(alt - lat)).toBeLessThan(1);
      }
    }
  });

  it('turns the sky once a sidereal day: a star returns to its place in 23h 56m 4s', () => {
    const at = { lat: 42, lon: -71 };
    const t = Date.UTC(2026, 9, 7, 22);
    const a = horizontal(279.23, 38.78, at, new Date(t));
    const b = horizontal(279.23, 38.78, at, new Date(t + 86_164_091));
    expect(Math.abs(a.alt - b.alt)).toBeLessThan(0.01);
    near(a.az, b.az, 0.01);
  });

  it('places the reader by their clock, on their side of the equator', () => {
    expect(observerFrom('America/New_York', 240)).toEqual({ lat: 42, lon: -60 });
    expect(observerFrom('Australia/Sydney', -600)).toEqual({ lat: -34, lon: 150 });
    expect(observerFrom('America/Argentina/Buenos_Aires', 180).lat).toBeLessThan(0);
    expect(observerFrom('Europe/London', 0).lat).toBeGreaterThan(0);
  });

  it('faces the reader toward the pole that does not set behind them; the ground lies below', () => {
    const north = { lat: 42, lon: 0 };
    expect(panorama({ alt: 0, az: 180 }, north, 180)).toEqual({ x: 0.5, y: 1 });
    expect(panorama({ alt: 90, az: 180 }, north, 180).y).toBe(0);
    expect(panorama({ alt: 30, az: 270 }, north, 180).x).toBeCloseTo(1);
    expect(panorama({ alt: -20, az: 180 }, north, 180).y).toBeGreaterThan(1);
    expect(panorama({ alt: 0, az: 0 }, { lat: -34, lon: 0 }, 180).x).toBe(0.5);
  });

  it('ships a trimmed catalogue and the figures that the stars make', () => {
    const stars = JSON.parse(readFileSync('public/data/stars.json', 'utf8')) as number[][];
    expect(stars.length).toBeGreaterThan(800);
    expect(stars.length).toBeLessThan(1500);
    // Sirius, the brightest, comes first.
    expect(stars[0]![2]).toBeLessThan(-1);
    near(stars[0]![0]!, 101.29, 0.1);
    for (const [ra, dec, v] of stars) {
      expect(ra).toBeGreaterThanOrEqual(0);
      expect(ra).toBeLessThan(360);
      expect(Math.abs(dec!)).toBeLessThanOrEqual(90);
      expect(v).toBeLessThanOrEqual(4.6);
    }
    const figures = JSON.parse(readFileSync('public/data/constellations.json', 'utf8')) as {
      id: string;
    }[];
    expect(figures.map((f) => f.id)).toEqual(expect.arrayContaining(['Ori', 'UMa', 'Cas', 'Cru']));
    expect(readFileSync('public/data/constellations.LICENSE.txt', 'utf8')).toMatch(/Olaf Frohn/);
  });
});

describe('the Moon (R-SKY-02)', () => {
  it('stands where Meeus finds it, to within half a degree (Example 47.a: 1992 April 12, 0h)', () => {
    const m = moonPlace(new Date(Date.UTC(1992, 3, 12)));
    near(m.lon, 133.162655, 0.5);
    expect(Math.abs(m.lat - -3.229126)).toBeLessThan(0.5);
    near(m.ra, 134.68847, 0.5);
    expect(Math.abs(m.dec - 13.768368)).toBeLessThan(0.5);
  });

  it('rises: at the hour given, the upper limb is on the horizon and climbing', () => {
    const at = { lat: 42, lon: -71 };
    for (const day of [1, 9, 17, 25]) {
      const from = new Date(Date.UTC(2026, 9, day, 4));
      const rise = moonrise(from, at);
      if (!rise) continue;
      expect(rise.getTime()).toBeGreaterThan(from.getTime());
      const alt = (t: number) => {
        const m = moonPlace(new Date(t));
        return horizontal(m.ra, m.dec, at, new Date(t)).alt;
      };
      expect(Math.abs(alt(rise.getTime()) - MOONRISE_ALTITUDE)).toBeLessThan(0.05);
      expect(alt(rise.getTime() + 600_000)).toBeGreaterThan(alt(rise.getTime()));
    }
  });

  it('rises about fifty minutes later each day', () => {
    const at = { lat: 42, lon: -71 };
    const a = moonrise(new Date(Date.UTC(2026, 9, 10, 4)), at)!;
    const b = moonrise(new Date(a.getTime() + 12 * 3_600_000), at)!;
    const late = (b.getTime() - a.getTime() - 86_400_000) / 60_000;
    expect(late).toBeGreaterThan(10);
    expect(late).toBeLessThan(90);
  });
});

describe('the orrery (R-SKY-04)', () => {
  it('turns each ring in proportion to its planet’s true period', () => {
    const earth = PLANETS.find((p) => p.id === 'earth')!;
    for (const p of PLANETS)
      expect(ringSeconds(p) / ringSeconds(earth)).toBeCloseTo(p.period / earth.period, 6);
    expect(PLANETS.map((p) => p.period)).toEqual(
      [...PLANETS.map((p) => p.period)].sort((a, b) => a - b),
    );
  });

  it('sets each planet at its mean longitude for the day', () => {
    const earth = PLANETS.find((p) => p.id === 'earth')!;
    near(meanLongitude(earth, new Date(Date.UTC(2000, 0, 1, 12))), 100.464457, 1e-6);
    // A year on, the Earth is back where it was; Mercury has gone round four times and more.
    const a = new Date(Date.UTC(2026, 0, 1));
    const b = new Date(a.getTime() + earth.period * 86_400_000);
    near(meanLongitude(earth, a), meanLongitude(earth, b), 1e-6);
  });
});

describe('a single meteor (R-SKY-03)', () => {
  it('falls first within the first minute of looking', () => {
    for (const draw of [0, 0.5, 0.999]) {
      const t = nextMeteor(null, 1000, draw);
      expect(t).toBeGreaterThan(1000);
      expect(t).toBeLessThan(1000 + METEOR_GAP);
    }
  });

  it('never falls twice within a minute, however the draws go', () => {
    let last: number | null = null;
    let now = 0;
    const falls: number[] = [];
    for (let i = 0; i < 200; i++) {
      const at = nextMeteor(last, now, (i * 0.618) % 1);
      falls.push(at);
      last = at;
      now = at + ((i * 7919) % 5000);
    }
    for (let i = 1; i < falls.length; i++)
      expect(falls[i]! - falls[i - 1]!).toBeGreaterThanOrEqual(METEOR_GAP);
  });
});
