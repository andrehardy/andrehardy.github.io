import { describe, expect, it } from 'vitest';
import { glideAt, held, launch, STIFFNESS, type Glide } from '../../src/folios/wizard/glide';
import type { Pt } from '../../src/folios/wizard/thread';

/** A small fixed-seed generator, so every run tries the same throws. */
function seeded(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 2 ** 32;
  };
}

/** The furthest a return travels past its rest, on either axis, sampled each millisecond. */
function overshoot(g: Glide, ms = 3000): number {
  let worst = 0;
  for (let t = 0; t <= ms; t++) {
    const { x } = glideAt(g, g.t + t);
    for (const i of [0, 1] as const) {
      if (g.x[i] !== 0 && Math.sign(x[i]) === -Math.sign(g.x[i]))
        worst = Math.max(worst, Math.abs(x[i]));
    }
  }
  return worst;
}

describe('the thread returns without bouncing (R-ID-WIZ-06)', () => {
  it('from rest, a pushed thread comes home without passing its rest', () => {
    expect(overshoot(launch([30, -18], [0, 0], 0))).toBe(0);
  });

  it('a thread flung toward its rest is checked, so it never crosses it', () => {
    const rand = seeded(7);
    for (let k = 0; k < 400; k++) {
      const x: Pt = [(rand() - 0.5) * 60, (rand() - 0.5) * 60];
      const v: Pt = [(rand() - 0.5) * 2000, (rand() - 0.5) * 2000];
      expect(overshoot(launch(x, v, 0))).toBe(0);
    }
  });

  it('the check matters: an unchecked fling would cross its rest', () => {
    const wild: Glide = { x: [10, 0], v: [-400, 0], t: 0 };
    expect(overshoot(wild)).toBeGreaterThan(1);
    expect(held(10, -400)).toBe(-STIFFNESS * 10);
    expect(held(-10, 400)).toBe(STIFFNESS * 10);
    expect(held(10, 50)).toBe(50);
  });

  it('a hand scribbling across a thread never makes it swing past where it is bound', () => {
    const rand = seeded(11);
    let target: Pt = [0, 0];
    let g = launch([0, 0], [0, 0], 0);
    let now = 0;
    for (let k = 0; k < 300; k++) {
      now += 10 + rand() * 120;
      const here = glideAt(g, now);
      const at: Pt = [target[0] + here.x[0], target[1] + here.x[1]];
      target = rand() < 0.5 ? [0, 0] : [(rand() - 0.5) * 60, (rand() - 0.5) * 60];
      g = launch([at[0] - target[0], at[1] - target[1]], here.v, now);
      expect(overshoot(g, 400)).toBe(0);
    }
  });

  it('a new return starts where the thread is, so it never jumps', () => {
    const g = launch([20, 5], [0, 0], 0);
    const mid = glideAt(g, 120);
    const next = launch(mid.x, mid.v, 120);
    expect(glideAt(next, 120).x).toEqual(mid.x);
  });

  it('it comes to rest, exactly, within two seconds', () => {
    const g = launch([30, 30], [0, 0], 0);
    const end = glideAt(g, 2000);
    expect(end.moving).toBe(false);
    expect(end.x).toEqual([0, 0]);
    expect(glideAt(g, 200).moving).toBe(true);
  });
});
