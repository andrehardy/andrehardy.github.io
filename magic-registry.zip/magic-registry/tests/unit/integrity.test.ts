import { describe, expect, it } from 'vitest';
import { ACCESS_IDS, ARCHETYPE_IDS } from '../../src/data/schemas';
import { ARCHETYPE_REALM } from '../../src/data/palettes';
import { labelsOf, namedBy } from '../../src/lib/labels';
import { CURRENT_PHASE } from '../phase';
import {
  access,
  archetypes,
  beings,
  glossary,
  portrayals,
  realms,
  trials,
  written,
} from './registry';

/** Once every archetype is written (after the Phase 5 batches), completeness is enforced (D-16). */
const ALL_WRITTEN = CURRENT_PHASE >= 5;

const byId = <T extends { id: string }>(xs: T[]) => new Map(xs.map((x) => [x.id, x]));
const arch = byId(archetypes);

describe('taxonomy', () => {
  it('names are the one canonical set, with the two agreed aliases', () => {
    const names = Object.fromEntries(archetypes.map((a) => [a.id, a.data.name]));
    expect(names).toEqual({
      wizard: 'Wizard',
      witch: 'Witch',
      shaman: 'Shaman',
      sorcerer: 'Sorcerer',
      enchantress: 'Enchantress',
      warlock: 'Warlock',
      druid: 'Druid',
      necromancer: 'Necromancer',
      cleric: 'Cleric',
      paladin: 'Paladin',
      alchemist: 'Alchemist',
      bard: 'Bard',
    });
    const aliases = Object.fromEntries(
      archetypes.filter((a) => a.data.aliases.length).map((a) => [a.id, a.data.aliases]),
    );
    expect(aliases).toEqual({ enchantress: ['Siren'], cleric: ['Priest'] });
  });

  it('each archetype is filed under the realm of its Source', () => {
    const realmOf = Object.fromEntries(archetypes.map((a) => [a.id, a.data.realm]));
    expect(realmOf).toEqual({
      cleric: 'sealed',
      paladin: 'vault',
      wizard: 'vault',
      shaman: 'vault',
      druid: 'vault',
      sorcerer: 'threshold',
      alchemist: 'threshold',
      bard: 'mantle',
      enchantress: 'mantle',
      witch: 'mantle',
      warlock: 'mantle',
      necromancer: 'mantle',
    });
    expect(realmOf).toEqual(ARCHETYPE_REALM);
  });

  it('axis values, and the two zeros say why they are zero', () => {
    const axis = Object.fromEntries(archetypes.map((a) => [a.id, a.data.axis]));
    expect(axis).toEqual({
      cleric: 100,
      paladin: 80,
      wizard: 75,
      shaman: 55,
      druid: 40,
      sorcerer: 0,
      alchemist: 0,
      bard: -35,
      enchantress: -55,
      witch: -65,
      warlock: -75,
      necromancer: -90,
    });
    const notes = Object.fromEntries(
      archetypes.filter((a) => a.data.axisNote).map((a) => [a.id, a.data.axisNote]),
    );
    expect(notes).toEqual({ sorcerer: 'oscillating', alchemist: 'unbound' });
  });

  it('the reader is told that earthly-looking practitioners can draw from the sky', () => {
    const vault = realms.find((r) => r.id === 'vault')!.data.description;
    expect(vault.almanac).toMatch(/Grid/);
    expect(vault.almanac).toMatch(/answers to the sky and not to the soil/);
    expect(vault.cipher).toMatch(/Grid/);
    expect(vault.cipher).toMatch(/look earthly draw from the sky/);
  });

  it('the axis agrees with the realm: Sealed at the top, Vault above zero, Mantle below', () => {
    for (const a of archetypes) {
      const { realm, axis } = a.data;
      if (realm === 'sealed') expect(axis, a.id).toBe(100);
      if (realm === 'vault') expect(axis, a.id).toBeGreaterThan(0);
      if (realm === 'threshold') expect(axis, a.id).toBe(0);
      if (realm === 'mantle') expect(axis, a.id).toBeLessThan(0);
    }
  });
});

describe('references resolve', () => {
  const realmIds = new Set(realms.map((r) => r.id));
  const beingIds = new Set(beings.map((b) => b.id));
  const accessIds = new Set(access.map((a) => a.id));

  it('realms, beings and access methods named by archetypes exist', () => {
    for (const a of archetypes) {
      expect(realmIds.has(a.data.realm), a.id).toBe(true);
      for (const b of a.data.beings) expect(beingIds.has(b), `${a.id} being ${b}`).toBe(true);
      expect(accessIds.has(a.data.access), a.id).toBe(true);
    }
  });

  it('each archetype has its own access method, and every method belongs to one archetype', () => {
    const used = archetypes.map((a) => a.data.access);
    expect(new Set(used).size).toBe(ARCHETYPE_IDS.length);
    expect([...used].sort()).toEqual([...ACCESS_IDS].sort());
  });

  it('counterparts point at other archetypes, once each', () => {
    for (const a of written) {
      const ids = a.data.counterparts.map((c) => c.archetype);
      expect(ids, a.id).not.toContain(a.id);
      expect(new Set(ids).size, a.id).toBe(ids.length);
      for (const id of ids) expect(arch.has(id), `${a.id} -> ${id}`).toBe(true);
    }
  });

  it('portrayal verdicts and trial outcomes name archetypes that exist', () => {
    for (const p of portrayals) expect(arch.has(p.data.verdict), p.id).toBe(true);
    for (const t of trials)
      for (const o of t.data.outcomes) expect(arch.has(o.archetype), t.id).toBe(true);
  });
});

describe('counterparts are reciprocal', () => {
  it(
    ALL_WRITTEN
      ? 'between every pair'
      : 'between written archetypes (a seeded counterpart is pending, D-16)',
    () => {
      const missing: string[] = [];
      for (const a of written)
        for (const c of a.data.counterparts) {
          const other = arch.get(c.archetype)!.data;
          if (other.stage !== 'written') {
            if (ALL_WRITTEN) missing.push(`${c.archetype} is not written`);
            continue;
          }
          if (!other.counterparts.some((x) => x.archetype === a.id))
            missing.push(`${c.archetype} does not name ${a.id}`);
        }
      expect(missing).toEqual([]);
    },
  );
});

describe('trials', () => {
  it('outcomes are unique per archetype and belong to written archetypes', () => {
    for (const t of trials) {
      const ids = t.data.outcomes.map((o) => o.archetype);
      expect(new Set(ids).size, t.id).toBe(ids.length);
      for (const id of ids) expect(arch.get(id)!.data.stage, `${t.id}/${id}`).toBe('written');
    }
  });

  it.runIf(ALL_WRITTEN)('every trial has exactly twelve outcomes', () => {
    for (const t of trials) expect(t.data.outcomes, t.id).toHaveLength(12);
  });
});

describe('completeness', () => {
  it('the Wizard is written (Phase 2 win)', () => {
    expect(arch.get('wizard')!.data.stage).toBe('written');
  });

  it('every written archetype has one outcome in every trial', () => {
    const missing: string[] = [];
    for (const a of written)
      for (const t of trials) {
        const n = t.data.outcomes.filter((o) => o.archetype === a.id).length;
        if (n !== 1) missing.push(`${a.id} has ${n} outcomes in ${t.id}`);
      }
    expect(missing).toEqual([]);
  });

  it('every written archetype has an exemplar and a runner-up portrayal', () => {
    const missing: string[] = [];
    for (const a of written)
      for (const rank of ['exemplar', 'runner-up'] as const)
        if (!portrayals.some((p) => p.data.verdict === a.id && p.data.rank === rank))
          missing.push(`${a.id} ${rank}`);
    expect(missing).toEqual([]);
  });

  it.runIf(ALL_WRITTEN)('every archetype is written', () => {
    expect(archetypes.filter((a) => a.data.stage !== 'written').map((a) => a.id)).toEqual([]);
  });

  it('a written archetype has an almanac body', () => {
    for (const a of written) expect(a.body.length, a.id).toBeGreaterThan(400);
  });
});

describe('the Wizard and the Witch', () => {
  it('their contrast, Merlin against Morgan, lives in the counterpart note in both voices', () => {
    const note = written
      .find((a) => a.id === 'wizard')!
      .data.counterparts.find((c) => c.archetype === 'witch')!.note;
    for (const layer of [note.almanac, note.cipher]) {
      expect(layer).toContain('Merlin');
      expect(layer).toContain('Morgan');
    }
  });
});

describe('portrayals', () => {
  const labels = labelsOf(archetypes);
  const named = (label: string) => namedBy(label, labels);

  it('reads labels in their plural and possessive forms', () => {
    expect(named('one of the sorcerers of Kamar-Taj').map((l) => l.id)).toEqual(['sorcerer']);
    expect(named('the witches of the coven').map((l) => l.id)).toEqual(['witch']);
    expect(named("the priestess's apprentice").map((l) => l.id)).toEqual(['cleric']);
    expect(named('Magician')).toEqual([]);
  });

  it('a label naming another archetype is misfiled; a misfiled label must name one', () => {
    for (const p of portrayals) {
      const other = named(p.data.canonLabel).some((l) => l.id !== p.data.verdict);
      if (other) expect(p.data.verdictKind, p.id).not.toBe('true-to-label');
      if (p.data.verdictKind === 'misfiled') expect(other, p.id).toBe(true);
    }
  });

  it('each archetype has at most one exemplar and one runner-up', () => {
    for (const rank of ['exemplar', 'runner-up'] as const) {
      const per = new Map<string, number>();
      for (const p of portrayals)
        if (p.data.rank === rank) per.set(p.data.verdict, (per.get(p.data.verdict) ?? 0) + 1);
      for (const [id, n] of per) expect(n, `${id} ${rank}`).toBe(1);
    }
  });

  it('the seed verdicts carried over from the reference are confirmed (D-19)', () => {
    const seeds: [string, string, string, string][] = [
      ['quentin-coldwater', 'wizard', 'exemplar', 'true-to-label'],
      ['stephen-strange', 'wizard', 'runner-up', 'misfiled'],
      ['leeloo', 'cleric', 'exemplar', 'true-to-label'],
      ['john-constantine-film', 'cleric', 'runner-up', 'true-to-label'],
      ['master-chief', 'paladin', 'exemplar', 'true-to-label'],
      ['din-djarin', 'paladin', 'runner-up', 'true-to-label'],
      ['walter-bishop', 'shaman', 'exemplar', 'true-to-label'],
      ['guild-navigators', 'shaman', 'runner-up', 'true-to-label'],
      ['the-navi', 'druid', 'exemplar', 'true-to-label'],
      ['swamp-thing', 'druid', 'runner-up', 'true-to-label'],
      ['the-cut-wife', 'witch', 'exemplar', 'true-to-label'],
      ['the-grand-high-witch', 'witch', 'runner-up', 'true-to-label'],
      ['bo-dennis', 'enchantress', 'exemplar', 'true-to-label'],
      ['true-blood-vampires', 'enchantress', 'runner-up', 'true-to-label'],
      ['morgan-le-fay', 'enchantress', 'notable', 'misfiled'],
      ['crossroads-bargainers', 'warlock', 'exemplar', 'true-to-label'],
      ['light-yagami', 'warlock', 'runner-up', 'true-to-label'],
      ['john-constantine-hellblazer', 'warlock', 'notable', 'true-to-label'],
      ['evelyn-poole', 'warlock', 'notable', 'misfiled'],
      ['liv-moore', 'necromancer', 'exemplar', 'true-to-label'],
      ['the-night-king', 'necromancer', 'runner-up', 'true-to-label'],
      ['marnie-stonebrook', 'necromancer', 'notable', 'misfiled'],
      ['laurel-lance', 'bard', 'exemplar', 'true-to-label'],
      ['paul-atreides-weirding', 'bard', 'runner-up', 'true-to-label'],
      ['eleven', 'sorcerer', 'exemplar', 'true-to-label'],
      ['clark-kent-smallville', 'sorcerer', 'runner-up', 'true-to-label'],
      ['harry-potter', 'sorcerer', 'notable', 'misfiled'],
      ['gandalf', 'cleric', 'notable', 'anomaly'],
      ['edward-elric', 'alchemist', 'exemplar', 'true-to-label'],
      ['walter-white', 'alchemist', 'runner-up', 'true-to-label'],
    ];
    for (const [id, verdict, rank, kind] of seeds) {
      const p = portrayals.find((x) => x.id === id);
      expect(p, id).toBeDefined();
      expect([p!.data.verdict, p!.data.rank, p!.data.verdictKind, p!.data.status], id).toEqual([
        verdict,
        rank,
        kind,
        'confirmed',
      ]);
    }
  });
});

describe('glossary and term mapping', () => {
  it('pins the plan seven plus the Threshold and the Grid (D-04)', () => {
    expect(glossary.map((g) => g.data.term).sort()).toEqual(
      [
        'The Vault',
        'The Deep Mantle',
        'The Sealed Light',
        'Being',
        'Source',
        'Covenant',
        'Keys of Ingestion',
        'The Threshold',
        'The Grid',
      ].sort(),
    );
  });

  it('maps the tiers onto realm names in both voices', () => {
    const r = Object.fromEntries(realms.map((x) => [x.id, x.data]));
    expect(r.vault).toMatchObject({ almanacName: 'The Vault', cipherName: 'The First Tier' });
    expect(r.mantle).toMatchObject({
      almanacName: 'The Deep Mantle',
      cipherName: 'The Second Tier',
    });
    expect(r.sealed).toMatchObject({
      almanacName: 'The Sealed Light',
      cipherName: 'The Sealed Tier',
    });
    expect(r.threshold).toMatchObject({ almanacName: 'The Threshold' });
    const g = Object.fromEntries(glossary.map((x) => [x.id, x.data]));
    for (const id of ['vault', 'mantle', 'threshold'] as const)
      expect(g[id]).toMatchObject({ term: r[id]!.almanacName, cipherTerm: r[id]!.cipherName });
    expect(g['sealed-light']).toMatchObject({
      term: r.sealed!.almanacName,
      cipherTerm: r.sealed!.cipherName,
    });
  });

  it('a bargain is a Covenant and an ingested key is one of the Keys of Ingestion', () => {
    const a = Object.fromEntries(access.map((x) => [x.id, x.data]));
    expect(a.covenant!.almanacName).toBe('The Covenant');
    expect(a.ingestion!.cipherName).toBe('Keys of Ingestion');
  });
});
