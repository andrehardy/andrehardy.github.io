import { describe, expect, it } from 'vitest';
import {
  describe as describePhase,
  julianDay,
  litPath,
  moonPhase,
  phaseName,
} from '~/lib/astronomy';

/** Principal phases from published ephemerides (UTC). */
const NEW_MOONS = [
  '2023-10-14T17:55Z', // annular solar eclipse
  '2024-04-08T18:21Z', // total solar eclipse
  '2026-02-17T12:01Z', // annular solar eclipse
];
const FULL_MOONS = [
  '2022-11-08T11:02Z', // total lunar eclipse
  '2025-03-14T06:55Z', // total lunar eclipse
  '2025-09-07T18:09Z', // total lunar eclipse
];
const FIRST_QUARTERS = ['2024-04-15T19:13Z', '2025-01-06T23:56Z'];
const LAST_QUARTERS = ['2024-04-02T03:15Z', '2025-01-21T20:31Z'];

describe('the lunar phase', () => {
  it('converts to Julian days (Meeus 7.a: 1957 October 4.81 = JD 2436116.31)', () => {
    expect(julianDay(new Date(Date.UTC(1957, 9, 4, 19, 26, 24)))).toBeCloseTo(2436116.31, 2);
  });

  it('matches Meeus example 48.a (1992 April 12, 0h: 0.6786 lit)', () => {
    expect(moonPhase(new Date('1992-04-12T00:00Z')).fraction).toBeCloseTo(0.68, 2);
  });

  it('is dark at known new moons and full at known full moons', () => {
    for (const d of NEW_MOONS) {
      const p = moonPhase(new Date(d));
      expect(p.fraction, d).toBeLessThan(0.005);
      expect(p.name, d).toBe('New Moon');
    }
    for (const d of FULL_MOONS) {
      const p = moonPhase(new Date(d));
      expect(p.fraction, d).toBeGreaterThan(0.995);
      expect(p.name, d).toBe('Full Moon');
    }
  });

  it('is half lit at the quarters, waxing before the full and waning after it', () => {
    for (const d of FIRST_QUARTERS) {
      const p = moonPhase(new Date(d));
      expect(p.fraction, d).toBeCloseTo(0.5, 1);
      expect(p.waxing, d).toBe(true);
      expect(p.name, d).toBe('First Quarter');
    }
    for (const d of LAST_QUARTERS) {
      const p = moonPhase(new Date(d));
      expect(p.fraction, d).toBeCloseTo(0.5, 1);
      expect(p.waxing, d).toBe(false);
      expect(p.name, d).toBe('Last Quarter');
    }
  });

  it('names the long phases between the quarters', () => {
    expect(phaseName(0.12)).toBe('Waxing Crescent');
    expect(phaseName(0.37)).toBe('Waxing Gibbous');
    expect(phaseName(0.62)).toBe('Waning Gibbous');
    expect(phaseName(0.88)).toBe('Waning Crescent');
    expect(phaseName(0.99)).toBe('New Moon');
  });

  it('describes the roundel in words', () => {
    expect(describePhase(moonPhase(new Date(FULL_MOONS[0]!)))).toBe('Full Moon, 100 per cent lit');
  });
});

describe('the lit part of the roundel', () => {
  it('is empty at the new moon and a full disc at the full', () => {
    expect(litPath({ fraction: 0, waxing: true }, 20, 18)).toBe('');
    expect(litPath({ fraction: 1, waxing: true }, 20, 18)).toBe(
      'M20 2A18 18 0 0 1 20 38A18 18 0 0 1 20 2Z',
    );
  });

  it('stands on the right while waxing and the left while waning', () => {
    // A crescent: the limb sweeps clockwise (right) when waxing; the terminator bows back.
    expect(litPath({ fraction: 0.2, waxing: true }, 20, 18)).toBe(
      'M20 2A18 18 0 0 1 20 38A10.8 18 0 0 0 20 2Z',
    );
    expect(litPath({ fraction: 0.2, waxing: false }, 20, 18)).toBe(
      'M20 2A18 18 0 0 0 20 38A10.8 18 0 0 1 20 2Z',
    );
    // A gibbous moon: the terminator bows past the centre, away from the lit limb.
    expect(litPath({ fraction: 0.8, waxing: true }, 20, 18)).toBe(
      'M20 2A18 18 0 0 1 20 38A10.8 18 0 0 1 20 2Z',
    );
  });
});
