import { describe, expect, it } from 'vitest';
import { ARCHETYPE_IDS } from '~/data/palettes';
import { VOICES, voiceFor, type Layer } from '~/lib/voices';

const ids = ['vault', 'mantle', ...ARCHETYPE_IDS] as const;
const gainOf = (l: Layer) => (l.kind === 'events' ? l.hit.gain : l.gain);

describe('the registry sounds (R-FLO-*-SND)', () => {
  it('has a voice for each realm of the home and each of the twelve', () => {
    expect(Object.keys(VOICES).sort()).toEqual([...ids].sort());
    for (const id of ids) {
      expect(VOICES[id].layers.length, id).toBeGreaterThan(0);
      expect(VOICES[id].heard.length, id).toBeGreaterThan(10);
    }
  });

  it('gives no two the same voice', () => {
    const recipes = ids.map((id) => JSON.stringify(VOICES[id].layers));
    expect(new Set(recipes).size).toBe(ids.length);
  });

  it('keeps every layer quiet: a room tone, never a fanfare', () => {
    for (const id of ids)
      for (const l of VOICES[id].layers) {
        expect(gainOf(l), id).toBeGreaterThan(0);
        expect(gainOf(l), id).toBeLessThanOrEqual(0.2);
      }
  });

  it('times every event sensibly', () => {
    for (const id of ids)
      for (const l of VOICES[id].layers) {
        if (l.kind !== 'events') continue;
        expect(Boolean(l.every) !== (l.once !== undefined), id).toBe(true);
        if (l.every) expect(l.every[0], id).toBeGreaterThan(0);
        if (l.every) expect(l.every[1], id).toBeGreaterThanOrEqual(l.every[0]);
        expect(l.hit.decay, id).toBeGreaterThan(l.hit.attack);
      }
  });

  it("gives the Bard one struck string, and leaves the rest to the reader's hand", () => {
    const events = VOICES.bard.layers.filter((l) => l.kind === 'events');
    expect(events).toHaveLength(1);
    expect(events[0]).toMatchObject({ once: expect.any(Number) });
  });

  it('chooses the folio voice on a folio, and the realm voice elsewhere', () => {
    expect(voiceFor('wizard', 'vault')).toBe('wizard');
    expect(voiceFor(undefined, 'mantle')).toBe('mantle');
    expect(voiceFor(undefined, 'vault')).toBe('vault');
    expect(voiceFor(undefined, 'sealed')).toBe('vault');
    expect(voiceFor(undefined, undefined)).toBe('vault');
  });
});
