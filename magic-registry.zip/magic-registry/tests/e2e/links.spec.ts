import { test, expect } from './fixtures';
import { ROUTES } from './site';

const BASE = '/magic-registry/';

test('every link and asset on every page resolves under the project path (R-PROC-10)', async ({
  page,
  request,
}) => {
  const seen = new Set<string>();
  const queue = [BASE];
  const bad: string[] = [];
  const checked = new Map<string, number>();

  while (queue.length) {
    const path = queue.shift()!;
    if (seen.has(path)) continue;
    seen.add(path);
    const response = await page.goto(path);
    expect(response?.status(), path).toBe(200);

    const refs = await page.evaluate(() =>
      [
        ...[...document.querySelectorAll('a[href]')].map((e) => ['a', e.getAttribute('href')!]),
        ...[...document.querySelectorAll('link[href]')].map((e) => [
          'link',
          e.getAttribute('href')!,
        ]),
        ...[...document.querySelectorAll('[src]')].map((e) => ['src', e.getAttribute('src')!]),
      ].filter(([, v]) => !v.startsWith('#') && !v.startsWith('data:')),
    );
    for (const [kind, ref] of refs) {
      const url = new URL(ref!, page.url());
      if (url.host !== new URL(page.url()).host || !url.pathname.startsWith(BASE)) {
        bad.push(`${path}: ${kind} ${ref}`);
        continue;
      }
      if (kind === 'a') {
        if (!seen.has(url.pathname)) queue.push(url.pathname);
      } else if (!checked.has(url.pathname)) {
        checked.set(url.pathname, (await request.get(url.href)).status());
      }
    }
  }

  expect(bad).toEqual([]);
  expect([...checked].filter(([, status]) => status !== 200)).toEqual([]);
  expect([...seen].map((p) => p.slice(BASE.length)).sort()).toEqual([...ROUTES].sort());
});
