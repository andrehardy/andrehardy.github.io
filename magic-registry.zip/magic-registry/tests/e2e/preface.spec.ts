import { test, expect, type Page } from './fixtures';

test.describe('the Preface (R-ROUTE-07, R-DATA-10)', () => {
  test('carries how to read, every glossary term in both voices, and the legend of marks', async ({
    page,
  }) => {
    await page.goto('preface/');
    await expect(page.locator('.placeholder-plate')).toHaveCount(0);
    const terms = page.locator('[data-glossary] [data-term]');
    await expect(terms).toHaveCount(9);
    await expect(page.locator('#term-vault dt')).toHaveText('The Vault', { useInnerText: true });
    await expect(page.locator('[data-legend="realms"] li')).toHaveCount(4);
    await expect(page.locator('[data-legend="verdicts"] dt')).toHaveText([
      'True to the label',
      'Misfiled',
      'An anomaly',
    ]);
    await expect(page.locator('[data-legend="results"] [data-result-mark]')).toHaveCount(5);
    await page.getByRole('button', { name: 'Read the Cipher' }).click();
    await expect(page.locator('#term-vault dt')).toHaveText('The First Tier', {
      useInnerText: true,
    });
  });
});

test.describe('glossary marginalia (R-TYPE-04)', () => {
  const note = (page: Page, term: string) =>
    page.locator(`.marks .gloss[data-gloss="${term}"] .gloss-note`).first();
  const clip = (page: Page, term: string) =>
    note(page, term).evaluate((n) => getComputedStyle(n).clipPath);

  test('a glossed word writes its meaning into the margin when pointed at', async ({
    page,
    isMobile,
  }) => {
    test.skip(isMobile, 'a pointer to hover with');
    await page.goto('archetypes/wizard/');
    expect(await clip(page, 'source')).not.toBe('inset(0px)');
    await page.locator('.marks .gloss[data-gloss="source"]').first().hover();
    await expect.poll(() => clip(page, 'source')).toBe('inset(0px)');
    await expect(note(page, 'source')).toContainText('Where a practitioner');
  });

  test('a keyboard reaches it too, and the note is read in the current voice', async ({ page }) => {
    await page.addInitScript(() => localStorage.setItem('mr-cipher', '1'));
    await page.goto('archetypes/druid/');
    await page.locator('.marks .gloss[data-gloss="being"]').first().focus();
    await expect.poll(() => clip(page, 'being')).toBe('inset(0px)');
    await expect(note(page, 'being')).toContainText('body type');
    const realm = page.locator('.marks .gloss[data-gloss="vault"]').first();
    await expect(realm.locator('> [data-layer="cipher"]')).toHaveText('The First Tier');
    const loose = await realm.evaluate((g) =>
      [...g.childNodes]
        .filter((n) => n.nodeType === Node.TEXT_NODE)
        .map((n) => n.textContent)
        .join(''),
    );
    expect(loose).not.toMatch(/\S/);
  });

  test('the note can be read with the pointer upon it, and put away with Escape (WCAG 1.4.13)', async ({
    page,
    isMobile,
  }) => {
    test.skip(isMobile, 'a pointer to hover with');
    await page.goto('archetypes/wizard/');
    const word = page.locator('.marks .gloss[data-gloss="source"]').first();
    await word.hover();
    await expect.poll(() => clip(page, 'source')).toBe('inset(0px)');
    const box = (await note(page, 'source').boundingBox())!;
    await page.mouse.move(box.x + box.width / 2, box.y + box.height - 4, { steps: 6 });
    await page.waitForTimeout(400);
    expect(await clip(page, 'source')).toBe('inset(0px)');
    await page.keyboard.press('Escape');
    await expect.poll(() => clip(page, 'source')).not.toBe('inset(0px)');

    await page.mouse.move(0, 0);
    await word.focus();
    await expect.poll(() => clip(page, 'source')).toBe('inset(0px)');
    await page.keyboard.press('Escape');
    await expect.poll(() => clip(page, 'source')).not.toBe('inset(0px)');
    await word.blur();
    await word.focus();
    await expect.poll(() => clip(page, 'source')).toBe('inset(0px)');
  });
});
