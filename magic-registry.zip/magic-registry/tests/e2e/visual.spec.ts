import { test, expect, type Page } from './fixtures';

/**
 * The visual baseline (D-30): the golden folio and the Axis, finished, in both voices.
 * Chromium on Windows with reduced motion and a fixed clock, so the moon, the reckoning and
 * every drawing-on are the same on every run. Refresh with --update-snapshots after a
 * deliberate change to the look, and say why in the phase summary.
 */
test.beforeEach(() => {
  test.skip(test.info().project.name !== 'chromium', 'the baseline is drawn in desktop Chromium');
  test.skip(process.platform !== 'win32', 'the baseline is drawn on Windows');
});

const WHEN = new Date(Date.UTC(2026, 9, 7, 12, 0, 0));

async function settle(page: Page, path: string, cipher: boolean) {
  await page.clock.setFixedTime(WHEN);
  await page.emulateMedia({ reducedMotion: 'reduce' });
  if (cipher) await page.addInitScript(() => localStorage.setItem('mr-cipher', '1'));
  await page.setViewportSize({ width: 1280, height: 900 });
  await page.goto(path);
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(250);
}

for (const cipher of [false, true]) {
  const voice = cipher ? 'cipher' : 'almanac';

  test(`the Wizard's folio, in the ${voice}`, async ({ page }) => {
    await settle(page, './archetypes/wizard/', cipher);
    await expect(page).toHaveScreenshot(`wizard-${voice}.png`, { fullPage: true, timeout: 30_000 });
  });

  test(`the Axis with its medallions, in the ${voice}`, async ({ page }) => {
    await settle(page, './', cipher);
    await expect(page.locator('section.axis')).toHaveScreenshot(`axis-${voice}.png`);
  });
}
