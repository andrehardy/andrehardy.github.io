import { test, expect } from './fixtures';
import { ROUTES } from './site';

/** A full moon, far from any build date this site is likely to carry (Meeus: 99.99% lit). */
const FULL_MOON = new Date('2026-10-26T04:12:00Z');

test('every leaf carries the moon roundel in its masthead, named for assistive technology', async ({
  page,
}) => {
  for (const route of [...ROUTES, 'no-such-leaf/']) {
    await page.goto(`./${route}`);
    const roundel = page.locator('header.masthead figure[data-moon] svg[role="img"]');
    await expect(roundel, route).toHaveCount(1);
    await expect(roundel, route).toHaveAccessibleName(/^The Moon: .+, \d+ per cent lit$/);
    await expect(page.locator('[data-moon-lit]'), route).toHaveCount(1);
  }
});

test("the roundel shows the reader's own moon, and keeps it after a turn of the leaf", async ({
  page,
}) => {
  await page.clock.setFixedTime(FULL_MOON);
  await page.goto('./');
  const roundel = page.locator('figure[data-moon] svg[role="img"]');
  await expect(roundel).toHaveAccessibleName('The Moon: Full Moon, 100 per cent lit');
  await expect(page.locator('[data-moon-name]')).toHaveText('Full Moon');
  // A full disc: the lit path runs the whole limb on both sides.
  await expect(page.locator('[data-moon-lit]')).toHaveAttribute(
    'd',
    'M20 5.5A14.5 14.5 0 0 1 20 34.5A14.5 14.5 0 0 1 20 5.5Z',
  );

  await page.getByRole('navigation').getByRole('link', { name: 'The Codex' }).click();
  await expect(page).toHaveURL(/\/codex\/$/);
  await expect(page.locator('figure[data-moon] svg[role="img"]')).toHaveAccessibleName(
    'The Moon: Full Moon, 100 per cent lit',
  );
  await expect(page.locator('[data-moon-name]')).toHaveText('Full Moon');
});
