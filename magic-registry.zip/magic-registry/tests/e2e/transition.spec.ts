import { test, expect, type Browser, unsealed } from './fixtures';

/** The element on the current leaf that carries a view-transition name, by name. */
const named = (name: string) =>
  [...document.querySelectorAll('*')]
    .filter((el) => getComputedStyle(el).viewTransitionName === name)
    .map((el) => el.getAttribute('data-medallion') ?? el.className.toString());

test('the medallion on the Axis and the plate on the folio share one name (R-SIG-03)', async ({
  page,
}) => {
  await page.goto('./');
  const cut = await page
    .locator('svg.medallion:not(.plain)')
    .evaluateAll((ms) => ms.map((m) => m.getAttribute('data-medallion')!));
  expect(cut).toContain('wizard');
  // The archetypes whose sigils are not yet cut keep plain roundels, with no name to turn.
  await expect(page.locator('svg.medallion.plain')).toHaveCount(12 - cut.length);
  for (const id of cut) expect(await page.evaluate(named, `sigil-${id}`)).toEqual([id]);
  for (const id of cut) {
    await page.goto(`./archetypes/${id}/`);
    const onFolio = await page.evaluate(named, `sigil-${id}`);
    expect(onFolio, id).toHaveLength(1);
    expect(onFolio[0]).toContain('plate-face');
  }
});

/**
 * Opens the Wizard's folio from the Axis and records, through the swap, the animations of the
 * shared sigil: the name of each, its duration, and the turn it reaches.
 */
async function openAndRecord(browser: Browser, reducedMotion: 'reduce' | 'no-preference') {
  const context = await browser.newContext({ reducedMotion });
  await unsealed(context);
  const page = await context.newPage();
  await page.goto('./');
  const supported = await page.evaluate(() => 'startViewTransition' in document);
  await page.evaluate(() => {
    const w = window as unknown as { seen: Record<string, number>; any: number };
    w.seen = {};
    w.any = 0;
    const until = performance.now() + 3000;
    const frame = () => {
      for (const a of document.getAnimations()) {
        const effect = a.effect as KeyframeEffect | null;
        const d = effect?.getTiming().duration;
        if (typeof d !== 'number') continue;
        w.any = Math.max(w.any, d);
        const pseudo = effect?.pseudoElement ?? '';
        if (pseudo.includes('sigil-wizard')) {
          const key = `${pseudo}:${(a as CSSAnimation).animationName ?? ''}`;
          w.seen[key] = Math.max(w.seen[key] ?? 0, d);
        }
      }
      if (performance.now() < until) requestAnimationFrame(frame);
    };
    requestAnimationFrame(frame);
  });
  await page.locator('.axis a[href$="/archetypes/wizard/"]').click();
  await expect(page).toHaveURL(/\/archetypes\/wizard\/$/);
  await expect(page.locator('h1')).toHaveText('The Wizard');
  await page.waitForTimeout(3100);
  const { seen, any } = await page.evaluate(() => {
    const w = window as unknown as { seen: Record<string, number>; any: number };
    return { seen: w.seen, any: w.any };
  });
  await context.close();
  return { supported, seen, any };
}

test('opening the folio turns the sigil over like a coin (R-MOT-03)', async ({ browser }) => {
  const { supported, seen } = await openAndRecord(browser, 'no-preference');
  test.skip(!supported, 'this browser swaps leaves without a view transition');
  const coin = Object.entries(seen).find(
    ([k]) => k.startsWith('::view-transition-image-pair') && k.endsWith(':coin-turn'),
  );
  expect(coin, JSON.stringify(seen)).toBeDefined();
  expect(coin![1]).toBeGreaterThanOrEqual(1200);
});

test('the coin turns once around, about its upright axis, without growing past its size', async ({
  page,
}) => {
  await page.goto('./');
  const frames = await page.evaluate(() => {
    const rule = [...document.styleSheets]
      .flatMap((s) => [...s.cssRules])
      .find((r) => r instanceof CSSKeyframesRule && r.name === 'coin-turn') as
      CSSKeyframesRule | undefined;
    return rule ? [...rule.cssRules].map((r) => (r as CSSKeyframeRule).style.transform) : [];
  });
  expect(frames.at(0)).toMatch(/rotateY\(0deg\)/);
  expect(frames.at(-1)).toMatch(/rotateY\(360deg\)/);
  for (const f of frames) expect(f).not.toMatch(/scale/);
});

test('with reduced motion the folio opens without the turn', async ({ browser }) => {
  const { seen, any } = await openAndRecord(browser, 'reduce');
  expect(Object.values(seen).every((d) => d <= 1)).toBe(true);
  expect(any).toBeLessThanOrEqual(1);
});
