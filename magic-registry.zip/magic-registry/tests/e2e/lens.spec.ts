import { test, expect, type Page, unsealed } from './fixtures';

const WIZARD = './archetypes/wizard/';
const toggle = (page: Page) => page.getByRole('button', { name: 'Read the Cipher' });
const thesis = (page: Page) => page.locator('[data-section="thesis"] .lensed');

/** The lens follows a fine pointer; touch reads the other voice through the toggle. */
const fineOnly = async (page: Page) =>
  test.skip(
    !(await page.evaluate(() => matchMedia('(pointer: fine)').matches)),
    'needs a fine pointer',
  );

/** Rests a fine pointer in the middle of an element. */
async function rest(page: Page, selector: ReturnType<Page['locator']>) {
  await selector.scrollIntoViewIfNeeded();
  const box = (await selector.boundingBox())!;
  await page.mouse.move(box.x + box.width / 2 - 40, box.y + box.height / 2);
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2, { steps: 4 });
  return box;
}

test.describe('the reading lens (R-CIPH-02, R-VOICE-05, D-25)', () => {
  test('over a passage, a circle shows the other voice where the pointer rests', async ({
    page,
  }) => {
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.goto(WIZARD);
    await fineOnly(page);
    const host = thesis(page);
    const box = await rest(page, host);
    await expect(host).toHaveClass(/lens-on/);
    const view = host.locator('.lens-view');
    await expect(view).toBeVisible();
    await expect(view).toHaveAttribute('aria-hidden', 'true');
    await expect(view.locator('[data-lens-layer="cipher"]')).toBeVisible();
    await expect(view.locator('[data-lens-layer="almanac"]')).toBeHidden();
    await expect(view.locator('[data-lens-layer="cipher"]')).toHaveText(
      (await host.locator('[data-layer="cipher"]').textContent()) as string,
    );
    // The circle is centred on the pointer.
    const centre = await view.evaluate((v) => {
      const r = v.getBoundingClientRect();
      const s = (v.parentElement as HTMLElement).style;
      return {
        x: r.left + parseFloat(s.getPropertyValue('--lx')),
        y: r.top + parseFloat(s.getPropertyValue('--ly')),
      };
    });
    expect(Math.abs(centre.x - (box.x + box.width / 2))).toBeLessThan(2);
    expect(Math.abs(centre.y - (box.y + box.height / 2))).toBeLessThan(2);

    await page.mouse.move(2, 2);
    await expect(host).not.toHaveClass(/lens-on/);
    await expect(view).toBeHidden();
  });

  test('with the cipher on, the lens shows the almanac', async ({ page }) => {
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.goto(WIZARD);
    await fineOnly(page);
    await toggle(page).click();
    const host = thesis(page);
    await rest(page, host);
    await expect(host.locator('.lens-view [data-lens-layer="almanac"]')).toBeVisible();
    await expect(host.locator('.lens-view [data-lens-layer="cipher"]')).toBeHidden();
  });

  test('every paired passage on the folio carries the lens', async ({ page }) => {
    await page.goto(WIZARD);
    for (const section of [
      'thesis',
      'account',
      'instruments',
      'costs',
      'counterparts',
      'trials',
      'ledger',
    ])
      expect(
        await page.locator(`[data-section="${section}"] [data-lens]`).count(),
        section,
      ).toBeGreaterThan(0);
    // Each lens carries both voices, the visible text and the other.
    for (const lens of await page.locator('[data-lens]').all()) {
      await expect(lens.locator(':scope > .lens-view > [data-lens-layer]')).toHaveCount(2);
    }
  });

  test('touch has no lens; the toggle serves it, and the keyboard', async ({ browser }) => {
    const context = await browser.newContext({
      hasTouch: true,
      isMobile: true,
      viewport: { width: 412, height: 915 },
    });
    await unsealed(context);
    const page = await context.newPage();
    await page.goto(WIZARD);
    const host = thesis(page);
    await host.scrollIntoViewIfNeeded();
    await host.tap();
    await expect(host).not.toHaveClass(/lens-on/);
    await toggle(page).tap();
    await expect(host.locator('[data-layer="cipher"]')).toBeVisible();
    await context.close();
  });
});

test.describe('the lantern (R-CIPH-01)', () => {
  test('turning the cipher casts its light across the leaf, and the new voice inks in', async ({
    page,
  }) => {
    await page.goto(WIZARD);
    await toggle(page).click();
    await expect(page.locator('.lantern-sweep')).toHaveCount(1);
    await expect(page.locator('.lantern-sweep')).toHaveAttribute('aria-hidden', 'true');
    await expect(page.locator('html')).toHaveClass(/lantern-lit/);
    await expect(page.locator('html')).toHaveClass(/to-cipher/);
    const ink = await page
      .locator('[data-section="thesis"] .thesis [data-layer="cipher"]')
      .evaluate((el) => getComputedStyle(el).animationName);
    expect(ink).toBe('iron-gall');
    await expect(page.locator('.lantern-sweep')).toHaveCount(0, { timeout: 4000 });
    await expect(page.locator('html')).not.toHaveClass(/lantern-lit/, { timeout: 4000 });

    await toggle(page).click();
    await expect(page.locator('html')).toHaveClass(/to-almanac/);
  });

  test('under reduced motion the voice simply changes', async ({ page }) => {
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.goto(WIZARD);
    // Everything the click does is recorded as it happens, so a light that comes and goes is seen.
    await page.evaluate(() => {
      const seen: string[] = [];
      (window as unknown as { lanternSeen: string[] }).lanternSeen = seen;
      new MutationObserver((records) => {
        for (const r of records) {
          for (const n of r.addedNodes)
            if (n instanceof Element && n.classList.contains('lantern-sweep')) seen.push('sweep');
          if (
            r.attributeName === 'class' &&
            document.documentElement.classList.contains('lantern-lit')
          )
            seen.push('lit');
        }
      }).observe(document.documentElement, { subtree: true, childList: true, attributes: true });
    });
    await toggle(page).click();
    await expect(page.locator('html')).toHaveAttribute('data-cipher', '');
    // Read the record only after the light's whole life (1.9 s), so a late light is seen too.
    await page.waitForTimeout(2200);
    const seen = await page.evaluate(
      () => (window as unknown as { lanternSeen: string[] }).lanternSeen,
    );
    expect(seen).toEqual([]);
  });
});
