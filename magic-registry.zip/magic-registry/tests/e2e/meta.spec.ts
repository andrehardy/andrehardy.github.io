import { test, expect } from './fixtures';

/** The cards a shared leaf carries, and the device in the tab (R-PH9-01). */
for (const [route, card] of [
  ['', 'registry'],
  ['ledger/', 'registry'],
  ['archetypes/witch/', 'witch'],
  ['archetypes/bard/', 'bard'],
] as const) {
  test(`/${route} is shared with the ${card} card`, async ({ page, request }) => {
    await page.goto(`./${route}`);
    const meta = (key: string) =>
      page.locator(`meta[property="${key}"], meta[name="${key}"]`).getAttribute('content');
    const image = await meta('og:image');
    expect(image).toMatch(
      new RegExp(`^https://andrehardy\\.github\\.io/magic-registry/og/${card}\\.jpg$`),
    );
    expect(await meta('og:title')).toBe(await page.title());
    expect(await meta('og:url')).toBe(`https://andrehardy.github.io/magic-registry/${route}`);
    expect(await meta('twitter:card')).toBe('summary_large_image');
    const alt = await meta('og:image:alt');
    expect(alt).toMatch(
      card === 'registry' ? /^The Magic Registry: / : new RegExp(`^The ${card}, `, 'i'),
    );
    expect(await meta('twitter:image:alt')).toBe(alt);
    const png = await request.get(new URL(image!).pathname);
    expect(png.status()).toBe(200);
    expect(png.headers()['content-type']).toContain('image/jpeg');
  });
}

test('a lost leaf announces no address of its own', async ({ page }) => {
  await page.goto('./no-such-leaf/');
  await expect(page.locator('meta[property="og:url"]')).toHaveCount(0);
  await expect(page.locator('meta[property="og:image"]')).toHaveCount(1);
});

test('the tab carries the registry device', async ({ page, request }) => {
  await page.goto('./');
  const href = await page.locator('link[rel="icon"]').getAttribute('href');
  expect(href).toBe('/magic-registry/favicon.svg');
  const svg = await request.get(href!);
  expect(svg.status()).toBe(200);
});
