import { test, expect } from './fixtures';
import AxeBuilder from '@axe-core/playwright';
import { readdirSync, statSync } from 'node:fs';
import { join, relative, sep } from 'node:path';
import { ARCHETYPE_PALETTES, isLight, type ArchetypeId } from '../../src/data/palettes';
import { ARCHETYPES, AXIS, CONFIRMED_PORTRAYALS, ROUTES, TRIALS } from './site';

/** Every index.html in dist/, as a path below the base. */
function builtPages(dir = 'dist'): string[] {
  const out: string[] = [];
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    if (statSync(full).isDirectory()) out.push(...builtPages(full));
    else if (name === 'index.html')
      out.push(relative('dist', dir).split(sep).join('/').replace(/(.)$/, '$1/'));
  }
  return out;
}

test('the build publishes exactly the planned routes, and no essay pages', () => {
  expect(builtPages().sort()).toEqual([...ROUTES].sort());
});

for (const route of ROUTES) {
  test(`/${route} renders as an almanac leaf with no accessibility violations`, async ({
    page,
  }) => {
    const response = await page.goto(`./${route}`);
    expect(response?.status()).toBe(200);
    await expect(page.locator('h1')).toHaveCount(1);
    await expect(page).toHaveTitle(/The Magic Registry/);
    await expect(page.locator('.running-head').first()).toBeVisible();
    // A finished plate where its folio is composed (src/folios), a plate on the bench where a
    // leaf is still sealed, and none on the registers or the Preface.
    const register = /^(codex|ledger|trials|preface)\//.test(route);
    await expect(page.locator('.placeholder-plate, figure.plate')).toHaveCount(register ? 0 : 1);
    const results = await new AxeBuilder({ page }).analyze();
    expect(results.violations).toEqual([]);
  });
}

test('the composed Wizard folio read in the cipher, every piece finished, has no accessibility violations', async ({
  page,
}) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.addInitScript(() => localStorage.setItem('mr-cipher', '1'));
  await page.goto('./archetypes/wizard/');
  await expect(page.locator('html')).toHaveAttribute('data-cipher', '');
  const results = await new AxeBuilder({ page }).analyze();
  expect(results.violations).toEqual([]);
});

test('each folio stands on its own archetype ground', async ({ page }) => {
  for (const id of ARCHETYPES) {
    await page.goto(`./archetypes/${id}/`);
    const body = page.locator('body');
    await expect(body).toHaveAttribute('data-archetype', id);
    const sheet = isLight(ARCHETYPE_PALETTES[id as ArchetypeId].ground) ? 'paper' : 'paper-dark';
    await expect(body).toHaveClass(new RegExp(`(^|\\s)${sheet}(\\s|$)`));
    const ground = await body.evaluate((el) => getComputedStyle(el).backgroundColor);
    const hex = ARCHETYPE_PALETTES[id as ArchetypeId].ground;
    const rgb = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16)).join(', ');
    expect(ground, id).toBe(`rgb(${rgb})`);
  }
});

test('every page carries a unique folio, in book order', async ({ page }) => {
  const byAxis = [...ARCHETYPES].sort((a, b) => AXIS[b]! - AXIS[a]! || a.localeCompare(b));
  const expected: Record<string, string> = { 'preface/': 'i' };
  [
    '',
    ...byAxis.map((id) => `archetypes/${id}/`),
    'codex/',
    'trials/',
    ...TRIALS.map((id) => `trials/${id}/`),
    'ledger/',
    'bestiary/',
  ].forEach((r, i) => (expected[r] = String(i + 1)));
  for (const route of ROUTES) {
    await page.goto(`./${route}`);
    await expect(page.locator('.folio'), route).toHaveText(expected[route]!);
  }
});

test('the axis stands every archetype at its place, highest first', async ({ page }) => {
  await page.goto('./');
  const hrefs = await page
    .locator('.axis a')
    .evaluateAll((as) => as.map((a) => a.getAttribute('href')!));
  const byAxis = [...ARCHETYPES].sort((a, b) => AXIS[b]! - AXIS[a]!);
  expect(hrefs.map((h) => h.split('/').at(-2))).toEqual(byAxis);
});

test('the Ledger lists only confirmed portrayals, misfiled first, and never their status', async ({
  page,
}) => {
  await page.goto('./ledger/');
  const entries = page.locator('.ledger > li');
  await expect(entries).toHaveCount(CONFIRMED_PORTRAYALS.length);
  const kinds = await entries.evaluateAll((li) =>
    li.map((l) => l.getAttribute('data-verdict-kind')),
  );
  const firstOther = kinds.findIndex((k) => k !== 'misfiled');
  expect(kinds.slice(firstOther).includes('misfiled')).toBe(false);
  const html = await page.content();
  expect(html).not.toMatch(/\b(proposed|confirmed)\b/i);
});

test('the Trials index names every trial', async ({ page }) => {
  await page.goto('./trials/');
  for (const id of TRIALS) await expect(page.locator(`a[href$="/trials/${id}/"]`)).toHaveCount(1);
});

test('a missing leaf is a 404 in the almanac shell that leads back to the Axis', async ({
  page,
}) => {
  const response = await page.goto('./no-such-leaf/');
  expect(response?.status()).toBe(404);
  await expect(page.locator('h1')).toHaveText('A Missing Leaf');
  await expect(page).toHaveTitle('A Missing Leaf · The Magic Registry');
  await expect(page.locator('.masthead')).toBeVisible();
  const results = await new AxeBuilder({ page }).analyze();
  expect(results.violations).toEqual([]);
  await page.getByRole('link', { name: 'Return to the Axis Mundi' }).click();
  await expect(page).toHaveURL(/\/magic-registry\/$/);
});
