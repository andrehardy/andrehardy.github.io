import { test, expect } from './fixtures';
import { lint } from '../unit/voice-lint';
import { ROUTES } from './site';

/**
 * The voice lint, run on every rendered page in both voices (R-PH3-08): navigation, captions
 * and labels obey the same rules as the content they frame.
 */
for (const route of [...ROUTES, 'no-such-leaf/']) {
  test(`/${route} keeps the registry voice, in the almanac and in the cipher`, async ({ page }) => {
    await page.goto(`./${route}`);
    const failures: string[] = [];
    const head = await page.evaluate(
      () =>
        `${document.title}\n${document.querySelector('meta[name="description"]')?.getAttribute('content') ?? ''}`,
    );
    failures.push(...lint(head, 'almanac').map((f) => `head: ${f}`));
    const almanac = await page.locator('body').innerText();
    failures.push(...lint(almanac, 'almanac').map((f) => `almanac: ${f}`));
    // a stray escape from a script (such as `n) must never reach the page
    expect(almanac).not.toMatch(/`/);
    await page.getByRole('button', { name: 'Read the Cipher' }).click();
    const cipher = await page.locator('body').innerText();
    failures.push(...lint(cipher, 'cipher').map((f) => `cipher: ${f}`));
    expect(cipher).not.toMatch(/`/);
    expect(failures).toEqual([]);
  });
}
