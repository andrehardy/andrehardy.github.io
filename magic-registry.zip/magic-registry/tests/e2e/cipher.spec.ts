import { test, expect, type Browser, type Page, unsealed } from './fixtures';

const toggle = (page: Page) => page.getByRole('button', { name: 'Read the Cipher' });
/** The Vault's band on the Axis, in each voice. */
const vaultAlmanac = (page: Page) =>
  page.locator('[data-realm-band="vault"] .band-name [data-layer="almanac"]');
const vaultCipher = (page: Page) =>
  page.locator('[data-realm-band="vault"] .band-name [data-layer="cipher"]');

test('the almanac voice is the default', async ({ page }) => {
  await page.goto('./');
  await expect(page.locator('html')).not.toHaveAttribute('data-cipher');
  await expect(toggle(page)).toHaveAttribute('aria-pressed', 'false');
  await expect(vaultAlmanac(page)).toBeVisible();
  await expect(vaultCipher(page)).toBeHidden();
});

test('the toggle turns every passage to the cipher, and back', async ({ page }) => {
  await page.goto('./');
  await toggle(page).click();
  await expect(page.locator('html')).toHaveAttribute('data-cipher', '');
  await expect(toggle(page)).toHaveAttribute('aria-pressed', 'true');
  await expect(vaultCipher(page)).toHaveText('The First Tier');
  await expect(vaultAlmanac(page)).toBeHidden();
  expect(await page.evaluate(() => localStorage.getItem('mr-cipher'))).toBe('1');

  await toggle(page).click();
  await expect(page.locator('html')).not.toHaveAttribute('data-cipher');
  await expect(vaultAlmanac(page)).toBeVisible();
  expect(await page.evaluate(() => localStorage.getItem('mr-cipher'))).toBe('0');
});

test('the choice is applied before the page is first drawn, so the other voice never flashes', async ({
  page,
}) => {
  // Record whether the cipher was already chosen at the moment <body> is parsed.
  await page.addInitScript(() => {
    new MutationObserver((_, observer) => {
      if (!document.body) return;
      (window as unknown as { cipherAtBody: boolean }).cipherAtBody =
        document.documentElement.hasAttribute('data-cipher');
      observer.disconnect();
    }).observe(document, { childList: true, subtree: true });
  });
  await page.goto('./');
  await toggle(page).click();
  await page.reload();
  expect(
    await page.evaluate(() => (window as unknown as { cipherAtBody: boolean }).cipherAtBody),
  ).toBe(true);
  await expect(toggle(page)).toHaveAttribute('aria-pressed', 'true');
  await expect(vaultCipher(page)).toBeVisible();
});

test('the choice survives a turn of the leaf (view transition) without a full reload', async ({
  page,
}) => {
  await page.goto('./');
  await toggle(page).click();
  await page.evaluate(() => ((window as unknown as { leafMark: number }).leafMark = 7));
  await page.getByRole('navigation').getByRole('link', { name: 'The Codex' }).click();
  await expect(page).toHaveURL(/\/codex\/$/);
  await expect(page.locator('h1')).toHaveText('The Codex');
  // The same document: the router swapped the leaf rather than loading a new page.
  expect(await page.evaluate(() => (window as unknown as { leafMark?: number }).leafMark)).toBe(7);
  await expect(page.locator('html')).toHaveAttribute('data-cipher', '');
  await expect(toggle(page)).toHaveAttribute('aria-pressed', 'true');
  await expect(page.locator('th [data-layer="cipher"]').first()).toBeVisible();
  await expect(page.locator('th [data-layer="almanac"]').first()).toBeHidden();

  // The toggle still works on the new leaf.
  await toggle(page).click();
  await expect(page.locator('html')).not.toHaveAttribute('data-cipher');
});

/**
 * Turns one leaf (Axis to Ledger) and records, frame by frame through the swap, the longest
 * animation on the page: every animation, and those of the view transition alone.
 */
async function turnAndRecord(browser: Browser, reducedMotion: 'reduce' | 'no-preference') {
  const context = await browser.newContext({ reducedMotion });
  await unsealed(context);
  const page = await context.newPage();
  await page.goto('./');
  const supported = await page.evaluate(() => 'startViewTransition' in document);
  await page.evaluate(() => {
    const w = window as unknown as { longest: { any: number; turn: number } };
    w.longest = { any: 0, turn: 0 };
    const until = performance.now() + 2500;
    const frame = () => {
      for (const a of document.getAnimations()) {
        const d = a.effect?.getTiming().duration;
        if (typeof d !== 'number') continue;
        w.longest.any = Math.max(w.longest.any, d);
        const pseudo = (a.effect as KeyframeEffect | null)?.pseudoElement ?? '';
        if (pseudo.startsWith('::view-transition')) w.longest.turn = Math.max(w.longest.turn, d);
      }
      if (performance.now() < until) requestAnimationFrame(frame);
    };
    requestAnimationFrame(frame);
  });
  await page.getByRole('navigation').getByRole('link', { name: 'The Ledger' }).click();
  await expect(page).toHaveURL(/\/ledger\/$/);
  await expect(page.locator('h1')).toHaveText('The Ledger');
  await page.waitForTimeout(2600);
  const longest = await page.evaluate(
    () => (window as unknown as { longest: { any: number; turn: number } }).longest,
  );
  await context.close();
  return { supported, longest };
}

test('the leaf turns as a slow fade where the browser supports view transitions', async ({
  browser,
}) => {
  const { supported, longest } = await turnAndRecord(browser, 'no-preference');
  test.skip(!supported, 'this browser swaps leaves without a view transition');
  expect(longest.turn).toBeGreaterThanOrEqual(400);
});

test('with reduced motion the leaf still turns, and nothing on it animates', async ({
  browser,
}) => {
  const { longest } = await turnAndRecord(browser, 'reduce');
  expect(longest.any).toBeLessThanOrEqual(1);
});
