import { test, expect, type Page } from './fixtures';
import { ARCHETYPE_PALETTES, GILT, REALM_PALETTES, giltFor } from '../../src/data/palettes';
import { hexToRgb } from '../../src/lib/color';

/** The specimen is served only by the proof build (see playwright.config.ts); never by dist/. */
const SPECIMEN = 'http://127.0.0.1:4332/magic-registry/specimen/';

const rgb = (hex: string) => `rgb(${hexToRgb(hex).join(', ')})`;

async function motionState(page: Page) {
  return page.evaluate(() => {
    const all = (s: string) => [...document.querySelectorAll<HTMLElement>(s)];
    const seconds = (v: string) => (v.endsWith('ms') ? parseFloat(v) / 1000 : parseFloat(v));
    return {
      ink: all('.ink-draw').map((el) => parseFloat(getComputedStyle(el).strokeDashoffset)),
      opacity: all('.rise, .settle').map((el) => Number(getComputedStyle(el).opacity)),
      transform: all('.rise, .settle').map((el) => getComputedStyle(el).transform),
      durations: all('.ink-draw, .rise, .settle').map((el) =>
        seconds(getComputedStyle(el).animationDuration),
      ),
    };
  });
}

test.describe('reduced motion', () => {
  test.use({ reducedMotion: 'reduce' });

  test('every motion rests at once in its finished, engraved state', async ({ page }, info) => {
    await page.goto(SPECIMEN);
    await page.waitForTimeout(120);
    const s = await motionState(page);
    expect(s.ink.length).toBeGreaterThan(0);
    expect(s.opacity.length).toBeGreaterThan(0);
    for (const d of s.durations) expect(d).toBeLessThanOrEqual(0.00001);
    for (const offset of s.ink) expect(offset).toBe(0);
    for (const o of s.opacity) expect(o).toBe(1);
    for (const t of s.transform) expect(['none', 'matrix(1, 0, 0, 1, 0, 0)']).toContain(t);
    await info.attach('specimen-reduced-motion', {
      body: await page.screenshot({ fullPage: true }),
      contentType: 'image/png',
    });
  });
});

test.describe('two physics', () => {
  test('the Vault rises slowly; the Mantle lands short and firm', async ({ page }) => {
    await page.goto(SPECIMEN);
    const result = await page.evaluate(() => {
      const seconds = (v: string) => (v.endsWith('ms') ? parseFloat(v) / 1000 : parseFloat(v));
      const rise = document.querySelector<HTMLElement>('.rise')!;
      const settle = document.querySelector<HTMLElement>('.settle')!;
      const anim = settle.getAnimations()[0] as CSSAnimation;
      const frames = (anim.effect as KeyframeEffect).getKeyframes();
      return {
        rise: seconds(getComputedStyle(rise).animationDuration),
        settle: seconds(getComputedStyle(settle).animationDuration),
        approach: frames[0].easing,
        lastTransform: frames[frames.length - 1].transform,
      };
    });
    expect(result.rise).toBeGreaterThanOrEqual(1.2);
    expect(result.rise).toBeLessThanOrEqual(3);
    expect(result.settle).toBeLessThan(1.2);
    // Arrives with velocity: the approach curve does not ease out to zero speed.
    const [, , x2, y2] = result.approach.match(/[\d.]+/g)!.map(Number);
    expect((1 - y2) / (1 - x2)).toBeGreaterThanOrEqual(2);
    expect(result.lastTransform).toBe('none');
  });

  test('the Mantle inks heavier and bleeds further than the Vault', async ({ page }) => {
    await page.goto(SPECIMEN);
    const ink = await page.evaluate(() => {
      const read = (realm: string) => {
        const panel = document.querySelector(`.physics [data-realm="${realm}"]`)!;
        const body = panel.querySelector<SVGPathElement>('.ink-body')!;
        const rule = panel.querySelector<HTMLElement>('.rule')!;
        return {
          swell: parseFloat(getComputedStyle(body).strokeWidth),
          filter: getComputedStyle(body).filter,
          rule: parseFloat(getComputedStyle(rule).height),
        };
      };
      return { vault: read('vault'), mantle: read('mantle') };
    });
    expect(ink.mantle.swell).toBeGreaterThan(ink.vault.swell);
    expect(ink.mantle.rule).toBeGreaterThan(ink.vault.rule);
    expect(ink.mantle.filter).toContain('ink-bleed-heavy');
    expect(ink.vault.filter).not.toContain('ink-bleed-heavy');
  });
});

test.describe('cascade', () => {
  test('rubrication takes the red of the ground it sits on', async ({ page }) => {
    await page.goto(SPECIMEN);
    for (const [id, p] of Object.entries(REALM_PALETTES)) {
      await expect(page.locator(`.realm[data-realm="${id}"] .rubric`)).toHaveCSS(
        'color',
        rgb(p.rubric),
      );
    }
  });

  test('gold follows the nearest sheet, and each ground declares its color scheme', async ({
    page,
  }) => {
    await page.goto(SPECIMEN);
    const probe = await page.evaluate(() => {
      const host = document.createElement('div');
      host.innerHTML =
        '<div class="paper-dark" id="d"><span class="gilt-text" id="gd">Or</span>' +
        '<div class="paper" id="l"><span class="gilt-text" id="gl">Or</span></div></div>';
      document.body.append(host);
      const css = (id: string) => getComputedStyle(document.getElementById(id)!);
      const scheme = (sel: string) => getComputedStyle(document.querySelector(sel)!).colorScheme;
      return {
        onDark: css('gd').backgroundImage,
        onLightInDark: css('gl').backgroundImage,
        darkScheme: css('d').colorScheme,
        lightScheme: css('l').colorScheme,
        wizard: scheme('[data-archetype="wizard"]'),
        cleric: scheme('[data-archetype="cleric"]'),
      };
    });
    expect(probe.onDark).toContain(rgb(GILT.dark.stops[0]));
    // The specimen's body is the Sealed scope, so vellum inside it takes the Sealed leaf.
    expect(probe.onLightInDark).toContain(rgb(giltFor(REALM_PALETTES.sealed).stops[0]!));
    expect(probe.darkScheme).toBe('dark');
    expect(probe.lightScheme).toBe('light');
    expect(probe.wizard).toBe('dark');
    expect(probe.cleric).toBe('light');
  });
});

test.describe('scopes on the root element (built site)', () => {
  test('a realm or archetype set on <html> wins over the stylesheet defaults', async ({ page }) => {
    await page.goto('./');
    const read = () =>
      page.evaluate(() => {
        const s = getComputedStyle(document.documentElement);
        return {
          ground: s.getPropertyValue('--ground').trim(),
          ink: s.getPropertyValue('--ink-weight').trim(),
          ease: s.getPropertyValue('--physics-ease').trim(),
          scheme: s.colorScheme,
        };
      });
    await page.evaluate(() => (document.documentElement.dataset.realm = 'mantle'));
    const mantle = await read();
    expect(mantle.ground).toBe(REALM_PALETTES.mantle.ground);
    expect(mantle.ink).toBe('1.5px');
    expect(mantle.scheme).toBe('dark');
    await page.evaluate(() => {
      delete document.documentElement.dataset.realm;
      document.documentElement.dataset.archetype = 'paladin';
    });
    const paladin = await read();
    expect(paladin.ground).toBe(ARCHETYPE_PALETTES.paladin.ground);
    expect(paladin.scheme).toBe('light');
  });

  test('vellum inside a light scope keeps that scope’s tuned gold', async ({ page }) => {
    await page.goto('./');
    const gold = await page.evaluate(() => {
      const html = document.documentElement;
      const read = (host: Element) => {
        const s = document.createElement('span');
        s.className = 'gilt-text';
        s.textContent = 'Or';
        host.append(s);
        const bg = getComputedStyle(s).backgroundImage;
        s.remove();
        return bg;
      };
      const bodyRealm = document.body.dataset.realm;
      delete document.body.dataset.realm;
      html.dataset.archetype = 'necromancer';
      const sheet = document.createElement('div');
      sheet.className = 'paper';
      document.body.append(sheet);
      const onRootScope = read(sheet);
      delete html.dataset.archetype;
      sheet.remove();
      document.body.dataset.realm = bodyRealm;
      const box = document.createElement('div');
      box.innerHTML =
        '<div data-archetype="warlock"><div class="paper" id="w"></div>' +
        '<div data-archetype="wizard"><div class="paper" id="z"></div></div></div>';
      document.body.append(box);
      return {
        onRootScope,
        nested: read(document.getElementById('w')!),
        darkInsideLight: read(document.getElementById('z')!),
      };
    });
    expect(gold.onRootScope).toContain(rgb(giltFor(ARCHETYPE_PALETTES.necromancer).stops[0]!));
    expect(gold.nested).toContain(rgb(giltFor(ARCHETYPE_PALETTES.warlock).stops[0]!));
    expect(gold.darkInsideLight).toContain(rgb(GILT.light.stops[0]!));
  });
});

test.describe('book typography (built site)', () => {
  test('old-style figures, discretionary ligatures and small caps actually render', async ({
    page,
  }) => {
    await page.goto('./');
    await page.evaluate(async () => {
      await document.fonts.load('400 40px "EB Garamond"');
      // Every sample sits at the same whole-pixel x and on its own whole-pixel row, so two
      // screenshots can differ only through their glyphs, never through sub-pixel placement.
      let row = 0;
      const make = (id: string, text: string, style: string) => {
        const el = document.createElement('span');
        el.id = id;
        el.textContent = text;
        el.style.cssText =
          `position:absolute;left:16px;top:${200 + 80 * row++}px;width:320px;height:64px;` +
          `line-height:64px;font-family:'EB Garamond';font-size:40px;white-space:nowrap;` +
          `background:#fff;color:#000;z-index:9;${style}`;
        document.body.append(el);
      };
      make('inherited', '1234567890', '');
      make('onum', '1234567890', "font-feature-settings:'onum' 1,'pnum' 1");
      make('lnum', '1234567890', "font-feature-settings:'lnum' 1,'pnum' 1");
      make('dlig-on', 'act fist', "font-feature-settings:'dlig' 1");
      make('dlig-off', 'act fist', "font-feature-settings:'dlig' 0");
      make('period', 'act fist', '');
      document.getElementById('period')!.classList.add('period');
      make('running', 'act fist', '');
      make('sc', 'Vault', 'font-variant-caps:all-small-caps;font-synthesis:none');
      make('plain', 'Vault', 'font-synthesis:none');
      await document.fonts.ready;
    });
    const shot = (id: string) => page.locator(`#${id}`).screenshot({ animations: 'disabled' });
    // Each feature exists in the shipped font: switching it changes the glyphs.
    expect((await shot('onum')).equals(await shot('lnum'))).toBe(false);
    expect((await shot('dlig-on')).equals(await shot('dlig-off'))).toBe(false);
    expect((await shot('sc')).equals(await shot('plain'))).toBe(false);
    // Running text gets old-style figures unasked; period setting adds the old ligatures,
    // which running text leaves out.
    expect((await shot('inherited')).equals(await shot('lnum'))).toBe(false);
    expect((await shot('period')).equals(await shot('dlig-off'))).toBe(false);
    expect((await shot('running')).equals(await shot('dlig-off'))).toBe(true);
  });
});
