import { test, expect, type Page } from './fixtures';
import { ARCHETYPES, AXIS } from './site';

const NEXT = 'Tab';
/**
 * WebKit tabs to links only when the reader turns on "Press Tab to highlight each item";
 * Playwright's WebKit cannot, so a tab walk is proven in Chromium and Firefox.
 */
const tabWalk = (browserName: string) =>
  test.skip(browserName === 'webkit', 'WebKit does not tab to links by default');

/** Describes whatever holds the focus: its tag, role and accessible text. */
const focused = (page: Page) =>
  page.evaluate(() => {
    const el = document.activeElement as HTMLElement | null;
    return el
      ? `${el.tagName.toLowerCase()}:${(el.textContent ?? '').replace(/\s+/g, ' ').trim()}`
      : '';
  });

test('the skip link is the first stop and lands on the text', async ({ page, browserName }) => {
  tabWalk(browserName);
  await page.goto('./');
  await page.keyboard.press(NEXT);
  expect(await focused(page)).toBe('a:Skip to the text');
  const box = await page.locator('.skip-link').boundingBox();
  expect(box && box.y >= 0).toBe(true);
  await page.keyboard.press('Enter');
  await expect(page.locator('main#text')).toBeFocused();
});

test('the masthead is walked in a fixed order: imprint, the cipher, the sound, then the sections', async ({
  page,
  browserName,
}) => {
  tabWalk(browserName);
  await page.goto('./');
  const stops: string[] = [];
  for (let i = 0; i < 10; i++) {
    await page.keyboard.press(NEXT);
    stops.push(await focused(page));
  }
  expect(stops).toEqual([
    'a:Skip to the text',
    'a:The Magic Registry',
    'button:Read the Cipher',
    'button:Sound',
    'a:Preface',
    'a:The Axis Mundi',
    'a:The Codex',
    'a:The Trials',
    'a:The Ledger',
    'a:The Bestiary',
  ]);
});

/** The focused element's ring: its style, width, opacity and contrast against the page ground. */
const ring = (page: Page) =>
  page.evaluate(() => {
    const rgba = (c: string) => {
      const n = (c.match(/[\d.]+/g) ?? []).map(Number);
      const scale = c.startsWith('color(') ? 255 : 1;
      return {
        rgb: n.slice(0, 3).map((v) => v * scale),
        alpha: n.length > 3 ? n[3]! : 1,
      };
    };
    const lum = ([r, g, b]: number[]) => {
      const lin = (v: number) => {
        const s = v / 255;
        return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
      };
      return 0.2126 * lin(r!) + 0.7152 * lin(g!) + 0.0722 * lin(b!);
    };
    const s = getComputedStyle(document.activeElement!);
    const line = rgba(s.outlineColor);
    // The ring is seen against the nearest ground laid under it: a zone's, or the leaf's own.
    let under: Element | null = document.activeElement!.parentElement;
    while (
      under &&
      under !== document.body &&
      rgba(getComputedStyle(under).backgroundColor).alpha < 1
    )
      under = under.parentElement;
    const ground = rgba(getComputedStyle(under ?? document.body).backgroundColor);
    const [hi, lo] = [lum(line.rgb), lum(ground.rgb)].sort((a, b) => b - a);
    return {
      style: s.outlineStyle,
      width: parseFloat(s.outlineWidth),
      alpha: line.alpha,
      contrast: (hi! + 0.05) / (lo! + 0.05),
    };
  });

/** Every element the reader can Tab to on the leaf as it is shown. */
const tabbable = (page: Page) =>
  page.evaluate(
    () =>
      [
        ...document.querySelectorAll<HTMLElement>(
          'a[href], button, input, select, textarea, [tabindex]',
        ),
      ].filter(
        (el) =>
          el.tabIndex >= 0 &&
          !el.closest('[inert], [aria-hidden="true"]') &&
          el.getClientRects().length > 0,
      ).length,
  );

for (const [start, least] of [
  ['./', 9 + ARCHETYPES.length],
  // The masthead, two counterparts and two trials at the least (R-PH4-08).
  ['./archetypes/wizard/', 13],
] as const) {
  test(`every stop on ${start} shows a solid focus ring that stands 3:1 off the ground`, async ({
    page,
    browserName,
  }) => {
    tabWalk(browserName);
    await page.goto(start);
    const stops = await tabbable(page);
    expect(stops).toBeGreaterThanOrEqual(least);
    for (let i = 0; i < stops; i++) {
      await page.keyboard.press(NEXT);
      const r = await ring(page);
      expect(r.style, `stop ${i + 1}`).not.toBe('none');
      expect(r.width, `stop ${i + 1}`).toBeGreaterThan(0);
      expect(r.alpha, `stop ${i + 1}`).toBe(1);
      expect(r.contrast, `stop ${i + 1}`).toBeGreaterThanOrEqual(3);
    }
  });
}

test('the cipher toggles from the keyboard', async ({ page }) => {
  await page.goto('./');
  await page.getByRole('button', { name: 'Read the Cipher' }).focus();
  await page.keyboard.press('Space');
  await expect(page.locator('html')).toHaveAttribute('data-cipher', '');
  await page.keyboard.press('Enter');
  await expect(page.locator('html')).not.toHaveAttribute('data-cipher');
});

test('after the masthead, Tab walks the twelve folios down the axis, highest first', async ({
  page,
  browserName,
}) => {
  tabWalk(browserName);
  await page.goto('./');
  for (let i = 0; i < 10; i++) await page.keyboard.press(NEXT);
  const stops: string[] = [];
  for (let i = 0; i < ARCHETYPES.length; i++) {
    await page.keyboard.press(NEXT);
    stops.push(
      await page.evaluate(
        () => document.activeElement?.getAttribute('href')?.split('/').at(-2) ?? '',
      ),
    );
  }
  const descending = [...ARCHETYPES].sort((a, b) => AXIS[b]! - AXIS[a]! || a.localeCompare(b));
  expect(stops).toEqual(descending);
});

test('every folio on the axis can be reached and opened from the keyboard', async ({ page }) => {
  await page.goto('./');
  const links = page.locator('.axis a');
  await expect(links).toHaveCount(ARCHETYPES.length);
  await links.last().focus();
  await page.keyboard.press('Enter');
  await expect(page).toHaveURL(/\/archetypes\/[a-z]+\/$/);
  await expect(page.locator('h1')).toBeVisible();
});

test('the sections are reached from the keyboard on every kind of leaf', async ({ page }) => {
  for (const start of ['./', './archetypes/necromancer/', './trials/glass/']) {
    await page.goto(start);
    await page.getByRole('navigation').getByRole('link', { name: 'The Trials' }).focus();
    await page.keyboard.press('Enter');
    await expect(page).toHaveURL(/\/trials\/$/);
    await expect(
      page.getByRole('navigation').getByRole('link', { name: 'The Trials' }),
    ).toHaveAttribute('aria-current', 'page');
  }
});
