import { test, expect, type Page, unsealed } from './fixtures';

/** The folios composed in Phase 6, with the cursor each carries (identity.cursor). */
const FOLIOS = [
  { id: 'cleric', cursor: 'soft-halo' },
  { id: 'paladin', cursor: 'steel-mote' },
  { id: 'shaman', cursor: 'ochre-handprint' },
  { id: 'druid', cursor: 'sprouting-spores' },
  { id: 'witch', cursor: 'ash-and-seed' },
  { id: 'enchantress', cursor: 'mirrored-pearl' },
  { id: 'warlock', cursor: 'crimson-nib' },
  { id: 'necromancer', cursor: 'puppet-crossbar' },
  { id: 'bard', cursor: 'resonant-waveform' },
  { id: 'sorcerer', cursor: 'crackling-ember' },
  { id: 'alchemist', cursor: 'transmuting-droplet' },
] as const;

const leaf = (id: string) => `./archetypes/${id}/`;
const fine = (page: Page) => page.evaluate(() => matchMedia('(pointer: fine)').matches);
const fineOnly = async (page: Page) => test.skip(!(await fine(page)), 'needs a fine pointer');

const delayOf = (style: string | null) => Number(/--delay:\s*([\d.]+)s/.exec(style ?? '')?.[1]);

for (const { id, cursor } of FOLIOS) {
  test.describe(`the ${id}'s folio`, () => {
    test('stands whole: every section in order, the plate, the trials and the ledger', async ({
      page,
    }) => {
      await page.emulateMedia({ reducedMotion: 'reduce' });
      await page.goto(leaf(id));
      const order = await page
        .locator('article [data-section]')
        .evaluateAll((s) => s.map((x) => x.getAttribute('data-section')));
      expect(order).toEqual([
        'thesis',
        'account',
        'instruments',
        'costs',
        'counterparts',
        'trials',
        'ledger',
      ]);
      for (const s of await page.locator('article [data-section]').all())
        await expect(s.locator('h2')).toHaveCount(1);
      await expect(page.locator(`figure.plate g.sigil[data-sigil="${id}"]`)).toBeAttached();
      await expect(page.locator('.trial-row')).toHaveCount(2);
      const ranks = await page
        .locator('.portrayal')
        .evaluateAll((p) => p.map((x) => x.getAttribute('data-rank')));
      expect(ranks.slice(0, 2)).toEqual(['exemplar', 'runner-up']);
    });

    test('under reduced motion it is shown finished at once', async ({ page }) => {
      await page.emulateMedia({ reducedMotion: 'reduce' });
      await page.goto(leaf(id));
      await page.waitForTimeout(150);
      const running = await page.evaluate(
        () =>
          document.getAnimations().filter((a) => {
            const d = a.effect?.getTiming().duration;
            return typeof d === 'number' && d > 1;
          }).length,
      );
      expect(running).toBe(0);
      await expect(page.locator('.account-text')).toBeVisible();
      await expect(page.locator('.waiting')).toHaveCount(0);
    });

    test('its sigil is drawn mark by mark, in the order it was made', async ({ page }) => {
      await page.goto(leaf(id));
      const sigil = page.locator(`figure.plate g.sigil[data-sigil="${id}"]`);
      const steps = await sigil.locator('[data-step]').evaluateAll((els) =>
        els.map((el) => {
          const timed = el.matches('[style*="--delay"]')
            ? el
            : el.querySelector('[style*="--delay"]');
          return {
            step: Number(el.getAttribute('data-step')),
            style: timed?.getAttribute('style') ?? '',
          };
        }),
      );
      expect(steps.length).toBe(Number(await sigil.getAttribute('data-steps')));
      expect(steps.map((s) => s.step)).toEqual(steps.map((_, i) => i));
      const delays = steps.map((s) => delayOf(s.style));
      for (let i = 1; i < delays.length; i++)
        expect(delays[i]!).toBeGreaterThanOrEqual(delays[i - 1]!);
      expect(delays.at(-1)!).toBeGreaterThan(delays[0]!);
    });

    test('its initial is ornamented and gilded before the Account appears', async ({ page }) => {
      await page.goto(leaf(id));
      const versal = page.locator('.account-almanac .versal');
      await expect(versal).toHaveAttribute('aria-hidden', 'true');
      const finished = Number(await versal.getAttribute('data-finished'));
      const text = await page.locator('.account-text').evaluate((el) => {
        const s = getComputedStyle(el);
        return { name: s.animationName, delay: parseFloat(s.animationDelay) };
      });
      expect(text.name.startsWith(`${id}-`)).toBe(true);
      expect(text.delay).toBeGreaterThanOrEqual(finished);
      const gild = await versal
        .locator('.versal-text')
        .evaluate((el) => parseFloat(getComputedStyle(el).animationDelay));
      const under = await versal
        .locator('.versal-guide')
        .evaluateAll((gs) => gs.map((g) => parseFloat(getComputedStyle(g).animationDelay)));
      expect(under.length).toBeGreaterThan(0);
      expect(gild).toBeGreaterThan(Math.max(...under));
    });

    test(`a fine pointer takes its cursor (${cursor}), and leaving takes it away`, async ({
      page,
    }) => {
      await page.goto(leaf(id));
      await fineOnly(page);
      await expect(page.locator('body')).toHaveClass(new RegExp(`cursor-${cursor}`));
      expect(await page.locator('h1').evaluate((h) => getComputedStyle(h).cursor)).toMatch(
        /^url\(/,
      );
      await expect(page.locator('.cursor-trail')).toHaveAttribute('aria-hidden', 'true');
      // Headless WebKit paints a folio at a few frames a second, too slow to settle a click
      // under load; the leaving, not the click, is under test.
      await page
        .getByRole('navigation')
        .getByRole('link', { name: 'The Codex' })
        .click({ force: true });
      await expect(page).toHaveURL(/\/codex\/$/, { timeout: 20_000 });
      await expect(page.locator('body')).not.toHaveClass(new RegExp(`cursor-${cursor}`));
      await expect(page.locator('.cursor-trail')).toHaveCount(0);
    });

    test('touch and reduced motion keep the ordinary pointer', async ({ browser }) => {
      const calm = await browser.newContext({ reducedMotion: 'reduce' });
      await unsealed(calm);
      const c = await calm.newPage();
      await c.goto(leaf(id));
      await expect(c.locator('h1')).toBeVisible();
      await expect(c.locator('body')).not.toHaveClass(new RegExp(`cursor-${cursor}`));
      await calm.close();
      const touch = await browser.newContext({
        hasTouch: true,
        isMobile: true,
        viewport: { width: 412, height: 915 },
      });
      await unsealed(touch);
      const t = await touch.newPage();
      await t.goto(leaf(id));
      await expect(t.locator('body')).not.toHaveClass(new RegExp(`cursor-${cursor}`));
      await touch.close();
    });
  });
}

/** A point on the plate, in screen coordinates, from its own 600-unit field. */
const onPlate = (page: Page, selector: string, x: number, y: number) =>
  page.locator(selector).evaluate(
    (svg, [px, py]) => {
      const m = (svg as SVGSVGElement).getScreenCTM()!;
      return { x: px! * m.a + py! * m.c + m.e, y: px! * m.b + py! * m.d + m.f };
    },
    [x, y],
  );

test.describe('each folio answers the hand in its own way (R-ID-*-06)', () => {
  test("the Cleric's light burns the grime from the rose where it passes", async ({ page }) => {
    await page.goto(leaf('cleric'));
    await fineOnly(page);
    const rose = page.locator('[data-rose]');
    await rose.scrollIntoViewIfNeeded();
    await expect(rose).toHaveAttribute('data-live', '');
    const alphaAt = (fx: number, fy: number) =>
      page.locator('canvas[data-grime]').evaluate(
        (c, [x, y]) => {
          const cv = c as HTMLCanvasElement;
          const ctx = cv.getContext('2d')!;
          let sum = 0;
          const px = Math.round(cv.width * x!);
          const py = Math.round(cv.height * y!);
          const d = ctx.getImageData(px - 4, py - 4, 9, 9).data;
          for (let i = 3; i < d.length; i += 4) sum += d[i]!;
          return sum / 81;
        },
        [fx, fy],
      );
    const before = await alphaAt(0.5, 0.5);
    expect(before).toBeGreaterThan(20);
    const box = (await page.locator('canvas[data-grime]').boundingBox())!;
    await page.mouse.move(box.x + box.width * 0.3, box.y + box.height * 0.5);
    await page.mouse.move(box.x + box.width * 0.7, box.y + box.height * 0.5, { steps: 12 });
    await expect
      .poll(async () => Number(await rose.getAttribute('data-cleansed')))
      .toBeGreaterThan(3);
    expect(await alphaAt(0.5, 0.5)).toBeLessThan(before * 0.5);
  });

  test("whatever is launched at the Paladin's shield ricochets at an angle it should not take", async ({
    page,
  }) => {
    await page.goto(leaf('paladin'));
    test.skip(
      await page.evaluate(() => matchMedia('(prefers-reduced-motion: reduce)').matches),
      'motion only',
    );
    const plate = page.locator('[data-shield]');
    await plate.scrollIntoViewIfNeeded();
    await expect(plate).toHaveAttribute('data-live', '');
    const at = await onPlate(page, 'svg.arms', 40, 40);
    await page.mouse.click(at.x, at.y);
    await expect
      .poll(async () => Number(await plate.getAttribute('data-ricochets')), { timeout: 5000 })
      .toBeGreaterThan(0);
    await expect(page.locator('svg.arms .spark, svg.arms .mote').first()).toBeAttached();
  });

  test("a still hand deepens the Shaman's trance; a moving one breaks it", async ({ page }) => {
    await page.goto(leaf('shaman'));
    await fineOnly(page);
    await page.mouse.move(400, 400);
    await page.mouse.move(420, 420, { steps: 3 });
    const veil = page.locator('.trance-veil');
    await expect(veil).toHaveAttribute('aria-hidden', 'true');
    await expect
      .poll(async () => Number(await veil.getAttribute('data-depth')), { timeout: 8000 })
      .toBeGreaterThanOrEqual(3);
    for (let i = 0; i < 12; i++) await page.mouse.move(420 + i * 25, 420, { steps: 2 });
    await expect
      .poll(async () => Number(await veil.getAttribute('data-depth')), { timeout: 4000 })
      .toBeLessThanOrEqual(1);
  });

  test("the Druid's tendrils lean toward a hand, and the leaf keeps the reader's season", async ({
    page,
  }) => {
    await page.clock.setFixedTime(new Date(2026, 3, 10, 12, 0, 0));
    await page.goto(leaf('druid'));
    await expect(page.locator('.grove')).toHaveAttribute('data-season', 'spring');
    await fineOnly(page);
    const host = page.locator('[data-grove-plate]');
    await host.scrollIntoViewIfNeeded();
    await expect(host).toHaveAttribute('data-live', '');
    const tendril = page.locator('path.tendril').first();
    const rest = await tendril.getAttribute('d');
    const base = (await tendril.getAttribute('data-base'))!.split(' ').map(Number);
    const near = await onPlate(page, 'svg.seed-head', (base[0]! + 300) / 2, (base[1]! + 300) / 2);
    await page.mouse.move(near.x, near.y, { steps: 4 });
    await expect
      .poll(async () => Number(await host.getAttribute('data-reaching')))
      .toBeGreaterThan(0);
    await expect.poll(() => tendril.getAttribute('d')).not.toBe(rest);
  });
  test("a hand over the Witch's specimens makes them rustle, and the raven watches it", async ({
    page,
  }) => {
    await page.goto(leaf('witch'));
    await fineOnly(page);
    const board = page.locator('[data-board]');
    const first = board.locator('.specimen').first();
    await first.scrollIntoViewIfNeeded();
    const box = (await first.boundingBox())!;
    await page.mouse.move(box.x - 40, box.y - 40);
    await page.mouse.move(box.x + box.width / 2, box.y + 30, { steps: 6 });
    await expect
      .poll(async () => Number(await board.getAttribute('data-rustles')))
      .toBeGreaterThan(0);
    await page.locator('[data-raven]').scrollIntoViewIfNeeded();
    await expect(page.locator('[data-raven]')).toHaveAttribute('data-watching', '');
    await page.mouse.move(5, 5);
    await page.mouse.move(600, 500, { steps: 4 });
    await expect(page.locator('.raven-pupil')).toHaveAttribute('transform', /translate\(/);
  });

  test("the Enchantress's glamour parts at the hand, and her line changes when the reader looks away", async ({
    page,
  }) => {
    await page.goto(leaf('enchantress'));
    const line = page.locator('[data-glamour]');
    const before = await line.getAttribute('data-glamour');
    await page.evaluate(() => window.dispatchEvent(new Event('blur')));
    await expect(line).not.toHaveAttribute('data-glamour', before!);
    await fineOnly(page);
    const host = page.locator('[data-veiled]');
    await host.scrollIntoViewIfNeeded();
    await expect(host).toHaveAttribute('data-live', '');
    const box = (await host.boundingBox())!;
    await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2, { steps: 4 });
    await expect
      .poll(async () => Number(await host.getAttribute('data-unveiled')))
      .toBeGreaterThan(0);
    await expect(host).toHaveAttribute('data-parted', '');
  });

  test("the Warlock's contract takes a signature in red ink, and the seal comes down on it", async ({
    page,
  }) => {
    await page.goto(leaf('warlock'));
    const host = page.locator('[data-signature]');
    await host.scrollIntoViewIfNeeded();
    await expect(host).toHaveAttribute('data-live', '');
    const box = (await host.locator('svg.signature-field').boundingBox())!;
    await page.mouse.move(box.x + box.width * 0.15, box.y + box.height * 0.7);
    await page.mouse.down();
    for (let i = 1; i <= 16; i++)
      await page.mouse.move(
        box.x + box.width * (0.15 + i * 0.04),
        box.y + box.height * (0.7 - (i % 2) * 0.3),
      );
    await page.mouse.up();
    await expect(host.locator('.ink .stroke')).toHaveCount(1);
    await expect(host).toHaveAttribute('data-signed', '');
  });

  test("a string on the Necromancer's plate, taken by the hand, pulls its bone", async ({
    page,
  }) => {
    await page.goto(leaf('necromancer'));
    test.skip(
      await page.evaluate(() => matchMedia('(prefers-reduced-motion: reduce)').matches),
      'motion only',
    );
    const host = page.locator('[data-marionette]');
    await host.scrollIntoViewIfNeeded();
    await expect(host).toHaveAttribute('data-live', '');
    const string = page.locator('path.string[data-string="2"]');
    const [bx, by] = (await string.getAttribute('data-bar'))!.split(' ').map(Number);
    const [tx, ty] = (await string.getAttribute('data-tip'))!.split(' ').map(Number);
    const at = await onPlate(page, 'svg.ossuary', (bx! + tx!) / 2, (by! + ty!) / 2);
    await page.mouse.move(at.x - 60, at.y + 200);
    await page.mouse.move(at.x, at.y, { steps: 6 });
    await expect.poll(async () => Number(await host.getAttribute('data-pulls'))).toBeGreaterThan(0);
    await expect(string).toHaveClass(/taut/);
    await expect(
      page.locator('svg.ossuary [data-figure^="bone-2-"].pulled').first(),
    ).toBeAttached();
  });

  test("a hand drawn across the Bard's strings plucks them; they stay silent unless asked", async ({
    page,
  }) => {
    await page.goto(leaf('bard'));
    test.skip(
      await page.evaluate(() => matchMedia('(prefers-reduced-motion: reduce)').matches),
      'motion only',
    );
    await expect(page.locator('main [data-sound]')).toHaveAttribute('aria-pressed', 'false');
    const host = page.locator('[data-strung]');
    await expect(host).toHaveAttribute('data-live', '');
    const box = (await host.locator('svg.strings').boundingBox())!;
    await page.mouse.move(box.x + box.width / 2, box.y + 2);
    await page.mouse.move(box.x + box.width / 2, box.y + box.height - 2, { steps: 10 });
    await expect
      .poll(async () => Number(await host.getAttribute('data-plucks')))
      .toBeGreaterThanOrEqual(3);
    await expect(page.locator('[data-chladni]')).toHaveClass(/ringing/);
  });

  test("on a touch screen, a tap on the Bard's strings plucks the nearest", async ({ page }) => {
    await page.goto(leaf('bard'));
    test.skip(await fine(page), 'needs a touch screen');
    const host = page.locator('[data-strung]');
    await host.scrollIntoViewIfNeeded();
    await expect(host).toHaveAttribute('data-live', '');
    const string = page.locator('path.string').nth(2);
    const box = (await string.boundingBox())!;
    await page.touchscreen.tap(box.x + box.width / 2, box.y + box.height / 2);
    await expect(host).toHaveAttribute('data-plucks', '1');
  });
  test("the Sorcerer's charge, held and let go, flares along the scar and leaves a burn", async ({
    page,
  }) => {
    await page.goto(leaf('sorcerer'));
    test.skip(
      await page.evaluate(() => matchMedia('(prefers-reduced-motion: reduce)').matches),
      'motion only',
    );
    const host = page.locator('[data-charged]');
    await host.scrollIntoViewIfNeeded();
    await expect(host).toHaveAttribute('data-live', '');
    const at = await onPlate(page, 'svg.scar', 380, 240);
    await page.mouse.move(at.x, at.y);
    await page.mouse.down();
    await expect(host).toHaveAttribute('data-gathering', '');
    await page.waitForTimeout(500);
    await page.mouse.up();
    await expect(host).toHaveAttribute('data-flares', '1');
    await expect(host).toHaveAttribute('data-scars', '1');
    await expect(page.locator('svg.scar .burn')).toHaveCount(1);
  });

  test("the Alchemist's Work goes through its stages down the notebook, and a hand turns a metal to gold", async ({
    page,
  }) => {
    await page.goto(leaf('alchemist'));
    const book = page.locator('[data-notebook]');
    await expect(book).toHaveAttribute('data-stage', '0');
    await page.locator('[data-section="ledger"]').scrollIntoViewIfNeeded();
    await expect.poll(async () => Number(await book.getAttribute('data-stage'))).toBeGreaterThan(1);
    const lead = page.locator('svg.metal[data-metal="saturnus"]');
    await lead.scrollIntoViewIfNeeded();
    const box = (await lead.locator('xpath=ancestor::h2').boundingBox())!;
    await page.mouse.move(box.x - 30, box.y - 30);
    await page.mouse.move(box.x + 10, box.y + box.height / 2, { steps: 4 });
    await expect(lead).toHaveClass(/transmuted/);
    await expect(book).toHaveAttribute('data-transmuted', '1');
  });
});
