import { test as base, type BrowserContext } from '@playwright/test';

export { expect } from '@playwright/test';
export type { Browser, Page } from '@playwright/test';

/**
 * Every test opens a fresh reading, and the first leaf of a reading comes sealed (R-SIG-01).
 * Tests begin with the seal already broken, unless they ask for it with `sealed: true`.
 */
export const unsealed = (context: BrowserContext) =>
  context.addInitScript(() => sessionStorage.setItem('mr-unsealed', '1'));

export const test = base.extend<{ sealed: boolean }>({
  sealed: [false, { option: true }],
  context: async ({ context, sealed }, use) => {
    if (!sealed) await unsealed(context);
    await use(context);
  },
});
