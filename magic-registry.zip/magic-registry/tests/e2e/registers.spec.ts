import { test, expect } from './fixtures';
import { ARCHETYPES, AXIS, CONFIRMED_PORTRAYALS } from './site';

test.describe('the Ledger (R-ROUTE-05)', () => {
  test('stands whole, the misfiled first, and is sorted by realm, kind of work and verdict', async ({
    page,
  }) => {
    await page.goto('ledger/');
    const entries = page.locator('[data-ledger] > li');
    const visible = page.locator('[data-ledger] > li:not([hidden])');
    await expect(entries).toHaveCount(CONFIRMED_PORTRAYALS.length);
    await expect(entries.first()).toHaveAttribute('data-kind', 'misfiled');
    const form = page.locator('[data-ledger-filter]');
    await expect(form).toBeVisible();
    await expect(form).toHaveAttribute('data-shown', String(CONFIRMED_PORTRAYALS.length));

    await form.getByRole('radio', { name: 'The Deep Mantle' }).check();
    await expect(page).toHaveURL(/\?realm=mantle$/);
    const mantle = await visible.evaluateAll((els) =>
      els.map((e) => e.getAttribute('data-realm-of')),
    );
    expect(mantle.length).toBeGreaterThan(0);
    expect(new Set(mantle)).toEqual(new Set(['mantle']));
    await expect(page.locator('[data-tally]')).toContainText(
      `of the ${CONFIRMED_PORTRAYALS.length}`,
    );

    await form.getByRole('radio', { name: 'Misfiled' }).check();
    const kinds = await visible.evaluateAll((els) => els.map((e) => e.getAttribute('data-kind')));
    expect(new Set(kinds)).toEqual(new Set(['misfiled']));

    await form.getByRole('radio', { name: 'Games' }).check();
    await expect(visible).toHaveCount(0);
    await expect(page.locator('[data-ledger-none]')).toBeVisible();
  });

  test('comes back to a shared view from its address', async ({ page }) => {
    await page.goto('ledger/?filed=wizard&kind=misfiled');
    const filed = await page
      .locator('[data-ledger] > li:not([hidden])')
      .evaluateAll((els) =>
        els.map((e) => `${e.getAttribute('data-filed')} ${e.getAttribute('data-kind')}`),
      );
    expect(filed.length).toBeGreaterThan(0);
    expect(new Set(filed)).toEqual(new Set(['wizard misfiled']));
    await expect(page.locator('#ledger-practitioner')).toHaveValue('wizard');
  });

  test('never shows a review status (R-DATA-08)', async ({ page }) => {
    for (const leaf of ['ledger/', 'archetypes/wizard/', 'codex/']) {
      await page.goto(leaf);
      const text = (await page.locator('body').innerText()).toLowerCase();
      expect(text, leaf).not.toMatch(/\b(proposed|confirmed)\b/);
    }
  });

  test('presses each verdict seal with a weighty impact and a gloss (R-SIG-04)', async ({
    page,
  }) => {
    await page.goto('archetypes/wizard/');
    const seal = page.locator('.verdict-seal').first();
    await seal.scrollIntoViewIfNeeded();
    const names = await seal.evaluate((el) => [
      getComputedStyle(el.querySelector('.seal-body')!).animationName,
      getComputedStyle(el.querySelector('.seal-gloss')!).animationName,
    ]);
    expect(names).toEqual(['seal-press', 'seal-gloss']);
  });
});

test.describe('the Codex (R-ROUTE-03)', () => {
  test('opens one crossing at a time beneath the grid, and keeps it in the address', async ({
    page,
  }) => {
    await page.goto('codex/');
    const codex = page.locator('[data-codex]');
    await expect(codex).toHaveAttribute('data-live', '');
    const openers = page.locator('[data-crossing]');
    const first = await openers.first().getAttribute('data-crossing');
    await expect(page.locator(`[data-crossing-panel="${first}"]`)).toBeVisible();
    await expect(page.locator('[data-crossing-panel]:visible')).toHaveCount(1);

    const second = openers.nth(1);
    const id = await second.getAttribute('data-crossing');
    await second.click();
    await expect(second).toHaveAttribute('aria-current', 'true');
    await expect(page.locator(`[data-crossing-panel="${id}"]`)).toBeVisible();
    await expect(page.locator('[data-crossing-panel]:visible')).toHaveCount(1);
    await expect(page).toHaveURL(new RegExp(`#crossing-${id}$`));

    await page.reload();
    await expect(page.locator(`[data-crossing-panel="${id}"]`)).toBeVisible();
  });

  test('sets every practitioner in the grid exactly where it belongs', async ({ page }) => {
    await page.goto('codex/');
    const placed = await page
      .locator('[data-codex-grid] [data-medallion]')
      .evaluateAll((els) => [...new Set(els.map((e) => e.getAttribute('data-medallion')))]);
    expect(placed.sort()).toEqual([...ARCHETYPES].sort());
  });

  test('marks the row and column the hand is on', async ({ page, isMobile }) => {
    test.skip(isMobile, 'a mouse');
    await page.goto('codex/');
    const cell = page.locator('[data-codex-grid] td[data-row="0"][data-col="1"]');
    await cell.hover();
    const grid = page.locator('[data-codex-grid]');
    await expect(grid).toHaveAttribute('data-at-row', '0');
    await expect(grid).toHaveAttribute('data-at-col', '1');
  });
});

test.describe('the Trials (R-ROUTE-04)', () => {
  test('sets all twelve side by side in axis order, each outcome with its sign', async ({
    page,
  }) => {
    await page.goto('trials/glass/');
    const ids = await page
      .locator('[data-outcome]')
      .evaluateAll((els) => els.map((e) => e.getAttribute('data-outcome')!));
    expect(ids).toHaveLength(12);
    const descending = [...ids].sort((a, b) => AXIS[b]! - AXIS[a]!);
    expect(ids.map((id) => AXIS[id])).toEqual(descending.map((id) => AXIS[id]));
    for (const li of await page.locator('[data-outcome]').all()) {
      const kind = await li.getAttribute('data-result');
      await expect(li.locator(`[data-result-mark="${kind}"]`)).toHaveCount(1);
    }
    await expect(page.locator('.tally-words')).toContainText(/moved/i);
  });

  test('sets the outcomes down in turn, and at once where stillness is asked', async ({
    page,
    browser,
  }) => {
    await page.goto('trials/glass/');
    const set = await page
      .locator('[data-outcome]')
      .evaluateAll((els) =>
        els.map(
          (e) =>
            [
              getComputedStyle(e).animationName,
              parseFloat(getComputedStyle(e).animationDelay),
            ] as const,
        ),
      );
    expect(set).toHaveLength(12);
    expect(set.every(([name]) => name === 'trial-set')).toBe(true);
    for (let i = 1; i < set.length; i++) expect(set[i]![1]).toBeGreaterThan(set[i - 1]![1]);

    const calm = await browser.newContext({ reducedMotion: 'reduce' });
    await calm.addInitScript(() => sessionStorage.setItem('mr-unsealed', '1'));
    const still = await calm.newPage();
    await still.goto(new URL('trials/glass/', test.info().project.use.baseURL!).href);
    const last = still.locator('[data-outcome]').last();
    await expect.poll(() => last.evaluate((el) => getComputedStyle(el).opacity)).toBe('1');
    await calm.close();
  });

  test('the index shows each trial as a row of twelve signs, with its tally in words', async ({
    page,
  }) => {
    await page.goto('trials/');
    for (const row of await page.locator('[data-trial]').all()) {
      await expect(row.locator('[data-result-mark]')).toHaveCount(12);
      await expect(row.locator('.tally-words')).toHaveText(/\.$/);
    }
  });
});
