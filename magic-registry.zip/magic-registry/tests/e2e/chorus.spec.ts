import { test, expect, type Page } from './fixtures';

const root = (page: Page) => page.locator('html');
const switchOf = (page: Page) => page.locator('.masthead button[data-sound]');

test.describe('sound (R-FLO-*-SND)', () => {
  test('is silent until the reader asks, then speaks for the ground beneath', async ({
    page,
    browserName,
  }) => {
    await page.goto('./');
    await expect(switchOf(page)).toHaveAttribute('aria-pressed', 'false');
    await expect(root(page)).not.toHaveAttribute('data-sound-on', /.*/);
    await expect(root(page)).not.toHaveAttribute('data-sound-voice', /.*/);

    await switchOf(page).click();
    await expect(switchOf(page)).toHaveAttribute('aria-pressed', 'true');
    await expect(root(page)).toHaveAttribute('data-sound-on', '');
    if (browserName === 'chromium')
      await expect(root(page)).toHaveAttribute('data-sound-voice', 'vault');

    await page.locator('a[href$="/archetypes/wizard/"]').first().click();
    await expect(page).toHaveURL(/archetypes\/wizard\/$/);
    await expect(switchOf(page)).toHaveAttribute('aria-pressed', 'true');
    if (browserName === 'chromium')
      await expect(root(page)).toHaveAttribute('data-sound-voice', 'wizard');

    await switchOf(page).click();
    await expect(switchOf(page)).toHaveAttribute('aria-pressed', 'false');
    await expect(root(page)).not.toHaveAttribute('data-sound-voice', /.*/);
  });

  test("is one switch: the Bard's own follows the masthead's", async ({ page }) => {
    await page.goto('archetypes/bard/');
    const own = page.locator('main button[data-sound]');
    await expect(own).toHaveAttribute('aria-pressed', 'false');
    await switchOf(page).click();
    await expect(own).toHaveAttribute('aria-pressed', 'true');
    await own.click();
    await expect(switchOf(page)).toHaveAttribute('aria-pressed', 'false');
  });
});

test.describe('the specular gold (R-MAT-02)', () => {
  test('turns its light toward the hand', async ({ page, isMobile }) => {
    test.skip(isMobile, 'with a mouse; a phone tilts instead');
    await page.goto('./');
    const leaf = page.locator('.gilt-text, .gilt-surface').first();
    const box = (await leaf.boundingBox())!;
    await page.mouse.move(box.x + box.width * 0.9, box.y + box.height * 0.5);
    await expect
      .poll(() => leaf.evaluate((el) => el.style.getPropertyValue('--gx')))
      .toMatch(/^8\d|^9\d/);
    await page.mouse.move(box.x + box.width * 0.1, box.y + box.height * 0.5);
    await expect
      .poll(() => leaf.evaluate((el) => el.style.getPropertyValue('--gx')))
      .toMatch(/^\d\.|^1\d\./);
  });
});

test.describe('the quill (R-SIG-02)', () => {
  test('writes on every leaf but a folio, and lets fall gold over the Vault', async ({
    page,
    isMobile,
  }) => {
    test.skip(isMobile, 'a mouse cursor');
    await page.goto('./');
    await expect(page.locator('body')).toHaveClass(/cursor-quill/);
    const vault = page.locator('[data-zone="vault"] .entry').first();
    await vault.scrollIntoViewIfNeeded();
    const box = (await vault.boundingBox())!;
    for (let i = 0; i < 6; i++) await page.mouse.move(box.x + 20 + i * 40, box.y + box.height / 2);
    const mote = page.locator('.ink-motes .ink-mote').last();
    await expect(mote).toHaveAttribute('data-tone', 'gold');

    await page.goto('archetypes/druid/');
    await expect(page.locator('body')).not.toHaveClass(/cursor-quill/);
    await expect(page.locator('.ink-motes')).toHaveCount(0);
  });

  test('lets fall iron-red over the Mantle', async ({ page, isMobile }) => {
    test.skip(isMobile, 'a mouse cursor');
    await page.goto('./');
    const mantle = page.locator('[data-zone="mantle"] .entry').first();
    await mantle.scrollIntoViewIfNeeded();
    const box = (await mantle.boundingBox())!;
    for (let i = 0; i < 6; i++) await page.mouse.move(box.x + 20 + i * 40, box.y + box.height / 2);
    await expect(page.locator('.ink-motes .ink-mote').last()).toHaveAttribute('data-tone', 'iron');
  });

  test('drops no ink where stillness is asked', async ({ page, isMobile }) => {
    test.skip(isMobile, 'a mouse cursor');
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.goto('./');
    await expect(page.locator('body')).toHaveClass(/cursor-quill/);
    await expect(page.locator('.ink-motes')).toHaveCount(0);
  });
});

test.describe('the seal (R-SIG-01)', () => {
  test.use({ sealed: true });

  const watchSeal = (page: Page) =>
    page.addInitScript(() => {
      const w = window as unknown as { __seal: number[] };
      w.__seal = [];
      new MutationObserver(() => {
        const on = document.documentElement.classList.contains('unsealing');
        if (on !== Boolean(w.__seal.length % 2)) w.__seal.push(performance.now());
      }).observe(document, { subtree: true, attributes: true, attributeFilter: ['class'] });
    });
  const times = (page: Page) =>
    page.evaluate(() => (window as unknown as { __seal: number[] }).__seal);

  test('breaks on the first leaf of a reading, in under two seconds, and only once', async ({
    page,
  }) => {
    await watchSeal(page);
    await page.goto('./', { waitUntil: 'domcontentloaded' });
    // The seal as seen: the veil's own fade, which a busy machine cannot stretch.
    const veil = await page.evaluate(() =>
      document
        .getAnimations()
        .filter((a) => (a as CSSAnimation).animationName === 'seal-veil')
        .map((a) => Number(a.effect!.getComputedTiming().endTime)),
    );
    expect(veil).toHaveLength(1);
    expect(veil[0]).toBeLessThan(2000);
    await expect.poll(() => times(page).then((t) => t.length), { timeout: 5000 }).toBe(2);
    await page.goto('ledger/');
    await page.waitForTimeout(300);
    expect(await times(page)).toEqual([]);
    await expect(root(page)).not.toHaveClass(/unsealing/);
  });

  test('gives way at once to a click', async ({ page }) => {
    await watchSeal(page);
    await page.goto('./', { waitUntil: 'domcontentloaded' });
    await page.mouse.click(5, 5);
    await expect.poll(() => times(page).then((t) => t.length)).toBe(2);
    const [on, off] = await times(page);
    expect(off! - on!).toBeLessThan(1500);
  });

  test('is never pressed where stillness is asked', async ({ page }) => {
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await watchSeal(page);
    await page.goto('./');
    await page.waitForTimeout(300);
    expect(await times(page)).toEqual([]);
  });
});
