import { test, expect } from './fixtures';
import AxeBuilder from '@axe-core/playwright';

test('home page is served under the project path', async ({ page }) => {
  const response = await page.goto('./');
  expect(response?.status()).toBe(200);
  await expect(page.locator('h1')).toContainText('Magic Registry');
});

test('home page has no accessibility violations', async ({ page }) => {
  await page.goto('./');
  const results = await new AxeBuilder({ page }).analyze();
  expect(results.violations).toEqual([]);
});

test('the design specimen is not published', async ({ page }) => {
  const response = await page.goto('./specimen/');
  expect(response?.status()).toBe(404);
});

test('every asset, including fonts, is self-hosted under the project path', async ({ page }) => {
  const foreign: string[] = [];
  const fonts: string[] = [];
  page.on('request', (req) => {
    const url = new URL(req.url());
    if (url.protocol === 'data:') return;
    if (url.host !== 'localhost:4329' || !url.pathname.startsWith('/magic-registry/')) {
      foreign.push(req.url());
    }
    if (req.resourceType() === 'font') fonts.push(url.pathname);
  });
  await page.goto('./', { waitUntil: 'networkidle' });
  await page.evaluate(() => document.fonts.ready);
  expect(foreign).toEqual([]);
  expect(fonts.length).toBeGreaterThan(0);
});
