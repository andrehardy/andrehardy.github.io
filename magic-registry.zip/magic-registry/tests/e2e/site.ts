/** The routes the almanac publishes, derived from the content so a new entry is tested at once. */
import { readFileSync, readdirSync } from 'node:fs';
import { parse } from 'yaml';

const ids = (dir: string, ext: string) =>
  readdirSync(`src/content/${dir}`)
    .filter((f) => f.endsWith(ext))
    .map((f) => f.slice(0, -ext.length))
    .sort();

export const ARCHETYPES = ids('archetypes', '.md');
export const TRIALS = ids('trials', '.yaml');

/** Axis value of each archetype, read from its frontmatter. */
export const AXIS: Record<string, number> = Object.fromEntries(
  ARCHETYPES.map((id) => {
    const front = readFileSync(`src/content/archetypes/${id}.md`, 'utf8').split(/^---$/m)[1]!;
    return [id, (parse(front) as { axis: number }).axis];
  }),
);

/** Confirmed portrayals: the only ones a reader may ever see (D-23). */
export const CONFIRMED_PORTRAYALS = ids('portrayals', '.yaml').filter(
  (id) =>
    (parse(readFileSync(`src/content/portrayals/${id}.yaml`, 'utf8')) as { status: string })
      .status === 'confirmed',
);

/** Every published page, as a path below the base. */
export const ROUTES = [
  '',
  'preface/',
  ...ARCHETYPES.map((id) => `archetypes/${id}/`),
  'codex/',
  'trials/',
  ...TRIALS.map((id) => `trials/${id}/`),
  'ledger/',
  'bestiary/',
];
