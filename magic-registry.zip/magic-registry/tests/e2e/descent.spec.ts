import { test, expect, type Page } from './fixtures';
import { PLANETS, meanLongitude } from '../../src/lib/sky';

/** A clear night over the eastern seaboard: 11 at night, New York time. */
const NIGHT = new Date(Date.UTC(2026, 9, 8, 3, 0, 0));

const firmament = (page: Page) => page.locator('[data-firmament]');
const toVault = (page: Page) =>
  page
    .locator('[data-realm-band="vault"]')
    .evaluate((el) => el.scrollIntoView({ block: 'center' }));

test.describe('the descent (R-DESC-01..03)', () => {
  test('goes down the axis in one run: Sealed Light, Vault, horizon, Mantle', async ({ page }) => {
    await page.goto('./');
    const zones = await page
      .locator('[data-descent] [data-zone]')
      .evaluateAll((z) => z.map((el) => el.getAttribute('data-zone')));
    expect(zones).toEqual(['sealed', 'vault', 'threshold', 'mantle']);
  });

  test('lies in six engraved planes, with the gilded meridian down the axis', async ({ page }) => {
    await page.goto('./');
    const planes = await page
      .locator('[data-descent] [data-plane]')
      .evaluateAll((p) => p.map((el) => el.getAttribute('data-plane')));
    expect(planes.sort()).toEqual(['cloud', 'horizon', 'roots', 'rays', 'stars', 'strata'].sort());
    await expect(page.locator('[data-meridian] rect')).toBeAttached();
  });

  test('the meridian inks itself down as the reader comes', async ({ page }) => {
    await page.goto('./');
    test.skip(
      await page.evaluate(() => matchMedia('(prefers-reduced-motion: reduce)').matches),
      'motion only',
    );
    const inked = () =>
      page.locator('[data-descent]').evaluate((el) => Number(el.style.getPropertyValue('--inked')));
    await expect.poll(inked).toBeLessThan(0.3);
    const before = await inked();
    await page.locator('[data-realm-band="mantle"]').scrollIntoViewIfNeeded();
    await expect.poll(inked).toBeGreaterThan(before + 0.3);
  });

  test('tells the reader why the Shaman and the Druid stand in the Vault (R-TAX-02)', async ({
    page,
  }) => {
    await page.goto('./');
    await expect(page.locator('[data-zone="vault"] .vault-head')).toContainText(
      /Shaman and the Druid.*filed in the Vault/,
    );
  });
});

test.describe("the reader's own sky (R-SKY-01, R-SKY-03, R-MOT-01)", () => {
  test.use({ timezoneId: 'America/New_York' });

  test('draws tonight’s stars above the horizon once the Vault is in view', async ({ page }) => {
    await page.clock.install({ time: NIGHT });
    await page.goto('./');
    await toVault(page);
    await page.clock.runFor(1500);
    await expect
      .poll(async () => Number(await firmament(page).getAttribute('data-stars')))
      .toBeGreaterThan(80);
    await expect(page.locator('[data-compass="0"]')).toHaveText('E');
  });

  test('a figure traces itself in; a meteor falls, never twice in a minute', async ({ page }) => {
    await page.goto('./');
    test.skip(
      await page.evaluate(() => matchMedia('(prefers-reduced-motion: reduce)').matches),
      'motion only',
    );
    await page.clock.install({ time: NIGHT });
    await page.reload();
    await toVault(page);
    await page.clock.runFor(4000);
    // The attribute is absent (null) until the stars have loaded and the first frame is drawn;
    // only then is the first meteor scheduled, so wait for a figure's name, not for "not empty".
    await expect.poll(() => firmament(page).getAttribute('data-tracing')).toMatch(/\S/);
    const meteors = async () => {
      await page.clock.runFor(100);
      return Number(await firmament(page).getAttribute('data-meteors'));
    };
    // The first falls within the first minute; the next not for at least another.
    await page.clock.fastForward(60_000);
    expect(await meteors()).toBe(1);
    await page.clock.fastForward(55_000);
    expect(await meteors()).toBe(1);
    await page.clock.fastForward(70_000);
    expect(await meteors()).toBe(2);
  });

  test('reckons the Moon’s rising for the reader’s clock', async ({ page }) => {
    await page.clock.install({ time: NIGHT });
    await page.goto('./');
    await expect(page.locator('[data-moonrise]')).toHaveText(
      /^The Moon (rises next at \d{1,2}:\d{2}|does not rise)/,
    );
  });
});

test.describe('the sky in the south', () => {
  test.use({ timezoneId: 'Australia/Sydney' });

  test('faces north, and names the points of the compass for it', async ({ page }) => {
    await page.goto('./');
    await expect(page.locator('[data-compass="0"]')).toHaveText('W');
    await expect(page.locator('[data-compass="2"]')).toHaveText('N');
  });
});

test.describe('the sky is drawn only while it can be seen (R-CHOR-06, R-CHOR-07)', () => {
  test('runs while the Vault is on screen, and stops when it scrolls away or the tab is hidden', async ({
    page,
  }) => {
    await page.setViewportSize({ width: 1000, height: 420 });
    await page.goto('./');
    await expect(firmament(page)).not.toHaveAttribute('data-running', '');
    await toVault(page);
    await expect(firmament(page)).toHaveAttribute('data-running', '');
    await page.evaluate(() => scrollTo(0, 0));
    await expect(firmament(page)).not.toHaveAttribute('data-running', '');
    await toVault(page);
    await expect(firmament(page)).toHaveAttribute('data-running', '');
    await page.evaluate(() => {
      Object.defineProperty(document, 'visibilityState', { value: 'hidden', configurable: true });
      document.dispatchEvent(new Event('visibilitychange'));
    });
    await expect(firmament(page)).not.toHaveAttribute('data-running', '');
  });

  test('a device that asks for less gets the lighter tier', async ({ page }) => {
    await page.addInitScript(() => localStorage.setItem('mr-tier', 'light'));
    await page.goto('./');
    await expect(firmament(page)).toHaveAttribute('data-tier', 'light');
  });

  test('keeps its pace: the Vault in view, frames still come smoothly', async ({ page }) => {
    test.skip(test.info().project.name !== 'chromium', 'sampled in desktop Chromium');
    await page.addInitScript(() => localStorage.setItem('mr-tier', 'full'));
    await page.goto('./');
    await toVault(page);
    await expect(firmament(page)).toHaveAttribute('data-running', '');
    const fps = await page.evaluate(
      () =>
        new Promise<number>((done) => {
          let n = 0;
          const start = performance.now();
          const tick = (t: number) => {
            n++;
            if (t - start < 1000) requestAnimationFrame(tick);
            else done((n * 1000) / (t - start));
          };
          requestAnimationFrame(tick);
        }),
    );
    expect(fps).toBeGreaterThan(30);
  });
});

test.describe('the orrery (R-SKY-04)', () => {
  test("is set for the reader's own night, not the day it was printed", async ({ page }) => {
    const later = new Date(Date.UTC(2027, 2, 1, 4));
    await page.clock.install({ time: later });
    await page.goto('./');
    const earth = PLANETS.find((p) => p.id === 'earth')!;
    const from = () =>
      page
        .locator('[data-orrery] .orbit[data-planet="earth"]')
        .evaluate((el) => parseFloat((el as SVGGElement).style.getPropertyValue('--from')));
    await expect.poll(from).toBeCloseTo(-meanLongitude(earth, later), 1);
  });

  test('turns each ring in proportion to its planet’s true period', async ({ page }) => {
    await page.goto('./');
    const turns = await page.locator('[data-orrery] .orbit').evaluateAll((orbits) =>
      orbits.map((o) => ({
        id: o.getAttribute('data-planet'),
        days: parseFloat(getComputedStyle(o).getPropertyValue('--period-days')),
        secs: parseFloat(getComputedStyle(o).animationDuration),
      })),
    );
    expect(turns.map((t) => t.id)).toEqual([
      'mercury',
      'venus',
      'earth',
      'mars',
      'jupiter',
      'saturn',
    ]);
    const reduced = await page.evaluate(
      () => matchMedia('(prefers-reduced-motion: reduce)').matches,
    );
    if (reduced) return;
    const earth = turns.find((t) => t.id === 'earth')!;
    for (const t of turns) expect(t.secs / earth.secs).toBeCloseTo(t.days / earth.days, 3);
  });
});

test.describe('the Mantle (R-EARTH-01..03)', () => {
  test('names its strata in the margin, top to bottom', async ({ page }) => {
    await page.goto('./');
    await expect(page.locator('[data-stratum] .stratum-name .smallcaps')).toHaveText([
      'Loess',
      'Shale',
      'Limestone',
      'Basalt',
      'Granite',
    ]);
  });

  test('a reader who lingers in the rock finds something surface there', async ({ page }) => {
    await page.clock.install({ time: NIGHT });
    await page.goto('./');
    await page
      .locator('[data-stratum="limestone"]')
      .evaluate((el) => el.scrollIntoView({ block: 'center' }));
    await page.clock.runFor(1000);
    await expect(page.locator('.inclusion.surfaced')).toHaveCount(0);
    await page.clock.runFor(4500);
    await expect(page.locator('[data-strata]')).toHaveAttribute('data-surfaced', '1');
    await expect(page.locator('.inclusion.surfaced')).toHaveCount(1);
  });

  test('the beds settle after a fast descent, and rest level', async ({ page }) => {
    await page.goto('./');
    test.skip(
      await page.evaluate(() => matchMedia('(prefers-reduced-motion: reduce)').matches),
      'motion only',
    );
    await page
      .locator('[data-zone="mantle"]')
      .evaluate((el) => el.scrollIntoView({ block: 'start' }));
    await page.mouse.wheel(0, -1400);
    const settle = () =>
      page
        .locator('[data-stratum="loess"]')
        .evaluate((el) => Math.abs(parseFloat(el.style.getPropertyValue('--settle')) || 0));
    await expect.poll(settle, { timeout: 3000 }).toBeGreaterThan(0.5);
    await expect.poll(settle, { timeout: 5000 }).toBeLessThan(0.06);
  });
});

test.describe('under reduced motion', () => {
  test.use({ reducedMotion: 'reduce' });

  test('the sky stands still but is there, and the meridian is inked from the first', async ({
    page,
  }) => {
    await page.clock.install({ time: NIGHT });
    await page.goto('./');
    await toVault(page);
    await page.clock.runFor(1000);
    await expect
      .poll(async () => Number(await firmament(page).getAttribute('data-stars')))
      .toBeGreaterThan(0);
    expect(await firmament(page).getAttribute('data-tracing')).toBeNull();
    expect(
      await page.locator('[data-descent]').evaluate((el) => el.style.getPropertyValue('--inked')),
    ).toBe('');
    const playing = await page
      .locator('[data-orrery] .orbit')
      .evaluateAll((o) => o.map((el) => getComputedStyle(el).animationName));
    expect(playing.every((n) => n === 'none')).toBe(true);
  });
});
