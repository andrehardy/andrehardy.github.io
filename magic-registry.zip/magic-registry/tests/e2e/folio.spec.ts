import { test, expect, type Page, unsealed } from './fixtures';
import { figures, reckon } from '../../src/lib/reckoning';

/** The Wizard's folio, the golden folio of Phase 4. */
const WIZARD = './archetypes/wizard/';

/** Hovering belongs to a fine pointer; a touch screen has no hand passing over the leaf. */
const fineOnly = async (page: Page) =>
  test.skip(
    !(await page.evaluate(() => matchMedia('(pointer: fine)').matches)),
    'needs a fine pointer',
  );

const still = async (page: Page) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.goto(WIZARD);
};

test.describe("the Wizard's folio is complete (R-PH4-03)", () => {
  test('every section stands in order, each with its heading and its margin', async ({ page }) => {
    await still(page);
    const sections = page.locator('.wizard-ledger > [data-section]');
    await expect(sections).toHaveCount(7);
    expect(await sections.evaluateAll((s) => s.map((x) => x.getAttribute('data-section')))).toEqual(
      ['thesis', 'account', 'instruments', 'costs', 'counterparts', 'trials', 'ledger'],
    );
    for (const s of await sections.all()) {
      await expect(s.locator('h2')).toBeVisible();
      await expect(s.locator('.row-margin .prop-number')).toBeVisible();
      await expect(s.locator('.row-gutter')).toHaveCount(1);
    }
    await expect(page.locator('figure.plate svg.ephemeris')).toBeVisible();
    await expect(page.locator('.marks .realm-mark[data-realm-mark="vault"]')).toBeVisible();
    await expect(page.locator('.trial-row')).toHaveCount(2);
    await expect(page.locator('.portrayal')).toHaveCount(4);
    expect(
      await page
        .locator('.portrayal')
        .evaluateAll((p) => p.map((x) => x.getAttribute('data-rank'))),
    ).toEqual(['exemplar', 'runner-up', 'notable', 'notable']);
    await expect(page.locator('.portrayal-filing').nth(1)).toHaveText(
      'Called “Sorcerer, a Master of the Mystic Arts” in the work; filed here as the Wizard.',
    );
  });

  test('evidence is given in the cipher only; the sources stand in the margin in both voices', async ({
    page,
  }) => {
    await still(page);
    const evidence = page.locator('.portrayal-evidence').first();
    await expect(evidence).toBeHidden();
    await expect(page.locator('.portrayal-sources').first()).toBeVisible();
    await page.getByRole('button', { name: 'Read the Cipher' }).click();
    await expect(evidence).toBeVisible();
    await expect(page.locator('.portrayal-sources').first()).toBeVisible();
  });
});

test.describe('the plate is built as a geometer builds (R-PH4-01, R-PH4-02, R-MOT-02)', () => {
  /** Each step of the sigil and the moment its drawing begins, read from the built page. */
  const steps = (page: Page) =>
    page.locator('svg.ephemeris g.sigil [data-step]').evaluateAll((els) =>
      els.map((el) => {
        const timed = el.matches('[style*="--delay"]')
          ? el
          : el.querySelector('[style*="--delay"]');
        const delay = /--delay:\s*([\d.]+)s/.exec(timed?.getAttribute('style') ?? '')?.[1];
        return { step: Number(el.getAttribute('data-step')), delay: Number(delay) };
      }),
    );

  test('the sigil draws move by move, in the order it was constructed', async ({ page }) => {
    await page.goto(WIZARD);
    const s = await steps(page);
    const declared = await page.locator('svg.ephemeris g.sigil').getAttribute('data-steps');
    expect(s).toHaveLength(Number(declared));
    expect(s.map((x) => x.step)).toEqual(s.map((_, i) => i));
    for (let i = 1; i < s.length; i++) expect(s[i]!.delay).toBeGreaterThan(s[i - 1]!.delay);
  });

  test('the threads are drawn after the figure is finished, and all meet at its focus', async ({
    page,
  }) => {
    await page.goto(WIZARD);
    const s = await steps(page);
    const last = s.at(-1)!.delay;
    const threads = await page.locator('svg.ephemeris path.thread').evaluateAll((ps) => {
      const svg = (ps[0] as SVGPathElement).ownerSVGElement!;
      const [fx, fy] = svg.getAttribute('data-focus')!.split(' ').map(Number);
      return ps.map((p) => {
        const path = p as SVGPathElement;
        const end = path.getPointAtLength(path.getTotalLength());
        const delay = Number(/--delay:\s*([\d.]+)s/.exec(path.getAttribute('style') ?? '')?.[1]);
        return { gap: Math.hypot(end.x - fx!, end.y - fy!), delay };
      });
    });
    expect(threads).toHaveLength(8);
    for (const t of threads) {
      expect(t.gap).toBeLessThan(0.5);
      expect(t.delay).toBeGreaterThan(last);
    }
  });

  test('the entrance is a sweep of the compass, then its chord (R-FLO-WIZ-ENT)', async ({
    page,
  }) => {
    await page.goto(WIZARD);
    const arc = page.locator('.compass-sweep .sweep-arc');
    const chord = page.locator('.compass-sweep .sweep-chord');
    const timing = (el: typeof arc) =>
      el.evaluate((e) => {
        const s = getComputedStyle(e);
        return {
          name: s.animationName,
          delay: parseFloat(s.animationDelay),
          duration: parseFloat(s.animationDuration),
        };
      });
    const a = await timing(arc);
    const c = await timing(chord);
    expect(a.name).toBe('ink-draw');
    expect(a.duration).toBeCloseTo(1.4, 5);
    expect(c.delay).toBeGreaterThan(a.delay + a.duration * 0.75);
  });
});

test.describe('the threads answer a passing hand (R-ID-WIZ-06)', () => {
  /** A point in the middle of a thread, on the screen. */
  const onThread = (page: Page) =>
    page
      .locator('svg.ephemeris path.thread-hit')
      .nth(5)
      .evaluate((hit) => {
        const p = hit as SVGPathElement;
        const mid = p.getPointAtLength(p.getTotalLength() * 0.45);
        const m = p.getScreenCTM()!;
        return { x: mid.x * m.a + mid.y * m.c + m.e, y: mid.x * m.b + mid.y * m.d + m.f };
      });
  const threadAt = (page: Page, at: { x: number; y: number }) =>
    page.evaluate(
      ({ x, y }) => document.elementFromPoint(x, y)?.getAttribute('data-thread') ?? null,
      at,
    );

  /**
   * Moves the pointer straight onto the middle of a thread, crossing no other thread on the way,
   * and reports which thread it is over.
   */
  const overThread = async (page: Page) => {
    const at = await onThread(page);
    await page.mouse.move(at.x, at.y);
    return threadAt(page, at);
  };

  test('a thread gives way to the hand, lets a grain fall to the focus, and returns', async ({
    page,
  }) => {
    await page.goto(WIZARD);
    await fineOnly(page);
    await page.locator('svg.ephemeris').scrollIntoViewIfNeeded();
    await expect(page.locator('svg.ephemeris')).toHaveAttribute('data-live', '');
    // The idle grains wait on a visible tab; reported hidden, only the hand's grains fall.
    await page.evaluate(() =>
      Object.defineProperty(document, 'visibilityState', { get: () => 'hidden' }),
    );
    const resting = await page
      .locator('svg.ephemeris path.thread')
      .evaluateAll((ps) => ps.map((p) => p.getAttribute('d')));
    const index = await overThread(page);
    expect(index).not.toBeNull();
    const thread = page.locator(`svg.ephemeris path.thread[data-thread="${index}"]`);
    const rest = resting[Number(index)];
    await expect(thread).toHaveClass(/nudged/);
    await expect.poll(() => thread.getAttribute('d')).not.toBe(rest);

    const grain = page.locator(`svg.ephemeris .grain.falling[data-thread="${index}"]`);
    await expect(grain).toHaveCount(1);
    // Every frame of its fall, the grain rides the thread as it then lies.
    const fall = await page.evaluate(
      (i) =>
        new Promise<{ frames: number; worst: number }>((done) => {
          const svg = document.querySelector('svg.ephemeris')!;
          const path = svg.querySelector<SVGPathElement>(`path.thread[data-thread="${i}"]`)!;
          let frames = 0;
          let worst = 0;
          const look = () => {
            const g = svg.querySelector<SVGCircleElement>(`.grain.falling[data-thread="${i}"]`);
            if (!g) return done({ frames, worst });
            const x = g.cx.baseVal.value;
            const y = g.cy.baseVal.value;
            const n = path.getTotalLength();
            let best = Infinity;
            for (let k = 0; k <= 200; k++) {
              const q = path.getPointAtLength((n * k) / 200);
              best = Math.min(best, Math.hypot(q.x - x, q.y - y));
            }
            frames++;
            worst = Math.max(worst, best);
            requestAnimationFrame(look);
          };
          look();
        }),
      index,
    );
    expect(fall.frames).toBeGreaterThan(5);
    expect(fall.worst).toBeLessThan(2.5);
    await expect(page.locator('svg.ephemeris')).toHaveAttribute('data-arrivals', '1');
    // A still hand holds the thread aside: it neither twitches back nor lets more grains fall.
    await page.waitForTimeout(1500);
    await expect(thread).toHaveClass(/nudged/);
    await expect(grain).toHaveCount(0);
    await expect(page.locator('svg.ephemeris')).toHaveAttribute('data-arrivals', '1');
    await expect(
      page.locator(`svg.ephemeris path.thread-hit[data-thread="${index}"]`),
    ).toHaveAttribute('d', rest!);
    await page.mouse.move(5, 5);
    await expect(thread).not.toHaveClass(/nudged/);
    // The return is worked exactly for whatever moment a frame falls, so the first frame after
    // about 1.3 s lands at rest; the wait is wide only for an engine starved of frames under load.
    await expect.poll(() => thread.getAttribute('d'), { timeout: 10000 }).toBe(rest);
  });

  test('on a touch screen, a tap on a thread stirs it and lets a grain fall', async ({ page }) => {
    await page.goto(WIZARD);
    test.skip(!(await page.evaluate(() => matchMedia('(pointer: coarse)').matches)), 'needs touch');
    await page.locator('svg.ephemeris').scrollIntoViewIfNeeded();
    await expect(page.locator('svg.ephemeris')).toHaveAttribute('data-live', '');
    const at = await onThread(page);
    const index = await threadAt(page, at);
    expect(index).not.toBeNull();
    await page.touchscreen.tap(at.x, at.y);
    await expect(page.locator(`svg.ephemeris .grain.falling[data-thread="${index}"]`)).toHaveCount(
      1,
    );
    await expect(page.locator('svg.ephemeris')).toHaveAttribute('data-arrivals', /^[1-9]/, {
      timeout: 4000,
    });
  });

  test('under reduced motion the plate is still: no thread moves, no grain falls', async ({
    page,
  }) => {
    await still(page);
    const svg = page.locator('svg.ephemeris');
    await svg.scrollIntoViewIfNeeded();
    await expect(svg).not.toHaveAttribute('data-live');
    const before = await page
      .locator('svg.ephemeris path.thread')
      .evaluateAll((ps) => ps.map((p) => p.getAttribute('d')));
    await overThread(page);
    await page.waitForTimeout(600);
    const after = await page
      .locator('svg.ephemeris path.thread')
      .evaluateAll((ps) => ps.map((p) => p.getAttribute('d')));
    expect(after).toEqual(before);
    await expect(page.locator('svg.ephemeris .grain.falling')).toHaveCount(0);
  });
});

test.describe("the Wizard's cursor (R-FLO-WIZ-CUR, R-PH4-07)", () => {
  test('a fine pointer becomes a pair of compasses that strikes fading construction arcs', async ({
    page,
  }) => {
    await page.goto(WIZARD);
    await fineOnly(page);
    await expect(page.locator('body')).toHaveClass(/compass-cursor/);
    expect(await page.locator('h1').evaluate((h) => getComputedStyle(h).cursor)).toMatch(/^url\(/);
    expect(
      await page
        .locator('.trial-name a')
        .first()
        .evaluate((a) => getComputedStyle(a).cursor),
    ).toBe('pointer');
    await page.mouse.move(200, 300);
    for (let i = 1; i <= 14; i++)
      await page.mouse.move(200 + i * 60, 300 + (i % 2) * 70, { steps: 2 });
    const arcs = page.locator('svg.compass-trail path.construction-arc');
    expect(await arcs.count()).toBeGreaterThan(0);
    expect(await arcs.count()).toBeLessThanOrEqual(8);
    await expect(page.locator('svg.compass-trail')).toHaveAttribute('aria-hidden', 'true');
    await expect(arcs).toHaveCount(0, { timeout: 6000 });
  });

  test('leaving the folio takes the cursor and its trail away', async ({ page }) => {
    await page.goto(WIZARD);
    await fineOnly(page);
    await expect(page.locator('body')).toHaveClass(/compass-cursor/);
    await page.getByRole('navigation').getByRole('link', { name: 'The Codex' }).click();
    await expect(page).toHaveURL(/\/codex\/$/);
    await expect(page.locator('body')).not.toHaveClass(/compass-cursor/);
    await expect(page.locator('svg.compass-trail')).toHaveCount(0);
  });

  test('touch and reduced motion keep the ordinary pointer', async ({ browser }) => {
    const touch = await browser.newContext({
      hasTouch: true,
      isMobile: true,
      viewport: { width: 412, height: 915 },
    });
    await unsealed(touch);
    const t = await touch.newPage();
    await t.goto(WIZARD);
    await expect(t.locator('body')).not.toHaveClass(/compass-cursor/);
    await touch.close();
    const calm = await browser.newContext({ reducedMotion: 'reduce' });
    await unsealed(calm);
    const c = await calm.newPage();
    await c.goto(WIZARD);
    await expect(c.locator('h1')).toBeVisible();
    await expect(c.locator('body')).not.toHaveClass(/compass-cursor/);
    await calm.close();
  });
});

test.describe('the construction capital opens the Account (R-TYPE-01, R-FLO-WIZ-INI, D-26, D-28)', () => {
  test('the capital is finished before the text beside it begins to appear', async ({ page }) => {
    await page.goto(WIZARD);
    const versal = page.locator('.account-almanac .versal');
    await expect(versal).toHaveAttribute('aria-hidden', 'true');
    const finished = Number(await versal.getAttribute('data-finished'));
    const text = await page.locator('.account-text').evaluate((el) => {
      const s = getComputedStyle(el);
      return { name: s.animationName, delay: parseFloat(s.animationDelay) };
    });
    expect(text.name).toBe('wizard-reveal');
    expect(text.delay).toBeGreaterThanOrEqual(finished);
    const gild = await page
      .locator('.versal-letter')
      .evaluate((el) => parseFloat(getComputedStyle(el).animationDelay));
    const guides = await page
      .locator('.versal-guide')
      .evaluateAll((gs) => gs.map((g) => parseFloat(getComputedStyle(g).animationDelay)));
    expect(gild).toBeGreaterThan(Math.max(...guides));
  });

  test('the letter it replaces is still read: the prose begins with its own first word', async ({
    page,
  }) => {
    await still(page);
    const first = await page.locator('.account-text p').first().innerText();
    expect(first.startsWith('The Wizard was born with nothing.')).toBe(true);
    await page.getByRole('button', { name: 'Read the Cipher' }).click();
    await expect(page.locator('.versal')).toBeHidden();
  });
});

test.describe('pieces wait to be seen (R-MOT-04, D-29)', () => {
  test('a seal far down the leaf is not pressed until the reader reaches it', async ({ page }) => {
    await page.goto(WIZARD);
    const row = page.locator('[data-section="ledger"]');
    await expect(row).toHaveClass(/waiting/);
    const state = () =>
      page
        .locator('.verdict-seal .seal-body')
        .first()
        .evaluate((el) => el.getAnimations().map((a) => a.playState));
    expect(await state()).toContain('paused');
    await row.scrollIntoViewIfNeeded();
    await page.locator('.verdict-seal').first().scrollIntoViewIfNeeded();
    await expect(row).not.toHaveClass(/waiting/);
    await expect.poll(state).not.toContain('paused');
  });

  test('the initial is not drawn, nor its prose revealed, until the reader reaches it', async ({
    page,
  }) => {
    await page.goto(WIZARD);
    const row = page.locator('[data-section="account"]');
    await expect(row).toHaveClass(/waiting/);
    const states = () =>
      row.evaluate((el) =>
        [
          ...el.querySelectorAll('.versal-frame, .versal-guide, .versal-letter, .account-text'),
        ].flatMap((n) => n.getAnimations().map((a) => a.playState)),
      );
    const before = await states();
    expect(before.length).toBeGreaterThan(2);
    expect(new Set(before)).toEqual(new Set(['paused']));
    await row.scrollIntoViewIfNeeded();
    await expect(row).not.toHaveClass(/waiting/);
    await expect.poll(states).not.toContain('paused');
  });

  test('a leaf printed unread is printed whole: initial, prose and seals finished', async ({
    page,
  }) => {
    await page.goto(WIZARD);
    await expect(page.locator('[data-section="account"]')).toHaveClass(/waiting/);
    await page.emulateMedia({ media: 'print' });
    const states = () =>
      page.evaluate(() =>
        [
          ...document.querySelectorAll(
            '.versal-frame, .versal-guide, .versal-letter, .account-text, .verdict-seal .seal-body',
          ),
        ].flatMap((n) => n.getAnimations().map((a) => a.playState)),
      );
    await expect.poll(async () => [...new Set(await states())]).toEqual(['finished']);
  });

  test('the seal is pressed small: never more than a breath past its size', async ({ page }) => {
    await still(page);
    await expect(page.locator('.verdict-seal .seal-body').first()).toBeAttached();
    const frames = await page.evaluate(() => {
      const sheet = [...document.styleSheets].flatMap((s) => [...s.cssRules]);
      const kf = sheet.find((r) => r instanceof CSSKeyframesRule && r.name === 'seal-press') as
        CSSKeyframesRule | undefined;
      return kf ? [...kf.cssRules].map((r) => (r as CSSKeyframeRule).style.transform) : [];
    });
    expect(frames.length).toBeGreaterThan(2);
    for (const t of frames)
      for (const s of t.match(/scale\(([^)]*)\)/g) ?? []) {
        for (const n of s.slice(6, -1).split(',').map(Number)) expect(n).toBeLessThanOrEqual(1.03);
      }
  });

  test('under reduced motion nothing waits, and every seal is already pressed', async ({
    page,
  }) => {
    await still(page);
    await expect(page.locator('.waiting')).toHaveCount(0);
    const opacity = await page
      .locator('.verdict-seal .seal-body')
      .first()
      .evaluate((el) => getComputedStyle(el).opacity);
    expect(opacity).toBe('1');
  });
});

test.describe("the Wizard's type and reckoning (R-ID-WIZ-05, R-PH4-06)", () => {
  test('figures are tabular and lining; labels are small capitals', async ({ page }) => {
    await still(page);
    const margin = await page
      .locator('.row-margin')
      .first()
      .evaluate((el) => getComputedStyle(el).fontVariantNumeric);
    expect(margin).toContain('tabular-nums');
    expect(margin).toContain('lining-nums');
    const caps = await page
      .locator('.row-title')
      .first()
      .evaluate((el) => getComputedStyle(el).fontVariantCaps);
    expect(caps).toBe('small-caps');
  });

  test("the margin reckons the reader's own day by the mean month", async ({ page }) => {
    const when = new Date(Date.UTC(2026, 9, 7, 12, 0, 0));
    await page.clock.setFixedTime(when);
    await still(page);
    const expected = figures(reckon(when));
    for (const key of ['julian-day', 'days', 'lunations', 'age'] as const)
      await expect(page.locator(`[data-reckon="${key}"]`)).toHaveText(expected[key]);
    await expect(page.locator('[data-reckon="julian-day"]')).toHaveText('2,461,321.0');
  });
});

test('under reduced motion the folio is shown finished at once', async ({ page }) => {
  await still(page);
  await page.waitForTimeout(150);
  const running = await page.evaluate(
    () =>
      document.getAnimations().filter((a) => {
        const d = a.effect?.getTiming().duration;
        return typeof d === 'number' && d > 1;
      }).length,
  );
  expect(running).toBe(0);
  const clip = await page.locator('.account-text').evaluate((el) => getComputedStyle(el).clipPath);
  // Finished, the reveal's clip is either gone or an inset of nothing on every side.
  if (clip !== 'none') {
    expect(clip).toMatch(/^inset\(/);
    for (const n of clip.match(/-?[\d.]+/g) ?? []) expect(Number(n)).toBe(0);
  }
  await expect(page.locator('.account-text')).toBeVisible();
});
