/** The build phase the project has reached. Structural tests require everything up to this phase. */
export const CURRENT_PHASE = 6;
