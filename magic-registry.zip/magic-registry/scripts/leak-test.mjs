// Fails if the build carries a page that belongs only to development. An extra scan kept
// outside the project may be chained on by setting MR_PRIVATE_SCAN to its path; it is given
// the project root and fails by exiting non-zero.
// Usage: node scripts/leak-test.mjs [--allow-missing-dist]
import { spawnSync } from 'node:child_process';
import { stat } from 'node:fs/promises';
import { join } from 'node:path';
import { listReleaseFiles, rootPath } from './project-files.mjs';

const failures = [];
const exists = (path) =>
  stat(join(rootPath, path)).then(
    () => true,
    () => false,
  );

const distExists = await exists('dist');
if (!distExists && !process.argv.includes('--allow-missing-dist')) {
  failures.push('dist/: missing; build before running the leak test');
}
if (distExists) {
  for (const devOnly of ['specimen', 'og-cards'])
    if (await exists(join('dist', devOnly)))
      failures.push(`dist/${devOnly}: a development-only page reached the build`);
}

const release = await listReleaseFiles();

const extra = process.env.MR_PRIVATE_SCAN;
if (extra) {
  const run = spawnSync(process.execPath, [extra, rootPath], { stdio: 'inherit' });
  if (run.status !== 0) failures.push('the private scan failed (see above)');
}

if (failures.length) {
  console.error('Leak test FAILED:\n' + [...new Set(failures)].map((f) => '  - ' + f).join('\n'));
  process.exit(1);
}
console.log(
  `Leak test passed: ${release.length} release files checked; no development page in the build.`,
);
