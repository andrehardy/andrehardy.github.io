// Photographs the Open Graph cards (src/dev/og.astro) into public/og/, one JPEG each.
// Run after a change to a sigil, a palette or an epithet, and commit the images.
// Usage: node scripts/og.mjs
import { spawn, spawnSync } from 'node:child_process';
import { mkdir } from 'node:fs/promises';
import { join } from 'node:path';
import { chromium } from '@playwright/test';
import { rootPath } from './project-files.mjs';

const PORT = 4333;
const CARDS = `http://localhost:${PORT}/magic-registry/og-cards/`;
const out = join(rootPath, 'public', 'og');

const build = spawnSync('npx astro build', {
  cwd: rootPath,
  shell: true,
  stdio: 'inherit',
  env: { ...process.env, MR_PROOF: '1' },
});
if (build.status !== 0) process.exit(build.status ?? 1);

const server = spawn(process.execPath, ['scripts/serve-static.mjs', '.proof', String(PORT)], {
  cwd: rootPath,
  stdio: 'ignore',
});
let browser;
try {
  browser = await chromium.launch();
  await mkdir(out, { recursive: true });
  const page = await browser.newPage({ viewport: { width: 1200, height: 630 } });
  for (let i = 0; ; i++) {
    try {
      await page.goto(CARDS);
      break;
    } catch (e) {
      if (i > 20) throw e;
      await new Promise((r) => setTimeout(r, 250));
    }
  }
  await page.evaluate(() => document.fonts.ready);
  const cards = page.locator('[data-og]');
  const count = await cards.count();
  for (let i = 0; i < count; i++) {
    const card = cards.nth(i);
    const id = await card.getAttribute('data-og');
    await card.screenshot({
      path: join(out, `${id}.jpg`),
      type: 'jpeg',
      quality: 88,
      animations: 'disabled',
    });
    console.log(`og/${id}.jpg`);
  }
} finally {
  await browser?.close();
  server.kill();
}
