// Packs the project for manual upload to GitHub, leaving out everything that is rebuilt or private.
import { createWriteStream } from 'node:fs';
import { join } from 'node:path';
import { ZipArchive } from 'archiver';
import { listReleaseFiles, rootPath } from './project-files.mjs';

const outPath = process.argv[2] ?? join(rootPath, 'magic-registry.zip');
const files = await listReleaseFiles();

const output = createWriteStream(outPath);
const archive = new ZipArchive({ zlib: { level: 9 } });
const closed = new Promise((resolve, reject) => {
  output.on('close', resolve);
  archive.on('error', reject);
});
archive.pipe(output);
for (const f of files) archive.file(join(rootPath, f), { name: `magic-registry/${f}` });
await archive.finalize();
await closed;

console.log(`${outPath}: ${files.length} files, ${(archive.pointer() / 1024).toFixed(0)} KB`);
for (const f of files) console.log('  ' + f);
