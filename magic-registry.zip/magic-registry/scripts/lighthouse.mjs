// Lighthouse budgets against the built site, served under its real base path.
// Usage: node scripts/lighthouse.mjs          (key routes, run at every gate)
//        node scripts/lighthouse.mjs --all    (every built route, run at release)
//        add --mobile for the phone settings: informational, never failing (R-PROC-25)
import { spawnSync } from 'node:child_process';
import { mkdir, writeFile } from 'node:fs/promises';
import { join, relative, sep } from 'node:path';
import { chromium } from '@playwright/test';
import { rootPath, walk } from './project-files.mjs';

const PORT = 4330;
const BASE = `http://localhost:${PORT}/magic-registry/`;
const KEY_ROUTES = ['', 'archetypes/wizard/', 'ledger/', 'codex/', 'trials/glass/', 'preface/'];
const MOBILE = process.argv.includes('--mobile');
const level = MOBILE ? 'warn' : 'error';

const distPath = join(rootPath, 'dist');
const built = [];
for await (const f of walk(distPath)) {
  if (!f.endsWith('index.html')) continue;
  const rel = relative(distPath, f)
    .split(sep)
    .join('/')
    .replace(/index\.html$/, '');
  built.push(rel);
}
if (!built.length) {
  console.error('Lighthouse: dist/ has no pages. Build first.');
  process.exit(1);
}

const missing = KEY_ROUTES.filter((r) => !built.includes(r));
if (missing.length) {
  console.error(`Lighthouse: key route(s) not built: ${missing.map((r) => '/' + r).join(', ')}`);
  process.exit(1);
}
const routes = process.argv.includes('--all') ? built.sort() : KEY_ROUTES;
const config = {
  ci: {
    collect: {
      url: routes.map((r) => BASE + r),
      numberOfRuns: 1,
      startServerCommand: `npx astro preview --port ${PORT}`,
      startServerReadyPattern: 'localhost',
      chromePath: chromium.executablePath(),
      settings: MOBILE
        ? { chromeFlags: '--headless=new --no-sandbox' }
        : { preset: 'desktop', chromeFlags: '--headless=new --no-sandbox' },
    },
    assert: {
      assertions: {
        'categories:performance': [level, { minScore: 0.9 }],
        'categories:accessibility': [level, { minScore: 1 }],
        'largest-contentful-paint': [level, { maxNumericValue: 2500 }],
        'cumulative-layout-shift': [level, { maxNumericValue: 0.05 }],
        'resource-summary:script:size': [level, { maxNumericValue: 160000 }],
      },
    },
    upload: {
      target: 'filesystem',
      outputDir: MOBILE ? '.lighthouseci/mobile' : '.lighthouseci/reports',
    },
  },
};

await mkdir(join(rootPath, '.lighthouseci'), { recursive: true });
const configPath = join(rootPath, '.lighthouseci', 'lighthouserc.json');
await writeFile(configPath, JSON.stringify(config, null, 2));

console.log(
  `Lighthouse${MOBILE ? ' (mobile, informational)' : ''}: ${routes.length} route(s): ${routes.map((r) => '/' + r).join(', ')}`,
);
const env = { ...process.env };
delete env.NO_COLOR;
const result = spawnSync(`npx lhci autorun --config="${configPath}"`, {
  stdio: 'inherit',
  shell: true,
  env,
});
process.exit(result.status ?? 1);
