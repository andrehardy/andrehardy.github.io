// Serves a built folder under the site's base path, for tests that need a second build
// alongside `astro preview` (which allows only one instance per project).
// Usage: node scripts/serve-static.mjs <dir> <port>
import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { extname, join, normalize, resolve, sep } from 'node:path';

const [dir = '.proof', port = '4332'] = process.argv.slice(2);
const root = resolve(dir);
const BASE = '/magic-registry/';

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8',
};

async function resolveFile(urlPath) {
  const rel = decodeURIComponent(urlPath.slice(BASE.length));
  const target = normalize(join(root, rel));
  if (target !== root && !target.startsWith(root + sep)) return null;
  try {
    const s = await stat(target);
    if (s.isDirectory()) {
      const index = join(target, 'index.html');
      await stat(index);
      return index;
    }
    return target;
  } catch {
    return null;
  }
}

createServer(async (req, res) => {
  const path = new URL(req.url ?? '/', 'http://localhost').pathname;
  if (!path.startsWith(BASE)) {
    res.writeHead(404).end();
    return;
  }
  const file = await resolveFile(path);
  if (!file) {
    // As GitHub Pages does for a project site: the built 404 page, with a 404 status.
    const missing = await readFile(join(root, '404.html')).catch(() => null);
    if (missing) res.writeHead(404, { 'content-type': TYPES['.html'] }).end(missing);
    else res.writeHead(404, { 'content-type': 'text/plain' }).end('Not found');
    return;
  }
  res.writeHead(200, { 'content-type': TYPES[extname(file)] ?? 'application/octet-stream' });
  res.end(await readFile(file));
}).listen(Number(port), '127.0.0.1', () =>
  console.log(`serving ${root} at http://localhost:${port}${BASE}`),
);
