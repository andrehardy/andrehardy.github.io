// Shared definition of "what the project is": used by the zip and the leak test.
import { readdir } from 'node:fs/promises';
import { join, relative, sep } from 'node:path';

export const rootPath = decodeURIComponent(new URL('..', import.meta.url).pathname).replace(
  /^\/([A-Za-z]:)/,
  '$1',
);

/** Rebuilt or machine-local folders that are never part of the project. */
export const CACHE_DIRS = new Set([
  'node_modules',
  '.astro',
  '.git',
  'test-results',
  'playwright-report',
  'blob-report',
  '.lighthouseci',
  'coverage',
  '.proof',
]);

/** Never shipped: build output, the release artifact, secrets, OS and editor litter. */
const RELEASE_EXCLUDED_NAMES = new Set([
  'dist',
  'magic-registry.zip',
  '.DS_Store',
  'Thumbs.db',
  '.idea',
]);
const isSecret = (name) => name === '.env' || name.startsWith('.env.');

/**
 * Walks a directory, yielding absolute file paths.
 * @param {string} dir
 * @param {(name: string, relPath: string, isDir: boolean) => boolean} keep
 */
export async function* walk(dir, keep = () => true) {
  let entries;
  try {
    entries = await readdir(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const entry of entries) {
    if (entry.isSymbolicLink()) continue;
    const full = join(dir, entry.name);
    const rel = relative(rootPath, full).split(sep).join('/');
    if (!keep(entry.name, rel, entry.isDirectory())) continue;
    if (entry.isDirectory()) yield* walk(full, keep);
    else yield full;
  }
}

/** Files that belong in the release zip, as sorted forward-slash relative paths. */
export async function listReleaseFiles() {
  const keep = (name, rel, isDir) => {
    if (CACHE_DIRS.has(name) || RELEASE_EXCLUDED_NAMES.has(name) || isSecret(name)) return false;
    if (rel.startsWith('.vscode/') && rel !== '.vscode/extensions.json' && !isDir) return false;
    return true;
  };
  const files = [];
  for await (const f of walk(rootPath, keep))
    files.push(relative(rootPath, f).split(sep).join('/'));
  return files.sort();
}
