export const rootPath: string;
export const CACHE_DIRS: Set<string>;
export function walk(
  dir: string,
  keep?: (name: string, relPath: string, isDir: boolean) => boolean,
): AsyncGenerator<string>;
export function listReleaseFiles(): Promise<string[]>;
