// Runs every check in order and stops at the first failure.
// Usage: node scripts/verify.mjs [step-name-fragment ...]
import { spawnSync } from 'node:child_process';

const steps = [
  ['Content and type check', 'npx astro check --minimumSeverity warning'],
  ['Lint', 'npx eslint . --max-warnings=0'],
  ['Formatting', 'npx prettier --check . --log-level warn'],
  ['Unit tests', 'npx vitest run'],
  ['Build', 'npx astro build'],
  ['Leak test', 'node scripts/leak-test.mjs'],
  ['End-to-end and accessibility tests', 'npx playwright test'],
  ['Lighthouse budgets', 'node scripts/lighthouse.mjs'],
];

const env = { ...process.env };
delete env.NO_COLOR;

const only = process.argv.slice(2);
for (const [name, cmd] of steps) {
  if (only.length && !only.some((o) => name.toLowerCase().includes(o.toLowerCase()))) continue;
  console.log(`\n=== ${name} ===`);
  const started = Date.now();
  const result = spawnSync(cmd, { stdio: 'inherit', shell: true, env });
  if (result.status !== 0) {
    console.error(`\nverify FAILED at: ${name}`);
    process.exit(result.status ?? 1);
  }
  console.log(`--- ${name} passed in ${((Date.now() - started) / 1000).toFixed(1)}s`);
}
console.log('\nverify passed.');
