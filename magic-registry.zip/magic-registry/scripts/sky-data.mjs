// Builds the sky the home page engraves (R-SKY-01, R-SKY-03), from two public sources:
//   - the Yale Bright Star Catalogue, 5th revised edition (Hoffleit and Warren, 1991; public
//     domain), in the JSON transcription at github.com/brettonw/YaleBrightStarCatalog;
//   - the constellation figures of d3-celestial (Olaf Frohn, BSD 3-clause; its notice is kept
//     beside the data in public/data/constellations.LICENSE.txt).
// The result is small enough to fetch when the Vault comes into view, and is checked in, so the
// build never touches the network. Run again only to change the cut: node scripts/sky-data.mjs
import { writeFile, mkdir } from 'node:fs/promises';

const BSC =
  'https://raw.githubusercontent.com/brettonw/YaleBrightStarCatalog/master/bsc5-short.json';
const LINES =
  'https://raw.githubusercontent.com/ofrohn/d3-celestial/master/data/constellations.lines.json';
const LICENSE = 'https://raw.githubusercontent.com/ofrohn/d3-celestial/master/LICENSE';

/** Stars to magnitude 4.6: every star of the figures, and about a thousand in all. */
const FAINTEST = 4.6;

const get = async (url) => {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${url}: ${res.status}`);
  return res;
};

const sexagesimal = (s, hours) => {
  const m = /([+-]?)(\d+)\D+(\d+)\D+([\d.]+)/.exec(s);
  if (!m) return NaN;
  const v = Number(m[2]) + Number(m[3]) / 60 + Number(m[4]) / 3600;
  return (m[1] === '-' ? -v : v) * (hours ? 15 : 1);
};

const round = (x, d = 2) => Math.round(x * 10 ** d) / 10 ** d;

const bsc = await (await get(BSC)).json();
const stars = bsc
  .map((s) => ({
    ra: sexagesimal(s.RA, true),
    dec: sexagesimal(s.Dec, false),
    v: Number(s.V),
    k: Number(s.K) || 6000,
  }))
  .filter((s) => Number.isFinite(s.ra) && Number.isFinite(s.dec) && s.v <= FAINTEST)
  .sort((a, b) => a.v - b.v)
  // [right ascension°, declination°, visual magnitude, colour temperature in hundreds of K]
  .map((s) => [round(s.ra), round(s.dec), round(s.v, 1), Math.round(s.k / 100)]);

const lines = await (await get(LINES)).json();
const figures = lines.features.map((f) => ({
  id: f.id,
  rank: Number(f.properties.rank),
  // d3-celestial gives right ascension from -180° to 180°; the almanac keeps 0° to 360°.
  lines: f.geometry.coordinates.map((l) =>
    l.map(([ra, dec]) => [round((ra + 360) % 360), round(dec)]),
  ),
}));

await mkdir(new URL('../public/data/', import.meta.url), { recursive: true });
const out = (name) => new URL(`../public/data/${name}`, import.meta.url);
await writeFile(out('stars.json'), JSON.stringify(stars));
await writeFile(out('constellations.json'), JSON.stringify(figures));
await writeFile(out('constellations.LICENSE.txt'), await (await get(LICENSE)).text());
console.log(`${stars.length} stars to magnitude ${FAINTEST}; ${figures.length} figures`);
