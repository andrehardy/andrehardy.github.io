// @ts-check
import { defineConfig } from 'astro/config';
import react from '@astrojs/react';
import mdx from '@astrojs/mdx';

/**
 * A proof is a test-only build (MR_PROOF=1) written to .proof/ instead of dist/, so the
 * end-to-end tests can exercise the design specimen exactly as built CSS renders it.
 */
const PROOF = process.env.MR_PROOF === '1';

/**
 * The design specimen is a working tool, not part of the almanac.
 * It is routed under `astro dev` and in a proof build, and never reaches dist/.
 */
const devOnlySpecimen = {
  name: 'dev-only-specimen',
  hooks: {
    /** @param {{ command: string, injectRoute: (route: { pattern: string, entrypoint: string }) => void }} options */
    'astro:config:setup': ({ command, injectRoute }) => {
      if (command === 'dev' || PROOF) {
        injectRoute({ pattern: '/specimen', entrypoint: './src/dev/specimen.astro' });
        injectRoute({ pattern: '/og-cards', entrypoint: './src/dev/og.astro' });
      }
    },
  },
};

export default defineConfig({
  site: 'https://andrehardy.github.io',
  base: '/magic-registry',
  trailingSlash: 'ignore',
  integrations: [react(), mdx(), devOnlySpecimen],
  outDir: PROOF ? './.proof' : './dist',
  build: {
    format: 'directory',
  },
  prefetch: {
    prefetchAll: false,
    defaultStrategy: 'hover',
  },
  devToolbar: {
    enabled: false,
  },
});
