import { defineConfig, devices } from '@playwright/test';

/** The built site, exactly as it will be published. */
const PORT = 4329;
/**
 * A proof build (MR_PROOF=1, written to .proof/, never shipped) that also contains the
 * design specimen, so the design system is tested as built CSS renders it.
 */
const PROOF_PORT = 4332;
const ALL_BROWSERS = process.env.ALL_BROWSERS === '1';

export default defineConfig({
  testDir: 'tests/e2e',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0,
  // Two workers at most: four engines on a small machine starve each other of frames.
  workers: ALL_BROWSERS ? 2 : undefined,
  reporter: [['list'], ['html', { open: 'never' }]],
  expect: {
    toHaveScreenshot: { maxDiffPixelRatio: 0.02, animations: 'disabled' },
  },
  use: {
    baseURL: `http://localhost:${PORT}/magic-registry/`,
    trace: 'retain-on-failure',
  },
  projects: ALL_BROWSERS
    ? [
        { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
        { name: 'firefox', use: { ...devices['Desktop Firefox'] } },
        // Headless WebKit, and the emulated phone, paint at a few frames a second here; one
        // retry lets a stall show as flaky, and the gate summary names each one.
        { name: 'webkit', retries: 1, use: { ...devices['Desktop Safari'] } },
        { name: 'mobile', retries: 1, use: { ...devices['Pixel 7'] } },
      ]
    : [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  webServer: [
    {
      command: `npx astro preview --port ${PORT}`,
      url: `http://localhost:${PORT}/magic-registry/`,
      reuseExistingServer: false,
      timeout: 60_000,
    },
    {
      command: `npx astro build && node scripts/serve-static.mjs .proof ${PROOF_PORT}`,
      url: `http://127.0.0.1:${PROOF_PORT}/magic-registry/specimen/`,
      env: { MR_PROOF: '1' },
      reuseExistingServer: false,
      timeout: 120_000,
    },
  ],
});
