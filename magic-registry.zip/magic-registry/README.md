# The Magic Registry

An almanac of the twelve kinds of practitioner of magic, filed by where their power comes from:
the Sealed Light, the Vault of the sky, the Threshold of the horizon, and the Deep Mantle of the
earth. Each practitioner has a folio of its own making, and three registers stand behind them:
the Codex (what a practitioner is, against where the power comes from), the Trials (one task
put to all twelve), and the Ledger (every portrayal in myth, books, film, television, games and
anime, with its verdict). Every passage is written twice: once as an almanac, and once plainly,
as the Cipher.

It is a static site built with [Astro](https://astro.build), published to GitHub Pages at
`https://andrehardy.github.io/magic-registry/`.

## Publishing it

The project is uploaded to GitHub by hand, as a zip.

1. Run `npm run zip`. It writes `magic-registry.zip` with the project's own files only:
   `node_modules/`, `dist/`, test output and anything else that is rebuilt are left out.
2. Unzip it into a GitHub repository named `magic-registry`, and push to `main`.
3. In the repository's **Settings → Pages**, set **Source** to **GitHub Actions**. The workflow
   in `.github/workflows/deploy.yml` then checks, tests, builds and publishes the site on every
   push to `main`.

The site is built for the base path `/magic-registry/`. To publish under another name or
account, change `site` and `base` in `astro.config.mjs`.

## Working on it

Node 24 is expected.

| Command           | What it does                                                                                                                       |
| ----------------- | ---------------------------------------------------------------------------------------------------------------------------------- |
| `npm install`     | Installs the dependencies.                                                                                                         |
| `npm run dev`     | Serves the site with live reload, at `http://localhost:4321/magic-registry/`.                                                      |
| `npm run build`   | Builds the site into `dist/`.                                                                                                      |
| `npm run preview` | Serves the built site.                                                                                                             |
| `npm run verify`  | The full check: types, lint, formatting, unit tests, build, leak test, end-to-end and accessibility tests, and Lighthouse budgets. |
| `npm run og`      | Redraws the Open Graph cards in `public/og/` from the sigils and palettes.                                                         |
| `npm run zip`     | Packs the project for upload.                                                                                                      |

End-to-end tests run in Chromium by default; set `ALL_BROWSERS=1` to add Firefox, WebKit and a
phone. Install the browsers once with `npx playwright install`.

### Where things are

- `src/content/`: the entries. Realms, beings, ways of access and the glossary are YAML; each
  archetype is a Markdown file; portrayals and Trials are YAML. Every reader-facing field holds
  both voices, `{ almanac, cipher }`, and `src/data/schemas.ts` enforces it.
- `src/folios/`: each archetype's folio, composed in its own manner.
- `src/descent/`: the home page's descent through the four realms, with its sky computed for the
  reader's own night.
- `src/styles/`: the tokens for colour, type and motion. Durations, curves and colours are named
  there and nowhere else.
- `tests/`: unit tests (Vitest), including the voice lint and the style lint, and end-to-end
  tests (Playwright, with axe for accessibility).

## Sources and licences

- **Type:** EB Garamond (the EB Garamond Project Authors, from the full release at
  github.com/octaviopardo/EBGaramond12, subset to Latin with its book features kept; licence in
  `src/fonts/EB-Garamond-OFL.txt`), with Cormorant Garamond, IM Fell English, Cinzel and
  UnifrakturMaguntia, all under the SIL Open Font License and served from this site.
- **Stars:** the Yale Bright Star Catalogue, 5th revised edition (Hoffleit and Warren, 1991;
  public domain), from the JSON transcription at github.com/brettonw/YaleBrightStarCatalog, cut
  to magnitude 4.6 (`public/data/stars.json`).
- **Constellation figures:** d3-celestial by Olaf Frohn, under the BSD 3-clause licence; its
  notice is kept beside the data in `public/data/constellations.LICENSE.txt`.
- `scripts/sky-data.mjs` rebuilds both sky files from those sources. The build itself never
  touches the network.
- The portrayals are cited, in each entry, to the works themselves.
